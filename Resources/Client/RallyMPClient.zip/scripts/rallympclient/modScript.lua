-- Auto-executed by BeamNG.drive VFS when joining the BeamMP server
-- Path: scripts/rallympclient/modScript.lua (single deterministic VFS bootstrap)

log("I", "rallyMP", "Bootstrapping Native BeamNG Rally Mode 2P Bridge (BeamNG v0.40.4+)...")
if not extensions.isExtensionLoaded("nativeRallyBridge") then
  extensions.load("nativeRallyBridge")
elseif extensions.nativeRallyBridge and extensions.nativeRallyBridge.rebindMpEvents then
  extensions.nativeRallyBridge.rebindMpEvents()
end
if setExtensionUnloadMode then
  setExtensionUnloadMode("nativeRallyBridge", "manual")
end
