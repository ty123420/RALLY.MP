angular.module("beamng.apps")
.directive("nativeRallyPeerTiming", [function () {
  return {
    template: "<div></div>",
    replace: true,
    restrict: "EA"
  };
}]);
