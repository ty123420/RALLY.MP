// BeamNG.drive v0.40.4+ MainGEUI Dynamic ModModule Entry
// Loaded directly by local://local/ui/entrypoints/main/boot.js
// Exact VFS path required by boot.js: ui/modModules/rallyMP/rallyMP.js

function notifyNativeRallyBridge() {
  try {
    if (window.bngApi && typeof window.bngApi.engineLua === "function") {
      window.bngApi.engineLua("if extensions and extensions.nativeRallyBridge and extensions.nativeRallyBridge.onCefBootModuleReady then extensions.nativeRallyBridge.onCefBootModuleReady() end");
    }
  } catch (err) {
    // Ignore early boot timing before bngApi attaches
  }
}

export function onLoad() {
  notifyNativeRallyBridge();
  setTimeout(notifyNativeRallyBridge, 350);
}

export function onUnload() {
  if (window.__NativeRallyMP && typeof window.__NativeRallyMP.closeAll === "function") {
    window.__NativeRallyMP.closeAll();
  }
}

notifyNativeRallyBridge();

export default {
  name: "rallyMP",
  onLoad,
  onUnload
};
