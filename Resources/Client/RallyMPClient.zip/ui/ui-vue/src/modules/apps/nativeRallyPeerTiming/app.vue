<template>
  <Transition name="fade">
    <div v-if="shouldShowHud()" class="native-rally-peer-hud">
      <div v-if="peerData.enableLiveSplitDeltaOverlay" class="peer-header-bar">
        <span class="peer-mode-label">
          {{ peerData.peerState.participationMode === "codriver" ? "SHARED CO-DRIVER" : "BEAMMP 2P RALLY" }}
        </span>
        <span class="peer-rtt">RTT {{ peerData.rttMs }}ms</span>
      </div>

      <div v-if="peerData.enableLiveSplitDeltaOverlay && peerData.lastSplit" class="peer-split-row">
        <span class="split-driver">
          {{ peerData.lastSplit.playerName }} · {{ peerData.lastSplit.splitLabel }}
        </span>
        <span
          v-if="peerData.lastSplit.deltaSec !== null && peerData.lastSplit.deltaSec !== undefined"
          class="split-delta"
          :class="peerData.lastSplit.deltaSec <= 0 ? 'ahead' : 'behind'"
        >
          {{ peerData.lastSplit.deltaSec <= 0 ? "" : "+" }}{{ Number(peerData.lastSplit.deltaSec).toFixed(2) }}s
        </span>
      </div>
    </div>
  </Transition>
</template>

<script setup>
import { reactive, onMounted, onUnmounted } from "vue"
import { useBridge } from "@/bridge"
import { useStreams, useEvents } from "@/services/events"

defineOptions({ name: "NativeRallyPeerTimingApp" })

const { lua } = useBridge()
const events = useEvents()

const peerData = reactive({
  rttMs: 0,
  enableLiveSplitDeltaOverlay: true,
  lastSplit: null,
  peerState: {
    status: "FREEROAM",
    participationMode: "two_car",
    hasPendingProposal: false,
    pendingProposal: false
  }
})

function isActiveStageStatus(st) {
  return (
    st === "START_SCREEN" ||
    st === "LOOP_ACTIVE" ||
    st === "STAGE_STAGING" ||
    st === "STAGE_ACTIVE" ||
    st === "RECCE_ACTIVE"
  )
}

useStreams(["nativeRallyPeer", "rallyLoop"], (streams) => {
  if (streams.nativeRallyPeer) {
    Object.assign(peerData, streams.nativeRallyPeer)
  }
})

function shouldShowHud() {
  return Boolean(
    peerData.enableLiveSplitDeltaOverlay &&
      (isActiveStageStatus(peerData.peerState.status) || peerData.lastSplit)
  )
}

onMounted(() => {
  events.on("NativeRallyVueState", (data) => {
    if (data) Object.assign(peerData, data)
  })
  lua.extensions.nativeRallyBridge.vueRequestState()
})

onUnmounted(() => {
  events.off("NativeRallyVueState")
})
</script>

<style lang="scss" scoped>
.native-rally-peer-hud {
  display: flex;
  flex-direction: column;
  width: 100%;
  font-family: "Noto Sans", sans-serif;
  color: #ffffff;
}

.peer-header-bar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  background-color: #009a1a;
  padding: 0.25rem 0.55rem;
  font-size: 0.8rem;
  font-weight: 700;
  letter-spacing: 0.04rem;
}

.peer-rtt {
  font-family: monospace;
}

.peer-split-row {
  display: flex;
  justify-content: space-between;
  align-items: center;
  background-color: rgba(0, 0, 0, 0.82);
  padding: 0.35rem 0.55rem;
  font-family: monospace;
  font-size: 0.92rem;
}

.split-delta {
  font-weight: 700;
  &.ahead { color: #66ff66; }
  &.behind { color: #ff6666; }
}

.fade-enter-active,
.fade-leave-active {
  transition: opacity 0.2s ease;
}
.fade-enter-from,
.fade-leave-to {
  opacity: 0;
}
</style>
