// BeamNG.drive v0.40+ ui-vue Runtime SFC Mod Entry
// Path inside archive: ui/ui-vue/mods/rallyMP/index.js
// Pairs with live MainGEUI Pause Menu injection (be:executeJS) in nativeRallyBridge.lua

import NativeRallyPauseTab from "./NativeRallyPauseTab.vue"

const PAUSE_ROUTE_NAME = "pause.rallyMPRally"

export function onLoad(api = {}) {
  if (api.router && typeof api.router.addRoute === "function") {
    api.router.addRoute({
      path: "/pause/rallyMP-rally",
      name: PAUSE_ROUTE_NAME,
      component: NativeRallyPauseTab,
      meta: {
        uiApps: { shown: false },
        infoBar: { visible: true, showSysInfo: true }
      }
    })
  }
}

export function onUnload(api = {}) {
  if (api.router && typeof api.router.removeRoute === "function") {
    api.router.removeRoute(PAUSE_ROUTE_NAME)
  }
}

export default {
  name: "rallyMP",
  onLoad,
  onUnload,
  NativeRallyPauseTab
}
