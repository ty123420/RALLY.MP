<template>
  <div class="native-rally-pause-view" bng-ui-scope="nativeRallyPause">
    <!-- Top Toolbar Header -->
    <header class="rally-pause-toolbar">
      <div class="toolbar-brand">
        <span class="slanted-mark" aria-hidden="true"></span>
        <div class="toolbar-titles">
          <div class="title-with-pill">
            <h2 class="toolbar-heading">BeamMP Native Rally Mode</h2>
            <span class="status-pill" :class="sessionStatusClass">
              {{ sessionStatusLabel }}
            </span>
          </div>
          <span class="toolbar-sub">
            Map: {{ (bridgeState.peerState.currentLevel || "freeroam").toUpperCase() }}
            · Latency: {{ bridgeState.rttMs || 15 }}ms
            · Connected: {{ connectedList.length }} Driver{{ connectedList.length === 1 ? '' : 's' }}
          </span>
        </div>
      </div>

      <div class="toolbar-controls">
        <div class="control-cluster" v-if="bridgeState.defaultVehicleChoice === 'host_chooses'">
          <span class="cluster-label">Car:</span>
          <button
            class="bng-seg-btn"
            :class="{ active: selectedVehicleMode === 'own_mp_car' }"
            bng-nav-item
            v-bng-on-ui-nav:ok.asMouse.focusRequired
            v-bng-sound-class="'bng_click_hover_generic'"
            @click="setVehicleMode('own_mp_car')"
            title="Drive your current multiplayer car across maps"
          >
            Own MP Car
          </button>
          <button
            class="bng-seg-btn"
            :class="{ active: selectedVehicleMode === 'stage_preset_car' }"
            bng-nav-item
            v-bng-on-ui-nav:ok.asMouse.focusRequired
            v-bng-sound-class="'bng_click_hover_generic'"
            @click="setVehicleMode('stage_preset_car')"
            title="Spawn official NGRC Group A rally spec car"
          >
            Stage Preset Car
          </button>
        </div>

        <div class="control-cluster crew-status-cluster">
          <span class="cluster-label">Crew:</span>
          <div
            class="crew-auto-pill"
            :class="{ 'codriver-active': bridgeState.peerState.participationMode === 'codriver' }"
            :title="bridgeState.peerState.participationMode === 'codriver' ? 'Shared Co-Driver mode active (in cockpit). Exit car to return to 2-Car.' : '2-Car Competition active. Walk up and enter partner\'s car to activate Co-Driver!'"
          >
            <span class="pill-dot"></span>
            <span class="pill-title">{{ bridgeState.peerState.participationMode === 'codriver' ? 'Shared Co-Driver' : '2-Car Duel' }}</span>
            <span class="pill-hint">{{ bridgeState.peerState.participationMode === 'codriver' ? '(In Cockpit)' : '(Enter partner car for Co-Driver)' }}</span>
          </div>
        </div>

        <div class="control-cluster">
          <span class="cluster-label">Clock:</span>
          <button
            class="bng-seg-btn"
            :class="{ active: bridgeState.peerState.launchMode === 'wrc_staggered' }"
            bng-nav-item
            v-bng-on-ui-nav:ok.asMouse.focusRequired
            v-bng-sound-class="'bng_click_hover_generic'"
            @click="setLaunchMode('wrc_staggered')"
            title="WRC staggered start with 60s offset"
          >
            WRC +{{ bridgeState.peerState.staggerSlotSeconds || 60 }}s
          </button>
          <button
            class="bng-seg-btn"
            :class="{ active: bridgeState.peerState.launchMode === 'simultaneous_ghost' }"
            bng-nav-item
            v-bng-on-ui-nav:ok.asMouse.focusRequired
            v-bng-sound-class="'bng_click_hover_generic'"
            @click="setLaunchMode('simultaneous_ghost')"
            title="Simultaneous green light release"
          >
            Simultaneous
          </button>
        </div>
      </div>
    </header>

    <!-- ACTIVE CREW REQUEST BANNER (Pre-Event Co-Pilot / Driver Pairing) -->
    <section v-if="crewRequest" class="crew-request-banner" :class="{ 'is-sender': crewRequest.isSender }">
      <div class="request-icon" aria-hidden="true">
        <span v-if="crewRequest.type === 'ask_copilot'">📋</span>
        <span v-else-if="crewRequest.type === 'invite_copilot'">🎙️</span>
        <span v-else-if="crewRequest.type === 'challenge_driver'">🏎️</span>
        <span v-else>🔄</span>
      </div>

      <div class="request-details" v-if="!crewRequest.isSender">
        <span class="request-kicker">PRE-EVENT CREW REQUEST</span>
        <div class="request-message">
          <strong>{{ crewRequest.fromPlayerName }}</strong>
          <span v-if="crewRequest.type === 'ask_copilot'"> wants to be your <strong>Co-Pilot</strong> (read roadbook in passenger seat).</span>
          <span v-else-if="crewRequest.type === 'invite_copilot'"> invited you to <strong>Co-Pilot</strong> for them in the upcoming stage!</span>
          <span v-else-if="crewRequest.type === 'challenge_driver'"> challenged you to a <strong>2-Car Rally Duel</strong>!</span>
          <span v-else-if="crewRequest.type === 'swap_roles'"> asked to swap Driver &amp; Co-Driver seats!</span>
        </div>
        <span class="request-timer">Expires in {{ crewRequest.remainingSec || 30 }}s · Press Alt+A to Accept or Alt+D to Decline</span>
      </div>

      <div class="request-details" v-else>
        <span class="request-kicker">INVITATION SENT</span>
        <div class="request-message">
          <span>Waiting for <strong>{{ crewRequest.toPlayerName }}</strong> to accept your </span>
          <strong v-if="crewRequest.type === 'ask_copilot'">Co-Pilot Request</strong>
          <strong v-else-if="crewRequest.type === 'invite_copilot'">Co-Driver Invite</strong>
          <strong v-else-if="crewRequest.type === 'challenge_driver'">2-Car Rally Challenge</strong>
          <strong v-else>Role Swap</strong>...
        </div>
        <span class="request-timer">Waiting for response ({{ crewRequest.remainingSec || 30 }}s remaining)</span>
      </div>

      <div class="request-actions">
        <template v-if="!crewRequest.isSender">
          <button
            class="btn-accept-crew"
            bng-nav-item
            v-bng-on-ui-nav:ok.asMouse.focusRequired
            v-bng-sound-class="'bng_click_generic'"
            @click="respondCrewRequest(true)"
          >
            Accept &amp; Pair Crew
          </button>
          <button
            class="btn-decline-crew"
            bng-nav-item
            v-bng-on-ui-nav:ok.asMouse.focusRequired
            @click="respondCrewRequest(false)"
          >
            Decline
          </button>
        </template>
        <template v-else>
          <button
            class="btn-cancel"
            bng-nav-item
            v-bng-on-ui-nav:ok.asMouse.focusRequired
            @click="cancelCrewRequest"
          >
            Cancel Request
          </button>
        </template>
      </div>
    </section>

    <!-- STAGE READY-CHECK BANNER -->
    <section v-else-if="pendingProposal" class="ready-check-banner" :class="{ proposer: isProposer }">
      <div class="ready-info" v-if="isProposer">
        <span class="ready-kicker proposer">
          {{ pendingProposal.actionType === "start_staged" ? "START READY CHECK" : "STAGE PROPOSED" }}
        </span>
        <span>
          {{ pendingProposal.actionType === "start_staged" ? "Waiting for partner to confirm Ready to launch" : "Waiting for partner to accept stage" }}
        </span>
        <strong>{{ pendingProposal.title }}</strong>
        <span class="ready-meta">
          ({{ pendingProposal.levelName || "auto-map" }} ·
          {{ pendingProposal.vehicleMode === "stage_preset_car" ? "Stage Preset Car" : "Own MP Car" }})
        </span>
      </div>
      <div class="ready-info" v-else>
        <span class="ready-kicker">
          {{ pendingProposal.actionType === "start_staged" ? "READY TO START RALLY" : "2P RALLY INVITE" }}
        </span>
        <strong>{{ pendingProposal.proposerName }}</strong>
        <span>
          {{ pendingProposal.actionType === "start_staged" ? "is starting staged event" : "invited you to race" }}
        </span>
        <strong>{{ pendingProposal.title }}</strong>
        <span class="ready-meta">
          ({{ pendingProposal.levelName || "auto-map" }} ·
          {{ pendingProposal.vehicleMode === "stage_preset_car" ? "Stage Preset Car" : "Own MP Car" }})
        </span>
      </div>
      <div class="ready-actions">
        <template v-if="!isProposer">
          <button
            class="btn-accept"
            bng-nav-item
            v-bng-on-ui-nav:ok.asMouse.focusRequired
            v-bng-sound-class="'bng_click_generic'"
            @click="respondProposal(true)"
          >
            Accept &amp; Ready
          </button>
          <button
            class="btn-decline"
            bng-nav-item
            v-bng-on-ui-nav:ok.asMouse.focusRequired
            @click="respondProposal(false)"
          >
            Decline
          </button>
        </template>
        <button
          v-else
          class="btn-cancel"
          bng-nav-item
          v-bng-on-ui-nav:ok.asMouse.focusRequired
          @click="cancelProposal"
        >
          Cancel
        </button>
      </div>
    </section>

    <!-- PRE-EVENT FREEROAM MINGLE & ROUTE PREP BANNER -->
    <section
      v-else-if="stagedMission && bridgeState.peerState.status === 'FREEROAM_STAGED'"
      class="staged-freeroam-banner"
    >
      <div class="ready-info" v-if="isStagedProposer">
        <span class="staged-kicker">PRE-EVENT FREEROAM MINGLE &amp; ROUTE SCOUTING</span>
        <span>Staged on <strong>{{ stagedMission.levelName }}</strong>:</span>
        <strong>{{ stagedMission.title }}</strong>
        <span class="ready-meta">
          Both cars active in Freeroam &amp; notes pre-loaded. Scout route, test vehicles, or stamp custom notes. Click Start when ready!
        </span>
      </div>
      <div class="ready-info" v-else>
        <span class="staged-kicker">PRE-EVENT FREEROAM MINGLE &amp; ROUTE SCOUTING</span>
        <span>Staged on <strong>{{ stagedMission.levelName }}</strong>:</span>
        <strong>{{ stagedMission.title }}</strong>
        <span class="ready-meta">
          Freeroam route scouting active. Mingle with your crew until <strong>{{ stagedMission.proposerName || "Host" }}</strong> starts the event (or type <code>/start</code>).
        </span>
      </div>
            <div class="startline-spawn-cluster">
        <span class="cluster-label">START POINT SPAWN:</span>
        <button
          type="button"
          class="btn-startline-spawn"
          :class="{ active: currentSpawnMode === 'random_rally' }"
          @click="spawnAtStart('random_rally')"
          title="Spawn an authentic rally-prepped car at the stage start point"
        >
          Random Rally Car
        </button>
        <button
          type="button"
          class="btn-startline-spawn"
          :class="{ active: currentSpawnMode === 'on_foot' }"
          @click="spawnAtStart('on_foot')"
          title="Spawn character on foot at start point to inspect track or co-drive"
        >
          On Foot
        </button>
        <button
          type="button"
          class="btn-startline-spawn"
          :class="{ active: currentSpawnMode === 'current_car' }"
          @click="spawnAtStart('current_car')"
          title="Teleport your current vehicle directly to the stage start point"
        >
          Teleport Car
        </button>
      </div>

      <div class="ready-actions" v-if="isStagedProposer">
        <button
          class="btn-start-staged"
          bng-nav-item
          v-bng-on-ui-nav:ok.asMouse.focusRequired
          v-bng-sound-class="'bng_click_generic'"
          @click="startStagedEvent"
        >
          Start Staged Event
        </button>
        <button
          class="btn-cancel"
          bng-nav-item
          v-bng-on-ui-nav:ok.asMouse.focusRequired
          @click="clearStagedEvent"
        >
          Clear Staged
        </button>
      </div>
    </section>

    <!-- CONNECTED PLAYERS & PRE-EVENT CREW ASSEMBLY (NEW CORE SECTION) -->
    <section class="crew-assembly-section">
      <div class="category-header">
        <span class="category-slash" aria-hidden="true"></span>
        <div class="crew-header-text">
          <h3 class="category-title">Connected Players &amp; Crew Assembly</h3>
          <span class="category-hint">
            Pair up with connected drivers before launching. Ask to Co-Pilot, invite partners, or challenge to a 2-Car Duel.
          </span>
        </div>
        <div class="category-rule"></div>
      </div>

      <!-- Active Crew Slots (Slot 1 & Slot 2) -->
      <div class="crew-slots-grid">
        <!-- Slot 1: Car 1 Driver -->
        <div class="crew-slot-card" :class="{ 'has-player': driverSlotPlayer, 'is-you': isCurrentPlayer(driverSlotPlayer) }">
          <div class="slot-badge">SLOT 1 · DRIVER</div>
          <div class="slot-body" v-if="driverSlotPlayer">
            <div class="player-avatar-badge">🏎️</div>
            <div class="slot-player-meta">
              <span class="player-name">
                {{ driverSlotPlayer.name }}
                <span class="you-tag" v-if="isCurrentPlayer(driverSlotPlayer)">(YOU)</span>
              </span>
              <span class="player-sub">
                Ping: {{ driverSlotPlayer.pingMs || 15 }}ms · Ready: {{ driverSlotPlayer.isReady ? 'YES' : 'STAGING' }}
              </span>
            </div>
            <div class="slot-actions" v-if="isCurrentPlayer(driverSlotPlayer)">
              <button class="bng-sub-btn" @click="swapSlots" title="Swap seats with Slot 2">Swap Role</button>
              <button class="bng-sub-btn danger" @click="leaveSlot" title="Step down to Paddock">Leave Slot</button>
            </div>
          </div>
          <div class="slot-empty" v-else>
            <span>Empty Driver Slot</span>
            <button class="bng-sub-btn highlight" @click="claimDriverSlot">Take Driver Seat</button>
          </div>
        </div>

        <!-- Slot 2: Co-Driver OR 2nd Driver -->
        <div class="crew-slot-card" :class="{ 'has-player': slot2Player, 'is-you': isCurrentPlayer(slot2Player) }">
          <div class="slot-badge">
            SLOT 2 · {{ isCoDriverMode ? 'CO-PILOT (ROADBOOK)' : 'RIVAL DRIVER (CAR 2)' }}
          </div>
          <div class="slot-body" v-if="slot2Player">
            <div class="player-avatar-badge">{{ isCoDriverMode ? '🎙️' : '🏎️' }}</div>
            <div class="slot-player-meta">
              <span class="player-name">
                {{ slot2Player.name }}
                <span class="you-tag" v-if="isCurrentPlayer(slot2Player)">(YOU)</span>
              </span>
              <span class="player-sub">
                Ping: {{ slot2Player.pingMs || 18 }}ms ·
                Role: {{ isCoDriverMode ? 'Co-Pilot (In-Car Roadbook)' : 'Driver 2 (Competitor)' }}
              </span>
            </div>
            <div class="slot-actions" v-if="isCurrentPlayer(slot2Player)">
              <button class="bng-sub-btn" @click="swapSlots" title="Swap seats with Driver">Swap Role</button>
              <button class="bng-sub-btn danger" @click="leaveSlot" title="Step down to Paddock">Leave Slot</button>
            </div>
          </div>
          <div class="slot-empty" v-else>
            <span>{{ isCoDriverMode ? 'No Co-Pilot Paired' : 'No 2nd Driver Paired' }}</span>
            <span class="empty-hint">Use Paddock list below to Ask or Invite</span>
          </div>
        </div>
      </div>

      <!-- Paddock / Connected Players List -->
      <div class="paddock-table-wrap">
        <div class="paddock-table-header">
          <span>Connected Drivers on Server ({{ connectedList.length }})</span>
          <span class="paddock-help">Click any action button to request pairing before the event</span>
        </div>
        <div class="paddock-list">
          <div
            v-for="p in connectedList"
            :key="p.playerId"
            class="paddock-row"
            :class="{ 'is-me': isCurrentPlayer(p), 'in-slot': p.slot }"
          >
            <div class="paddock-col-player">
              <div class="status-dot" :class="{ active: p.isReady, idle: !p.isReady }"></div>
              <div class="player-text">
                <span class="row-name">
                  {{ p.name }}
                  <span class="you-pill" v-if="isCurrentPlayer(p)">You</span>
                </span>
                <span class="row-veh">
                  Role: <strong>{{ formatRole(p.role) }}</strong> · Latency: {{ p.pingMs || 15 }}ms
                </span>
              </div>
            </div>

            <div class="paddock-col-badge">
              <span class="role-chip" :class="p.role ? p.role.toLowerCase() : 'paddock'">
                {{ formatRole(p.role) }}
              </span>
            </div>

            <div class="paddock-col-actions">
              <!-- If viewing another player and not in a pending request -->
              <template v-if="!isCurrentPlayer(p)">
                <!-- Ask to Co-Pilot for this player (if they are driver) -->
                <button
                  v-if="p.role === 'DRIVER_1'"
                  class="action-pill-btn copilot"
                  @click="requestCrew('ask_copilot', p.playerId)"
                  title="Request to sit in their passenger seat and call pacenotes"
                >
                  🎙️ Ask to Co-Pilot
                </button>

                <!-- Invite this player to be your Co-Pilot (if you are Driver 1) -->
                <button
                  v-if="amIDriver1 && p.role === 'PADDOCK'"
                  class="action-pill-btn invite"
                  @click="requestCrew('invite_copilot', p.playerId)"
                  title="Invite this player to be your Co-Pilot"
                >
                  📋 Invite as Co-Pilot
                </button>

                <!-- Challenge this player to 2-Car Duel -->
                <button
                  v-if="p.role !== 'DRIVER_1'"
                  class="action-pill-btn challenge"
                  @click="requestCrew('challenge_driver', p.playerId)"
                  title="Challenge this player to race head-to-head"
                >
                  🏎️ Challenge to 2-Car
                </button>
              </template>

              <!-- If this is the local player and in a slot -->
              <template v-else-if="p.slot">
                <button class="action-pill-btn danger" @click="leaveSlot">
                  Step Down to Paddock
                </button>
              </template>
              <template v-else>
                <span class="status-note">Browsing Paddock</span>
              </template>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- RALLY LOOP CATALOG -->
    <section class="rally-category-section" v-if="rallyLoops.length > 0">
      <div class="category-header">
        <span class="category-slash" aria-hidden="true"></span>
        <h3 class="category-title">Rally Loops (Multi-Lap / Endurance)</h3>
        <div class="category-rule"></div>
      </div>
      <div class="rally-card-grid">
        <button
          v-for="loop in rallyLoops"
          :key="loop.id"
          class="rally-stage-card"
          bng-nav-item
          v-bng-on-ui-nav:ok.asMouse.focusRequired
          v-bng-sound-class="'bng_click_hover_generic'"
          @click="proposeMission(loop.id)"
        >
          <div class="card-thumb">
            <img
              draggable="false"
              :src="resolveThumb(loop.previewFile)"
              :alt="loop.name"
              @error="onThumbError"
            />
            <span class="card-map-tag">{{ loop.levelName }}</span>
            <span class="card-surface-tag">Gravel</span>
          </div>
          <div class="card-footer">
            <div class="card-title-group">
              <span class="card-name">{{ loop.name }}</span>
              <span class="card-desc">Synced Stage · Full Solid Collisions</span>
            </div>
            <span class="card-share-icon" title="2-Player Network Synced">&#9741;</span>
          </div>
        </button>
      </div>
    </section>

    <!-- RALLY STAGE CATALOG -->
    <section class="rally-category-section" v-if="rallyStages.length > 0">
      <div class="category-header">
        <span class="category-slash" aria-hidden="true"></span>
        <h3 class="category-title">Rally Special Stages (Point-to-Point SS)</h3>
        <div class="category-rule"></div>
      </div>
      <div class="rally-card-grid">
        <button
          v-for="stage in rallyStages"
          :key="stage.id"
          class="rally-stage-card"
          bng-nav-item
          v-bng-on-ui-nav:ok.asMouse.focusRequired
          v-bng-sound-class="'bng_click_hover_generic'"
          @click="proposeMission(stage.id)"
        >
          <div class="card-thumb">
            <img
              draggable="false"
              :src="resolveThumb(stage.previewFile)"
              :alt="stage.name"
              @error="onThumbError"
            />
            <span class="card-map-tag">{{ stage.levelName }}</span>
            <span class="card-surface-tag">Mixed Surface</span>
          </div>
          <div class="card-footer">
            <div class="card-title-group">
              <span class="card-name">{{ stage.name }}</span>
              <span class="card-desc">Pacenotes Ready · Timed Splits</span>
            </div>
            <span class="card-share-icon" title="2-Player Network Synced">&#9741;</span>
          </div>
        </button>
      </div>
    </section>

    <!-- FOOTER TOOLS & SHORTCUTS -->
    <footer class="rally-tools-footer" v-if="bridgeState.unlockNativeRallyFeatures">
      <div class="native-tools-row">
        <button class="bng-tool-btn" bng-nav-item @click="toggleAiVoice">
          {{ bridgeState.aiVoiceMutedKeepOff ? "AI Voice: OFF (Co-Driver Only)" : "AI Voice: ON" }}
        </button>
        <button class="bng-tool-btn" bng-nav-item @click="toggleRecce">
          {{ bridgeState.peerState.recceEnabled ? "Stop 2P Recce" : "2-Player Recce App" }}
        </button>
        <button class="bng-tool-btn" bng-nav-item @click="nudgeCalls(true)">Calls -0.1s</button>
        <button class="bng-tool-btn" bng-nav-item @click="nudgeCalls(false)">Calls +0.1s</button>
        <button class="bng-tool-btn" bng-nav-item @click="toggleClock3D">
          Clock: {{ (bridgeState.countdownDisplay || "3d").toUpperCase() }}
        </button>
        <button class="bng-tool-btn danger" bng-nav-item @click="stopRally">Stop Rally</button>
      </div>
    </footer>
  </div>
</template>

<script setup>
import { ref, reactive, computed, onMounted, onUnmounted } from "vue"
import { useBridge } from "@/bridge"
import { useEvents } from "@/services/events"
import { vBngOnUiNav, vBngSoundClass } from "@/common/directives"
import { getAssetURL } from "@/utils"

defineOptions({ name: "NativeRallyPauseTab" })

const { lua } = useBridge()
const events = useEvents()

const selectedVehicleMode = ref("own_mp_car")

const bridgeState = reactive({
  rttMs: 0,
  aiVoiceMutedKeepOff: false,
  defaultVehicleChoice: "host_chooses",
  countdownDisplay: "3d",
  unlockNativeRallyFeatures: true,
  maps: [],
  missions: [],
  peerState: {
    status: "FREEROAM",
    currentLevel: "",
    recceEnabled: false,
    participationMode: "two_car",
    launchMode: "wrc_staggered",
    staggerSlotSeconds: 60,
    yourPlayerId: -1,
    hasPendingProposal: false,
    pendingProposal: false,
    hasStagedMission: false,
    stagedMission: false,
    connectedPlayers: [],
    pendingCrewRequest: false
  }
})

// Connected Players list
const connectedList = computed(() => {
  const pList = bridgeState.peerState?.connectedPlayers
  if (Array.isArray(pList) && pList.length > 0) {
    return pList
  }
  // Fallback to peer list if connectedPlayers is not populated yet
  const peers = bridgeState.peerState?.peers || []
  return peers.map(p => ({
    playerId: p.playerId,
    name: p.name || `Player ${p.playerId}`,
    role: p.role === "CO-DRIVER" ? "CODRIVER" : (p.slot === 1 ? "DRIVER_1" : "DRIVER_2"),
    slot: p.slot,
    pingMs: p.rttMs || 15,
    isReady: p.staged || false
  }))
})

const myPlayerId = computed(() => Number(bridgeState.peerState?.yourPlayerId))

function isCurrentPlayer(player) {
  if (!player) return false
  return Number(player.playerId) === myPlayerId.value
}

const driverSlotPlayer = computed(() =>
  connectedList.value.find(p => p.slot === 1 || p.role === "DRIVER_1")
)

const slot2Player = computed(() =>
  connectedList.value.find(p => p.slot === 2 || p.role === "CODRIVER" || p.role === "DRIVER_2")
)

const isCoDriverMode = computed(() =>
  bridgeState.peerState?.participationMode === "codriver"
)

const amIDriver1 = computed(() => {
  const me = connectedList.value.find(p => isCurrentPlayer(p))
  return me && (me.slot === 1 || me.role === "DRIVER_1")
})

const sessionStatusLabel = computed(() => {
  const st = bridgeState.peerState?.status
  if (st === "STAGE_ACTIVE" || st === "LOOP_ACTIVE") return "RALLY ACTIVE"
  if (st === "READY_CHECK") return "READY CHECK"
  if (st === "FREEROAM_STAGED") return "ROUTE PREP & MINGLE"
  if (bridgeState.peerState?.pendingCrewRequest) return "CREW FORMING"
  return "PADDOCK FREEROAM"
})

const sessionStatusClass = computed(() => {
  const st = bridgeState.peerState?.status
  if (st === "STAGE_ACTIVE" || st === "LOOP_ACTIVE") return "active"
  if (st === "READY_CHECK") return "ready-check"
  if (st === "FREEROAM_STAGED") return "staged"
  return "freeroam"
})

const crewRequest = computed(() => {
  const cr = bridgeState.peerState?.pendingCrewRequest
  if (!cr || typeof cr !== "object" || !cr.id) return null
  return cr
})

const pendingProposal = computed(() => {
  const ps = bridgeState.peerState
  const p = ps?.pendingProposal
  if (!p || typeof p !== "object" || !p.id || ps?.hasPendingProposal === false) return null
  return p
})

const isProposer = computed(() => {
  const p = pendingProposal.value
  if (!p) return false
  if (p.isProposer === true) return true
  const myId = myPlayerId.value
  if (myId !== undefined && myId !== -1 && p.proposerId !== undefined) {
    return Number(p.proposerId) === Number(myId)
  }
  return false
})

const stagedMission = computed(() => {
  const ps = bridgeState.peerState
  const s = ps?.stagedMission
  if (!s || typeof s !== "object" || !s.missionId || ps?.hasStagedMission === false) return null
  return s
})

const isStagedProposer = computed(() => {
  const s = stagedMission.value
  if (!s) return false
  if (s.isProposer === true) return true
  const myId = myPlayerId.value
  if (myId !== undefined && myId !== -1 && s.proposerId !== undefined) {
    return Number(s.proposerId) === Number(myId)
  }
  return false
})

const rallyLoops = computed(() =>
  (bridgeState.missions || []).filter(m => m.missionType === "rallyLoop"))

const rallyStages = computed(() =>
  (bridgeState.missions || []).filter(m => m.missionType === "rallyStage"))

function formatRole(role) {
  if (role === "DRIVER_1") return "Car 1 Driver"
  if (role === "CODRIVER") return "Co-Pilot"
  if (role === "DRIVER_2") return "Car 2 Driver"
  return "Paddock Driver"
}

function resolveThumb(path) {
  if (!path) return getAssetURL("images/mainmenu/default_mission.jpg")
  return path.startsWith("/") ? "local://local" + path : getAssetURL(path)
}

function onThumbError(ev) {
  if (ev && ev.target) {
    ev.target.style.opacity = "0.25"
  }
}

function setVehicleMode(mode) {
  selectedVehicleMode.value = mode
  lua.extensions.nativeRallyBridge.vueSetVehicleMode(mode)
}

function setCrewMode(mode) {
  lua.extensions.nativeRallyBridge.vueSetMode(mode)
}

function setLaunchMode(mode) {
  lua.extensions.nativeRallyBridge.vueSetLaunchMode(mode)
}

function requestCrew(type, targetPlayerId) {
  if (lua.extensions.nativeRallyBridge.vueRequestCrew) {
    lua.extensions.nativeRallyBridge.vueRequestCrew(type, targetPlayerId)
  }
}

function respondCrewRequest(accept) {
  const cr = crewRequest.value
  if (cr && lua.extensions.nativeRallyBridge.vueRespondCrewRequest) {
    lua.extensions.nativeRallyBridge.vueRespondCrewRequest(cr.id, accept)
  }
}

function cancelCrewRequest() {
  if (lua.extensions.nativeRallyBridge.vueCancelCrewRequest) {
    lua.extensions.nativeRallyBridge.vueCancelCrewRequest()
  }
}

function leaveSlot() {
  if (lua.extensions.nativeRallyBridge.vueLeaveCrewSlot) {
    lua.extensions.nativeRallyBridge.vueLeaveCrewSlot()
  }
}

function claimDriverSlot() {
  lua.extensions.nativeRallyBridge.vueSwapSlots()
}

function swapSlots() {
  lua.extensions.nativeRallyBridge.vueSwapSlots()
}

function proposeMission(missionId) {
  lua.extensions.nativeRallyBridge.vueProposeMission(
    missionId,
    selectedVehicleMode.value,
    bridgeState.peerState.participationMode,
    bridgeState.peerState.launchMode
  )
}

function startStagedEvent() {
  lua.extensions.nativeRallyBridge.vueStartStagedEvent(selectedVehicleMode.value)
}

function clearStagedEvent() {
  lua.extensions.nativeRallyBridge.vueClearStagedEvent()
}

function respondProposal(accept) {
  lua.extensions.nativeRallyBridge.vueRespondProposal(accept)
}

const currentSpawnMode = computed(() => {
  return bridgeState.freeroamSpawnMode || "random_rally"
})

function spawnAtStart(mode) {
  if (lua.extensions.nativeRallyBridge && lua.extensions.nativeRallyBridge.vueSpawnAtStartLine) {
    lua.extensions.nativeRallyBridge.vueSpawnAtStartLine(mode)
  }
}

function cancelProposal() {
  lua.extensions.nativeRallyBridge.vueCancelProposal()
}

function toggleAiVoice() {
  lua.extensions.nativeRallyBridge.vueToggleAiVoicepack()
}

function toggleRecce() {
  lua.extensions.nativeRallyBridge.vueToggleRecce()
}

function nudgeCalls(earlier) {
  lua.extensions.nativeRallyBridge.vueNudgeCodriverTiming(earlier)
}

function toggleClock3D() {
  lua.extensions.nativeRallyBridge.vueToggleCountdownDisplay()
}

function stopRally() {
  lua.extensions.nativeRallyBridge.vueStopMission()
}

onMounted(() => {
  events.on("NativeRallyVueState", (data) => {
    if (!data) return
    Object.assign(bridgeState, data)
    if (data.vehicleMode) {
      selectedVehicleMode.value = data.vehicleMode
    }
  })
  lua.extensions.nativeRallyBridge.vueRequestState()
})

onUnmounted(() => {
  events.off("NativeRallyVueState")
})
</script>

<style lang="scss" scoped>
.native-rally-pause-view {
  display: flex;
  flex-direction: column;
  gap: 1.25rem;
  padding: 1.25rem 1.75rem;
  color: var(--bng-off-white, #f8fafc);
  background: rgba(var(--bng-cool-gray-900-rgb, 15, 23, 42), 0.88);
  backdrop-filter: blur(12px);
  height: 100%;
  overflow-y: auto;
  font-family: "Noto Sans", sans-serif;
}

.rally-pause-toolbar {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  justify-content: space-between;
  gap: 1rem;
  padding-bottom: 0.85rem;
  border-bottom: 1px solid rgba(255, 255, 255, 0.14);
}

.toolbar-brand {
  display: flex;
  align-items: center;
  gap: 0.75rem;
}

.slanted-mark,
.category-slash {
  display: inline-block;
  width: 0.5rem;
  height: 1.4rem;
  background: var(--bng-orange-500, #ff6600);
  transform: skewX(-18deg);
}

.title-with-pill {
  display: flex;
  align-items: center;
  gap: 0.75rem;
}

.toolbar-heading {
  margin: 0;
  font-size: 1.25rem;
  font-style: italic;
  font-weight: 800;
  letter-spacing: -0.02em;
}

.status-pill {
  padding: 0.2rem 0.6rem;
  font-size: 0.72rem;
  font-weight: 700;
  border-radius: 9999px;
  text-transform: uppercase;
  letter-spacing: 0.05em;

  &.freeroam {
    background: rgba(255, 255, 255, 0.15);
    color: #e2e8f0;
  }
  &.staged {
    background: rgba(234, 179, 8, 0.25);
    color: #facc15;
    border: 1px solid rgba(234, 179, 8, 0.4);
  }
  &.ready-check {
    background: rgba(249, 115, 22, 0.25);
    color: #fb923c;
    border: 1px solid rgba(249, 115, 22, 0.4);
  }
  &.active {
    background: rgba(34, 197, 94, 0.25);
    color: #4ade80;
    border: 1px solid rgba(34, 197, 94, 0.4);
  }
}

.toolbar-sub {
  font-size: 0.78rem;
  color: rgba(255, 255, 255, 0.7);
}

.toolbar-controls {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 0.85rem;
}

.control-cluster {
  display: inline-flex;
  align-items: center;
  gap: 0.35rem;
  background: rgba(0, 0, 0, 0.35);
  padding: 0.25rem 0.45rem;
  border-radius: 0.35rem;
}

.cluster-label {
  font-size: 0.74rem;
  text-transform: uppercase;
  font-weight: 700;
  color: rgba(255, 255, 255, 0.6);
  margin-right: 0.2rem;
}

.bng-seg-btn {
  padding: 0.3rem 0.65rem;
  background: transparent;
  color: rgba(255, 255, 255, 0.75);
  border: 1px solid transparent;
  border-radius: 0.25rem;
  font-size: 0.78rem;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.15s ease;

  &:hover {
    color: #ffffff;
    background: rgba(255, 255, 255, 0.08);
  }

  &.active {
    background: var(--bng-orange-500, #ff6600);
    color: #ffffff;
    font-weight: 700;
    box-shadow: 0 0 10px rgba(255, 102, 0, 0.4);
  }
}

/* CREW REQUEST BANNER */
.crew-request-banner {
  display: flex;
  align-items: center;
  gap: 1rem;
  padding: 0.9rem 1.25rem;
  background: linear-gradient(90deg, rgba(30, 58, 138, 0.85) 0%, rgba(15, 23, 42, 0.95) 100%);
  border: 2px solid #3b82f6;
  border-radius: 0.45rem;
  box-shadow: 0 4px 18px rgba(59, 130, 246, 0.25);

  &.is-sender {
    background: linear-gradient(90deg, rgba(55, 65, 81, 0.85) 0%, rgba(15, 23, 42, 0.95) 100%);
    border-color: #9ca3af;
  }
}

.request-icon {
  font-size: 1.8rem;
  display: flex;
  align-items: center;
  justify-content: center;
}

.request-details {
  display: flex;
  flex-direction: column;
  gap: 0.25rem;
  flex: 1;
}

.request-kicker {
  font-size: 0.7rem;
  font-weight: 800;
  letter-spacing: 0.08em;
  color: #60a5fa;
  text-transform: uppercase;
}

.request-message {
  font-size: 0.92rem;
  color: #ffffff;
}

.request-timer {
  font-size: 0.76rem;
  color: #93c5fd;
}

.request-actions {
  display: flex;
  gap: 0.6rem;
}

.btn-accept-crew {
  background: #22c55e;
  color: #ffffff;
  padding: 0.5rem 1.1rem;
  border-radius: 0.35rem;
  font-size: 0.85rem;
  font-weight: 700;
  border: none;
  cursor: pointer;
  transition: background 0.15s;

  &:hover {
    background: #16a34a;
  }
}

.btn-decline-crew {
  background: rgba(239, 68, 68, 0.2);
  color: #f87171;
  border: 1px solid rgba(239, 68, 68, 0.5);
  padding: 0.5rem 0.9rem;
  border-radius: 0.35rem;
  font-size: 0.85rem;
  font-weight: 600;
  cursor: pointer;

  &:hover {
    background: rgba(239, 68, 68, 0.35);
  }
}

/* READY CHECK & STAGED BANNER */
.ready-check-banner,
.staged-freeroam-banner {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 1rem;
  padding: 0.9rem 1.25rem;
  border-radius: 0.45rem;
}

.ready-check-banner {
  background: linear-gradient(90deg, rgba(194, 65, 12, 0.85) 0%, rgba(15, 23, 42, 0.9) 100%);
  border: 1px solid #f97316;
}

.staged-freeroam-banner {
  background: linear-gradient(90deg, rgba(161, 98, 7, 0.85) 0%, rgba(15, 23, 42, 0.9) 100%);
  border: 1px solid #eab308;
}

.ready-info {
  display: flex;
  flex-direction: column;
  gap: 0.2rem;
}

.ready-kicker,
.staged-kicker {
  font-size: 0.72rem;
  font-weight: 800;
  letter-spacing: 0.08em;
  text-transform: uppercase;
  color: #fde047;
}

.ready-meta {
  font-size: 0.78rem;
  color: rgba(255, 255, 255, 0.8);
}

.ready-actions {
  display: flex;
  gap: 0.6rem;
}

.btn-accept,
.btn-start-staged {
  background: var(--bng-orange-500, #ff6600);
  color: #ffffff;
  padding: 0.5rem 1.15rem;
  border-radius: 0.35rem;
  font-size: 0.85rem;
  font-weight: 700;
  border: none;
  cursor: pointer;

  &:hover {
    background: #e65c00;
  }
}

.btn-decline,
.btn-cancel {
  background: rgba(255, 255, 255, 0.1);
  color: #ffffff;
  padding: 0.5rem 0.9rem;
  border-radius: 0.35rem;
  font-size: 0.85rem;
  font-weight: 600;
  border: 1px solid rgba(255, 255, 255, 0.2);
  cursor: pointer;
}

/* CREW ASSEMBLY SECTION */
.crew-assembly-section {
  display: flex;
  flex-direction: column;
  gap: 0.85rem;
}

.crew-header-text {
  display: flex;
  flex-direction: column;
  gap: 0.15rem;
}

.category-header {
  display: flex;
  align-items: center;
  gap: 0.65rem;
}

.category-title {
  margin: 0;
  font-size: 1.05rem;
  font-weight: 700;
  font-style: italic;
  text-transform: uppercase;
  letter-spacing: 0.02em;
}

.category-hint {
  font-size: 0.74rem;
  color: rgba(255, 255, 255, 0.65);
}

.category-rule {
  flex: 1;
  height: 1px;
  background: rgba(255, 255, 255, 0.12);
}

.crew-slots-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
  gap: 1rem;
}

.crew-slot-card {
  background: rgba(0, 0, 0, 0.35);
  border: 1px solid rgba(255, 255, 255, 0.12);
  border-radius: 0.45rem;
  padding: 0.85rem;
  display: flex;
  flex-direction: column;
  gap: 0.6rem;

  &.is-you {
    border-color: rgba(255, 102, 0, 0.6);
    background: rgba(255, 102, 0, 0.08);
  }
}

.slot-badge {
  font-size: 0.68rem;
  font-weight: 800;
  letter-spacing: 0.06em;
  color: var(--bng-orange-500, #ff6600);
}

.slot-body {
  display: flex;
  align-items: center;
  gap: 0.75rem;
}

.player-avatar-badge {
  font-size: 1.6rem;
  width: 2.4rem;
  height: 2.4rem;
  background: rgba(255, 255, 255, 0.08);
  border-radius: 0.35rem;
  display: flex;
  align-items: center;
  justify-content: center;
}

.slot-player-meta {
  display: flex;
  flex-direction: column;
  gap: 0.15rem;
  flex: 1;
}

.player-name {
  font-weight: 700;
  font-size: 0.95rem;
}

.you-tag {
  color: var(--bng-orange-500, #ff6600);
  font-size: 0.75rem;
  margin-left: 0.35rem;
}

.player-sub {
  font-size: 0.74rem;
  color: rgba(255, 255, 255, 0.65);
}

.slot-empty {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 0.75rem;
  color: rgba(255, 255, 255, 0.5);
  font-size: 0.85rem;
  gap: 0.35rem;
}

.empty-hint {
  font-size: 0.72rem;
  color: rgba(255, 255, 255, 0.4);
}

.slot-actions {
  display: flex;
  flex-direction: column;
  gap: 0.35rem;
}

.bng-sub-btn {
  padding: 0.3rem 0.65rem;
  background: rgba(255, 255, 255, 0.08);
  border: 1px solid rgba(255, 255, 255, 0.15);
  border-radius: 0.25rem;
  color: #ffffff;
  font-size: 0.74rem;
  font-weight: 600;
  cursor: pointer;

  &:hover {
    background: rgba(255, 255, 255, 0.16);
  }

  &.highlight {
    background: var(--bng-orange-500, #ff6600);
    border-color: var(--bng-orange-500, #ff6600);
  }

  &.danger {
    color: #f87171;
    border-color: rgba(239, 68, 68, 0.3);
  }
}

/* PADDOCK LIST */
.paddock-table-wrap {
  background: rgba(0, 0, 0, 0.28);
  border: 1px solid rgba(255, 255, 255, 0.1);
  border-radius: 0.45rem;
  overflow: hidden;
}

.paddock-table-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0.55rem 0.85rem;
  background: rgba(255, 255, 255, 0.04);
  font-size: 0.75rem;
  font-weight: 700;
  color: rgba(255, 255, 255, 0.75);
  border-bottom: 1px solid rgba(255, 255, 255, 0.08);
}

.paddock-help {
  font-weight: 400;
  color: rgba(255, 255, 255, 0.5);
  font-size: 0.72rem;
}

.paddock-list {
  display: flex;
  flex-direction: column;
}

.paddock-row {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0.65rem 0.85rem;
  border-bottom: 1px solid rgba(255, 255, 255, 0.05);

  &:last-child {
    border-bottom: none;
  }

  &.is-me {
    background: rgba(255, 102, 0, 0.04);
  }
}

.paddock-col-player {
  display: flex;
  align-items: center;
  gap: 0.65rem;
  min-width: 200px;
}

.status-dot {
  width: 0.55rem;
  height: 0.55rem;
  border-radius: 50%;

  &.active {
    background: #22c55e;
    box-shadow: 0 0 6px #22c55e;
  }
  &.idle {
    background: #94a3b8;
  }
}

.player-text {
  display: flex;
  flex-direction: column;
}

.row-name {
  font-weight: 700;
  font-size: 0.86rem;
}

.you-pill {
  font-size: 0.68rem;
  padding: 0.1rem 0.4rem;
  background: rgba(255, 102, 0, 0.2);
  color: var(--bng-orange-500, #ff6600);
  border-radius: 0.2rem;
  margin-left: 0.35rem;
}

.row-veh {
  font-size: 0.72rem;
  color: rgba(255, 255, 255, 0.6);
}

.role-chip {
  font-size: 0.7rem;
  font-weight: 700;
  padding: 0.2rem 0.55rem;
  border-radius: 0.25rem;
  text-transform: uppercase;

  &.driver_1 {
    background: rgba(255, 102, 0, 0.2);
    color: #ff8533;
    border: 1px solid rgba(255, 102, 0, 0.4);
  }
  &.codriver {
    background: rgba(59, 130, 246, 0.2);
    color: #93c5fd;
    border: 1px solid rgba(59, 130, 246, 0.4);
  }
  &.driver_2 {
    background: rgba(168, 85, 247, 0.2);
    color: #c084fc;
    border: 1px solid rgba(168, 85, 247, 0.4);
  }
  &.paddock {
    background: rgba(255, 255, 255, 0.08);
    color: #94a3b8;
  }
}

.paddock-col-actions {
  display: flex;
  align-items: center;
  gap: 0.45rem;
}

.action-pill-btn {
  padding: 0.35rem 0.75rem;
  border-radius: 0.3rem;
  font-size: 0.75rem;
  font-weight: 700;
  border: 1px solid transparent;
  cursor: pointer;
  transition: all 0.15s ease;

  &.copilot {
    background: rgba(59, 130, 246, 0.25);
    color: #bfdbfe;
    border-color: rgba(59, 130, 246, 0.5);

    &:hover {
      background: #3b82f6;
      color: #ffffff;
    }
  }

  &.invite {
    background: rgba(234, 179, 8, 0.25);
    color: #fde047;
    border-color: rgba(234, 179, 8, 0.5);

    &:hover {
      background: #eab308;
      color: #000000;
    }
  }

  &.challenge {
    background: rgba(168, 85, 247, 0.25);
    color: #e9d5ff;
    border-color: rgba(168, 85, 247, 0.5);

    &:hover {
      background: #a855f7;
      color: #ffffff;
    }
  }

  &.danger {
    background: rgba(239, 68, 68, 0.2);
    color: #f87171;
    border-color: rgba(239, 68, 68, 0.4);

    &:hover {
      background: #ef4444;
      color: #ffffff;
    }
  }
}

.status-note {
  font-size: 0.72rem;
  color: rgba(255, 255, 255, 0.45);
}

/* RALLY CARDS */
.rally-category-section {
  display: flex;
  flex-direction: column;
  gap: 0.75rem;
}

.rally-card-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(240px, 1fr));
  gap: 1rem;
}

.rally-stage-card {
  display: flex;
  flex-direction: column;
  background: rgba(0, 0, 0, 0.45);
  border: 1px solid rgba(255, 255, 255, 0.12);
  border-radius: 0.45rem;
  overflow: hidden;
  text-align: left;
  cursor: pointer;
  transition: transform 0.15s, border-color 0.15s;

  &:hover {
    transform: translateY(-2px);
    border-color: var(--bng-orange-500, #ff6600);
  }
}

.card-thumb {
  position: relative;
  width: 100%;
  aspect-ratio: 16 / 9;
  background: #0f172a;

  img {
    width: 100%;
    height: 100%;
    object-fit: cover;
  }
}

.card-map-tag {
  position: absolute;
  top: 0.5rem;
  left: 0.5rem;
  background: rgba(0, 0, 0, 0.75);
  font-size: 0.68rem;
  font-weight: 700;
  text-transform: uppercase;
  padding: 0.2rem 0.45rem;
  border-radius: 0.2rem;
}

.card-surface-tag {
  position: absolute;
  top: 0.5rem;
  right: 0.5rem;
  background: rgba(234, 179, 8, 0.85);
  color: #000;
  font-size: 0.65rem;
  font-weight: 800;
  text-transform: uppercase;
  padding: 0.15rem 0.4rem;
  border-radius: 0.2rem;
}

.card-footer {
  padding: 0.65rem 0.85rem;
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.card-title-group {
  display: flex;
  flex-direction: column;
}

.card-name {
  font-size: 0.85rem;
  font-weight: 700;
  color: #ffffff;
}

.card-desc {
  font-size: 0.68rem;
  color: rgba(255, 255, 255, 0.55);
}

.card-share-icon {
  font-size: 1.1rem;
  color: var(--bng-orange-500, #ff6600);
}

/* FOOTER */
.rally-tools-footer {
  padding-top: 0.75rem;
  border-top: 1px solid rgba(255, 255, 255, 0.1);
}

.native-tools-row {
  display: flex;
  flex-wrap: wrap;
  gap: 0.5rem;
}

.bng-tool-btn {
  padding: 0.35rem 0.75rem;
  background: rgba(255, 255, 255, 0.08);
  border: 1px solid rgba(255, 255, 255, 0.16);
  border-radius: 0.25rem;
  color: rgba(255, 255, 255, 0.85);
  font-size: 0.75rem;
  font-weight: 600;
  cursor: pointer;

  &:hover {
    background: rgba(255, 255, 255, 0.15);
    color: #ffffff;
  }

  &.danger {
    color: #f87171;
    border-color: rgba(239, 68, 68, 0.3);

    &:hover {
      background: rgba(239, 68, 68, 0.2);
    }
  }
}
.startline-spawn-cluster {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  margin-top: 0.6rem;
  margin-bottom: 0.6rem;
  padding: 0.4rem 0.6rem;
  background: rgba(0, 0, 0, 0.35);
  border-radius: 4px;
  border: 1px solid rgba(255, 255, 255, 0.08);

  .cluster-label {
    font-size: 0.7rem;
    font-weight: 700;
    letter-spacing: 0.05em;
    color: #94a3b8;
    margin-right: 0.25rem;
  }

  .btn-startline-spawn {
    padding: 0.3rem 0.65rem;
    font-size: 0.75rem;
    font-weight: 600;
    color: #f1f5f9;
    background: rgba(255, 255, 255, 0.08);
    border: 1px solid rgba(255, 255, 255, 0.16);
    border-radius: 3px;
    cursor: pointer;
    transition: all 0.15s ease;

    &:hover {
      background: rgba(255, 255, 255, 0.2);
      border-color: rgba(255, 255, 255, 0.3);
    }

    &.active {
      background: #2563eb;
      border-color: #3b82f6;
      color: #ffffff;
      box-shadow: 0 0 8px rgba(37, 99, 235, 0.5);
    }
  }
}
.crew-status-cluster {
  .crew-auto-pill {
    display: inline-flex;
    align-items: center;
    gap: 0.4rem;
    padding: 0.3rem 0.65rem;
    background: rgba(15, 23, 42, 0.6);
    border: 1px solid rgba(255, 255, 255, 0.15);
    border-radius: 4px;
    font-size: 0.75rem;

    .pill-dot {
      width: 7px;
      height: 7px;
      border-radius: 50%;
      background: #10b981;
    }

    .pill-title {
      font-weight: 700;
      color: #f1f5f9;
    }

    .pill-hint {
      color: #94a3b8;
      font-size: 0.7rem;
    }

    &.codriver-active {
      background: rgba(37, 99, 235, 0.25);
      border-color: rgba(59, 130, 246, 0.5);

      .pill-dot {
        background: #3b82f6;
        box-shadow: 0 0 6px #3b82f6;
      }

      .pill-title {
        color: #93c5fd;
      }

      .pill-hint {
        color: #bfdbfe;
      }
    }
  }
}
</style>
