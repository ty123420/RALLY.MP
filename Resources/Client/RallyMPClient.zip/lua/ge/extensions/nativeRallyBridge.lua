-- ============================================================================
-- BeamNG.drive GE Extension: lua/ge/extensions/nativeRallyBridge.lua
--
-- Verified against BeamNG.drive v0.40.4.0 (CEF MainGEUI + ui-vue + ui_router) + BeamMP:
--   • Live CEF MainGEUI Pause Menu "Rally Mode (2P)" Tab via be:executeJS(...)
--     (mounts immediately on server join without UI reload, tracks v0.40 'pause'
--      routes, and hides 100% on 'play' so driving HUD stays completely clean)
--   • Zero-TOML Cross-Map Switching (MPCoreNetwork.loadLevel + session guard)
--   • Per-Event Vehicle Mode ("own_mp_car" carryover vs "stage_preset_car")
--   • Partner Ready-Check Proposals (Propose -> Accept/Decline -> Launch)
--   • gameplay_rally, gameplay_rallyLoop, RecceApp, CodriverTiming
--   • 3D s_rally_start_tree clock sync & End-Screen aiCompetitorsLeaderboard
-- ============================================================================

local M = {}

local CFG = {
  pauseMenuRallyTabOnly = true,
  enableDynamicCrossMapSync = true,
  freeroamMingleOnNewMap = true,
  unlockAllGameMapsCatalog = true,
  unlockNativeRallyFeatures = true,
  defaultVehicleChoice = "host_chooses",
  requirePartnerReadyCheck = true,
  allowRallyLoop = true,
  allowRallyStage = true,
  serviceBayLateralOffsetM = 4.8,
  staggerSlotSeconds = 60,
  clockSkipPolicy = "consensus_both",
  enableRttClockSync = true,
  strictSingleVehicleSync = true,
  immediatePartnerSpawnFlush = true,
  collisionPolicy = "always_solid",
  protectMpVehiclesFromClean = true,
  disableLiaisonAiTraffic = true,
  patchGlobalVehicleResetBug = true,
  injectEndScreenLeaderboard = true,
  enableLiveSplitDeltaOverlay = true,
  codriverMuteAiVoicepack = true,
  codriverClickToCallVoice = true,
  preferNativeVoice = true,        -- use BeamNG's own co-driver voicepack when a matching native pacenote exists
  subtitlesForNotes = true,        -- on-screen captions for every spoken note (accessibility)
  codriverHideDriverNotes = true,
  codriverDespawnExtraCarAndLockCam = true,
  codriverWritableTrackNotes = true,
  defaultRoadbookStyle = "grassroots_notepad",
  defaultCodriverPersonality = "pro_descriptive",
  roadbookNotesPerPage = 5
}

-- Official BeamNG Rally Loop & Rally Stage fallback catalog (guarantees cards from any map)
local OFFICIAL_RALLY_FALLBACKS = {
  { id = "utah/rallyLoop/ngrc26-rally-utah", name = "NGRC Rally Utah 2026", token = "utah", missionType = "rallyLoop", levelName = "utah", previewFile = "/gameplay/missions/utah/rallyLoop/ngrc26-rally-utah/preview.jpg" },
  { id = "italy/rallyLoop/ngrc25-rally-norte", name = "NGRC Rally Norte 2025", token = "norte", missionType = "rallyLoop", levelName = "italy", previewFile = "/gameplay/missions/italy/rallyLoop/ngrc25-rally-norte/preview.jpg" },
  { id = "east_coast_usa/rallyStage/ss-backroads-stage", name = "SS Backroads Stage", token = "backroads", missionType = "rallyStage", levelName = "east_coast_usa", previewFile = "/gameplay/missions/east_coast_usa/rallyStage/ss-backroads-stage/preview.jpg" },
  { id = "italy/rallyStage/ss-cliffside", name = "SS Cliffside", token = "cliffside", missionType = "rallyStage", levelName = "italy", previewFile = "/gameplay/missions/italy/rallyStage/ss-cliffside/preview.jpg" },
  { id = "automation_test_track/rallyStage/ss-clyde-peak", name = "SS Clyde Peak", token = "clyde", missionType = "rallyStage", levelName = "automation_test_track", previewFile = "/gameplay/missions/automation_test_track/rallyStage/ss-clyde-peak/preview.jpg" },
  { id = "automation_test_track/rallyStage/ss-facility-road", name = "SS Facility Road", token = "facility", missionType = "rallyStage", levelName = "automation_test_track", previewFile = "/gameplay/missions/automation_test_track/rallyStage/ss-facility-road/preview.jpg" },
  { id = "italy/rallyStage/001-ss-fastello-norte", name = "SS Fastello-Norte", token = "fastello", missionType = "rallyStage", levelName = "italy", previewFile = "/gameplay/missions/italy/rallyStage/001-ss-fastello-norte/preview.jpg" },
  { id = "jungle_rock_island/rallyStage/ss-howler-pass", name = "SS Howler Pass", token = "howler", missionType = "rallyStage", levelName = "jungle_rock_island", previewFile = "/gameplay/missions/jungle_rock_island/rallyStage/ss-howler-pass/preview.jpg" },
  { id = "italy/rallyStage/ss-orchard-hill", name = "SS Orchard Hill", token = "orchard", missionType = "rallyStage", levelName = "italy", previewFile = "/gameplay/missions/italy/rallyStage/ss-orchard-hill/preview.jpg" },
  { id = "small_island/rallyStage/ss-rockwood", name = "SS Rockwood", token = "rockwood", missionType = "rallyStage", levelName = "small_island", previewFile = "/gameplay/missions/small_island/rallyStage/ss-rockwood/preview.jpg" }
}

-- Self-contained CEF MainGEUI Pause Menu Tab + Rally Mode Selector + #009a1a Split/Ready HUD
-- Injected dynamically via be:executeJS(...) so it works immediately in BeamNG v0.40.4+ without UI reload
local CEF_PAUSE_UI_JS = [===[
(function() {
  if (window.__NativeRallyMP && window.__NativeRallyMP.mounted && document.getElementById("nrmp-cef-root")) {
    return;
  }

  var oldRoot = document.getElementById("nrmp-cef-root");
  if (oldRoot && oldRoot.parentNode) oldRoot.parentNode.removeChild(oldRoot);
  var oldStyle = document.getElementById("nrmp-cef-style");
  if (oldStyle && oldStyle.parentNode) oldStyle.parentNode.removeChild(oldStyle);

  var styleEl = document.createElement("style");
  styleEl.id = "nrmp-cef-style";
  styleEl.textContent = [
    "#nrmp-cef-root, #nrmp-cef-root * { box-sizing: border-box; user-select: none; -webkit-user-select: none; -webkit-user-drag: none; }",
    "#nrmp-cef-root { position: fixed; inset: 0; pointer-events: none; z-index: 2147483646; font-family: 'Noto Sans', 'Segoe UI', sans-serif; color: #f8fafc; }",
    ".nrmp-pause-tab-btn *, .nrmp-act-btn *, .nrmp-seg *, .nrmp-tool-btn *, .nrmp-close-btn * { pointer-events: none; }",
    "#nrmp-pause-tab-wrap { position: fixed; top: 10px; left: 50%; transform: translateX(-50%); pointer-events: auto; display: none; align-items: center; gap: 6px; z-index: 2147483646; }",
    "#nrmp-pause-tab-wrap.visible { display: flex; }",
    ".nrmp-pause-tab-btn { display: inline-flex; align-items: center; gap: 8px; padding: 7px 16px; background: rgba(15, 23, 42, 0.94); border: 1px solid #ff6600; border-radius: 4px; color: #ffffff; font-size: 13px; font-weight: 700; letter-spacing: 0.03em; cursor: pointer; box-shadow: 0 4px 16px rgba(0,0,0,0.55); transition: background 0.15s ease; }",
    ".nrmp-pause-tab-btn:hover, .nrmp-pause-tab-btn.active { background: #ff6600; color: #ffffff; }",
    ".nrmp-slash { display: inline-block; width: 6px; height: 15px; background: #ff6600; transform: skewX(-18deg); pointer-events: none; }",
    ".nrmp-pause-tab-btn:hover .nrmp-slash, .nrmp-pause-tab-btn.active .nrmp-slash { background: #ffffff; }",
    "#nrmp-invite-toast { position: fixed; top: 56px; left: 50%; transform: translateX(-50%); min-width: 430px; max-width: 690px; background: rgba(11, 15, 23, 0.97); border: 1px solid #009a1a; border-radius: 6px; padding: 12px 16px; box-shadow: 0 14px 40px rgba(0,0,0,0.84); pointer-events: auto; display: none; flex-direction: column; gap: 9px; z-index: 2147483647; }",
    "#nrmp-invite-toast.visible { display: flex; }",
    "#nrmp-invite-toast.proposer { border-color: #ff6600; }",
    ".nrmp-invite-top { display: flex; align-items: center; justify-content: space-between; gap: 12px; font-size: 13px; color: #f8fafc; }",
    ".nrmp-invite-actions { display: flex; align-items: center; justify-content: space-between; gap: 10px; }",
    ".nrmp-invite-hint { font-size: 11px; color: rgba(255,255,255,0.68); }",
    "#nrmp-selector-panel { position: fixed; top: 54px; left: 28px; right: 28px; bottom: 24px; background: rgba(13, 18, 28, 0.96); border: 1px solid rgba(255, 102, 0, 0.55); border-radius: 6px; box-shadow: 0 18px 48px rgba(0,0,0,0.75); pointer-events: auto; display: none; flex-direction: column; overflow: hidden; z-index: 2147483645; }",
    "#nrmp-selector-panel.open { display: flex; }",
    ".nrmp-toolbar { display: flex; flex-wrap: wrap; align-items: center; justify-content: space-between; gap: 12px; padding: 14px 20px; background: rgba(8, 12, 20, 0.92); border-bottom: 1px solid rgba(255,255,255,0.12); }",
    ".nrmp-brand { display: flex; align-items: center; gap: 10px; }",
    ".nrmp-brand-slash { width: 8px; height: 24px; background: #ff6600; transform: skewX(-18deg); display: inline-block; }",
    ".nrmp-title { margin: 0; font-size: 18px; font-weight: 800; font-style: italic; color: #ffffff; }",
    ".nrmp-sub { font-size: 12px; color: rgba(255,255,255,0.68); }",
    ".nrmp-controls { display: flex; flex-wrap: wrap; align-items: center; gap: 8px; }",
    ".nrmp-cluster { display: inline-flex; align-items: center; gap: 4px; background: rgba(0,0,0,0.48); border: 1px solid rgba(255,255,255,0.14); border-radius: 4px; padding: 3px 6px; }",
    ".nrmp-cluster-lbl { font-size: 11px; color: rgba(255,255,255,0.68); margin-right: 3px; }",
    ".nrmp-seg { background: transparent; border: none; color: rgba(255,255,255,0.82); padding: 4px 9px; font-size: 12px; font-weight: 700; border-radius: 3px; cursor: pointer; }",
    ".nrmp-seg.active { background: #ff6600; color: #ffffff; }",
    ".nrmp-close-btn { background: rgba(51, 65, 85, 0.9); border: 1px solid rgba(255,255,255,0.2); color: #ffffff; padding: 5px 12px; font-size: 12px; font-weight: 700; border-radius: 4px; cursor: pointer; }",
    ".nrmp-close-btn:hover { background: #b91c1c; border-color: #ef4444; }",
    ".nrmp-scroll-body { flex: 1; overflow-y: auto; padding: 16px 20px; display: flex; flex-direction: column; gap: 18px; }",
    ".nrmp-status-bar { display: flex; align-items: center; justify-content: space-between; gap: 8px; padding: 8px 14px; background: rgba(255, 102, 0, 0.18); border: 1px solid rgba(255, 102, 0, 0.65); border-radius: 4px; font-size: 12px; font-weight: 600; color: #ffffff; }",
    ".nrmp-ready-banner { display: flex; flex-wrap: wrap; align-items: center; justify-content: space-between; gap: 10px; padding: 10px 14px; background: rgba(0, 154, 26, 0.22); border: 1px solid #009a1a; border-radius: 4px; }",
    ".nrmp-ready-banner.proposer { background: rgba(255, 102, 0, 0.16); border-color: #ff6600; }",
    ".nrmp-ready-kicker { background: #009a1a; color: #fff; font-weight: 800; font-size: 11px; padding: 2px 6px; border-radius: 2px; margin-right: 6px; }",
    ".nrmp-ready-kicker.proposer { background: #ff6600; }",
    ".nrmp-staged-banner { display: flex; flex-wrap: wrap; align-items: center; justify-content: space-between; gap: 10px; padding: 11px 14px; background: rgba(245, 158, 11, 0.16); border: 1px solid #f59e0b; border-radius: 4px; }",
    ".nrmp-staged-kicker { background: #d97706; color: #fff; font-weight: 800; font-size: 11px; padding: 2px 6px; border-radius: 2px; margin-right: 6px; }",
    ".nrmp-timer-pill { font-family: monospace; font-weight: 700; font-size: 12px; color: #e2e8f0; }",
    ".nrmp-btn-row { display: flex; align-items: center; gap: 6px; }",
    ".nrmp-act-btn { border: none; color: #fff; padding: 7px 14px; font-size: 12px; font-weight: 700; border-radius: 4px; cursor: pointer; white-space: nowrap; }",
    ".nrmp-act-start { background: #ff6600; }",
    ".nrmp-act-start:hover { background: #ea580c; }",
    ".nrmp-act-notes { background: rgba(30, 41, 59, 0.95); border: 1px solid rgba(255,255,255,0.22); }",
    ".nrmp-act-notes:hover { border-color: #f59e0b; }",
    ".nrmp-act-accept { background: #009a1a; }",
    ".nrmp-act-accept:hover { background: #16a34a; }",
    ".nrmp-act-decline { background: #b91c1c; }",
    ".nrmp-act-decline:hover { background: #dc2626; }",
    ".nrmp-act-cancel { background: #475569; }",
    ".nrmp-act-cancel:hover { background: #64748b; }",
    ".nrmp-act-dismiss { background: rgba(30, 41, 59, 0.9); border: 1px solid rgba(255,255,255,0.18); padding: 6px 10px; }",
    ".nrmp-cat-head { display: flex; align-items: center; gap: 8px; margin-bottom: 10px; }",
    ".nrmp-cat-title { margin: 0; font-size: 16px; font-weight: 800; font-style: italic; color: #ffffff; }",
    ".nrmp-cat-line { flex: 1; height: 1px; background: rgba(255,255,255,0.18); }",
    ".nrmp-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(215px, 1fr)); gap: 12px; }",
    ".nrmp-card { display: flex; flex-direction: column; padding: 0; background: rgba(30, 41, 59, 0.92); border: 1px solid rgba(255,255,255,0.15); border-radius: 4px; overflow: hidden; cursor: pointer; text-align: left; color: #ffffff; transition: border-color 0.14s ease, transform 0.14s ease; }",
    ".nrmp-card * { pointer-events: none; -webkit-user-drag: none; }",
    ".nrmp-card:hover { border-color: #ff6600; box-shadow: 0 0 0 1px #ff6600; transform: translateY(-1px); }",
    ".nrmp-thumb { position: relative; width: 100%; height: 118px; background: linear-gradient(135deg, #1e293b 0%, #0f172a 60%, #431407 100%); overflow: hidden; display: flex; align-items: center; justify-content: center; }",
    ".nrmp-thumb img { width: 100%; height: 100%; object-fit: cover; display: block; pointer-events: none; -webkit-user-drag: none; }",
    ".nrmp-thumb-fallback { font-size: 12px; font-weight: 700; color: rgba(255,255,255,0.45); letter-spacing: 0.04em; text-transform: uppercase; }",
    ".nrmp-map-tag { position: absolute; top: 6px; right: 6px; background: rgba(0,0,0,0.78); color: #f8fafc; font-size: 10px; font-family: monospace; padding: 2px 6px; border-radius: 2px; }",
    ".nrmp-card-foot { display: flex; align-items: center; justify-content: space-between; gap: 6px; padding: 8px 10px; background: rgba(15, 23, 42, 0.98); }",
    ".nrmp-card-name { font-size: 13px; font-weight: 700; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }",
    ".nrmp-card-sync { font-size: 11px; color: #ff6600; font-weight: 700; flex-shrink: 0; }",
    ".nrmp-footer { padding: 12px 20px; background: rgba(8, 12, 20, 0.94); border-top: 1px solid rgba(255,255,255,0.12); display: flex; flex-wrap: wrap; align-items: center; justify-content: flex-end; gap: 10px; }",
    ".nrmp-tools-row { display: flex; flex-wrap: wrap; align-items: center; gap: 6px; }",
    ".nrmp-tool-btn { background: rgba(30, 41, 59, 0.95); border: 1px solid rgba(255,255,255,0.18); color: #ffffff; padding: 5px 10px; font-size: 12px; font-weight: 600; border-radius: 3px; cursor: pointer; }",
    ".nrmp-tool-btn:hover { border-color: #ff6600; }",
    ".nrmp-tool-btn.danger { background: #991b1b; border-color: #b91c1c; }",
    "#nrmp-hud-strip { position: fixed; top: 410px; left: 12px; width: 300px; pointer-events: none; display: none; flex-direction: column; box-shadow: 0 8px 24px rgba(0,0,0,0.55); z-index: 2147481900; }",
    "#nrmp-hud-strip.visible { display: flex; }",
    "#nrmp-subtitle { position: fixed; left: 50%; bottom: 9%; transform: translateX(-50%); max-width: 72vw; min-width: 160px; padding: 10px 22px; border-radius: 8px; background: rgba(0,0,0,0.84); color: #ffffff; font-family: Arial, Helvetica, sans-serif; font-weight: 700; line-height: 1.25; text-align: center; letter-spacing: 0.01em; text-shadow: 0 1px 2px #000; border: 2px solid rgba(255,255,255,0.4); pointer-events: none; display: none; z-index: 2147483000; box-shadow: 0 6px 20px rgba(0,0,0,0.6); }",
    "#nrmp-subtitle.visible { display: block; }",
    "#nrmp-voice-panel { position: fixed; top: 90px; right: 24px; width: 340px; display: none; flex-direction: column; gap: 9px; padding: 14px 16px; background: rgba(8,12,20,0.97); color: #f8fafc; border: 1px solid rgba(255,102,0,0.7); border-radius: 8px; font-family: Arial, Helvetica, sans-serif; font-size: 13px; box-shadow: 0 14px 40px rgba(0,0,0,0.7); pointer-events: auto; z-index: 2147483200; }",
    "#nrmp-voice-panel.visible { display: flex; }",
    "#nrmp-voice-panel * { pointer-events: auto; box-sizing: border-box; }",
    "#nrmp-voice-panel h3 { margin: 0; font-size: 15px; display: flex; justify-content: space-between; align-items: center; }",
    "#nrmp-voice-panel label { display: flex; align-items: center; justify-content: space-between; gap: 8px; }",
    "#nrmp-voice-panel select, #nrmp-voice-panel button { background: #1e293b; color: #fff; border: 1px solid rgba(255,255,255,0.25); border-radius: 3px; padding: 4px 8px; font-size: 12px; }",
    "#nrmp-voice-panel select { max-width: 200px; }",
    "#nrmp-voice-panel input[type=range] { width: 150px; }",
    "#nrmp-voice-panel button { cursor: pointer; font-weight: 700; }",
    "#nrmp-voice-panel button:hover { border-color: #ff6600; }",
    "#nrmp-voice-panel .nrmp-vp-note { font-size: 11px; color: #94a3b8; line-height: 1.35; }",
    "#nrmp-subtitle .nrmp-sub-who { display: block; font-size: 0.55em; color: #ffb066; letter-spacing: 0.1em; margin-bottom: 2px; }",
    ".nrmp-hud-head { display: flex; justify-content: space-between; align-items: center; background: #009a1a; color: #fff; padding: 4px 9px; font-size: 12px; font-weight: 800; letter-spacing: 0.04em; }",
    ".nrmp-hud-split { display: flex; justify-content: space-between; align-items: center; background: rgba(0,0,0,0.85); color: #fff; padding: 6px 9px; font-family: monospace; font-size: 13px; }",
    "#nrmp-roadbook-win { position: fixed; pointer-events: auto; display: none; flex-direction: column; overflow: hidden; z-index: 2147482600; box-shadow: 0 18px 46px rgba(0,0,0,0.72); border-radius: 8px; transition: opacity 0.14s ease; }",
    "#nrmp-roadbook-win.visible { display: flex; }",
    "#nrmp-roadbook-win.digital { background: #0B101B; border: 1px solid #334155; color: #F8FAFC; font-family: 'Noto Sans', 'Segoe UI', sans-serif; }",
    "#nrmp-roadbook-win.paper { background: #F6F1E3; border: 1px solid #A89F88; color: #1C1917; font-family: 'Caveat', 'Segoe Print', 'Bradley Hand', 'Comic Sans MS', sans-serif; }",
    ".nrmp-rb-spiral { display: flex; align-items: center; justify-content: space-around; height: 14px; background: #292524; border-bottom: 1px solid #78716C; padding: 0 10px; flex-shrink: 0; }",
    ".nrmp-rb-ring { width: 8px; height: 12px; border-radius: 4px; background: linear-gradient(180deg, #E7E5E4 0%, #78716C 100%); box-shadow: 0 1px 2px rgba(0,0,0,0.65); }",
    ".nrmp-rb-dragbar { display: flex; align-items: center; justify-content: space-between; gap: 8px; padding: 7px 10px; cursor: move; flex-shrink: 0; }",
    "#nrmp-roadbook-win.digital .nrmp-rb-dragbar { background: #111827; border-bottom: 1px solid #1E293B; }",
    "#nrmp-roadbook-win.paper .nrmp-rb-dragbar { background: #EAE2CE; border-bottom: 1px solid #C7BCA1; font-family: 'Noto Sans', 'Segoe UI', sans-serif; }",
    ".nrmp-rb-title { font-size: 12px; font-weight: 800; letter-spacing: 0.03em; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }",
    ".nrmp-rb-odo { font-family: monospace; font-size: 12px; font-weight: 700; padding: 2px 6px; border-radius: 3px; white-space: nowrap; }",
    "#nrmp-roadbook-win.digital .nrmp-rb-odo { background: #052E16; color: #4ADE80; border: 1px solid #166534; }",
    "#nrmp-roadbook-win.paper .nrmp-rb-odo { background: #292524; color: #FDE68A; }",
    ".nrmp-rb-subbar { display: flex; flex-wrap: wrap; align-items: center; justify-content: space-between; gap: 5px; padding: 5px 10px; font-family: 'Noto Sans', 'Segoe UI', sans-serif; font-size: 11px; flex-shrink: 0; }",
    "#nrmp-roadbook-win.digital .nrmp-rb-subbar { background: #0F172A; border-bottom: 1px solid #1E293B; color: #CBD5E1; }",
    "#nrmp-roadbook-win.paper .nrmp-rb-subbar { background: #EFE8D5; border-bottom: 2px solid rgba(220,38,38,0.35); color: #44403C; }",
    ".nrmp-rb-mini-group { display: inline-flex; align-items: center; gap: 3px; }",
    ".nrmp-rb-chip { border: 1px solid rgba(148,163,184,0.35); background: rgba(15,23,42,0.12); color: inherit; font-size: 10px; font-weight: 700; padding: 2px 6px; border-radius: 3px; cursor: pointer; white-space: nowrap; }",
    ".nrmp-rb-chip * { pointer-events: none; }",
    ".nrmp-rb-chip.active { background: #EA580C; border-color: #EA580C; color: #FFFFFF; }",
    ".nrmp-rb-chip.save { background: #16A34A; border-color: #16A34A; color: #FFFFFF; }",
    ".nrmp-rb-sheet { flex: 1; display: flex; flex-direction: column; justify-content: space-between; overflow-y: auto; padding: 8px 10px; transform-origin: left center; transition: transform 0.18s cubic-bezier(0.16, 1, 0.3, 1), opacity 0.18s ease; }",
    ".nrmp-rb-sheet.flip-next { transform: perspective(900px) rotateY(-14deg) scale(0.985); opacity: 0.72; }",
    ".nrmp-rb-sheet.flip-prev { transform: perspective(900px) rotateY(14deg) scale(0.985); opacity: 0.72; }",
    "#nrmp-roadbook-win.paper .nrmp-rb-sheet { background-image: repeating-linear-gradient(to bottom, transparent 0px, transparent 31px, rgba(59,130,246,0.18) 32px); }",
    ".nrmp-rb-rows { display: flex; flex-direction: column; gap: 6px; flex: 1; }",
    ".nrmp-rb-row { display: flex; align-items: center; gap: 9px; padding: 6px 8px; border-radius: 5px; cursor: pointer; position: relative; transition: background 0.12s ease, transform 0.1s ease; }",
    ".nrmp-rb-row.read-row * { pointer-events: none; }",
    "#nrmp-roadbook-win.digital .nrmp-rb-row { background: rgba(30,41,59,0.58); border: 1px solid rgba(71,85,105,0.45); }",
    "#nrmp-roadbook-win.digital .nrmp-rb-row:hover { border-color: #F97316; background: rgba(30,41,59,0.92); }",
    "#nrmp-roadbook-win.digital .nrmp-rb-row.selected { border-color: #38BDF8; box-shadow: inset 0 0 0 1px #38BDF8; }",
    "#nrmp-roadbook-win.digital .nrmp-rb-row.hazard { background: rgba(127,29,29,0.34); border-color: rgba(248,113,113,0.65); }",
    "#nrmp-roadbook-win.paper .nrmp-rb-row { border-bottom: 1px dashed rgba(120,113,108,0.32); border-radius: 3px; padding-left: 6px; }",
    "#nrmp-roadbook-win.paper .nrmp-rb-row:hover { background: rgba(234,88,12,0.09); }",
    "#nrmp-roadbook-win.paper .nrmp-rb-row.selected { outline: 1.5px solid #EA580C; background: rgba(254,215,170,0.42); }",
    "#nrmp-roadbook-win.paper .nrmp-rb-row.hazard { background: #FEF08A; }",
    ".nrmp-rb-dist { min-width: 48px; text-align: right; font-family: monospace; font-weight: 800; padding-right: 7px; flex-shrink: 0; }",
    "#nrmp-roadbook-win.paper .nrmp-rb-dist { border-right: 2px solid rgba(220,38,38,0.45); color: #7C2D12; }",
    "#nrmp-roadbook-win.digital .nrmp-rb-dist { border-right: 1px solid rgba(148,163,184,0.28); color: #94A3B8; }",
    ".nrmp-rb-icon { width: 34px; height: 34px; border-radius: 5px; display: inline-flex; align-items: center; justify-content: center; font-family: 'Noto Sans', sans-serif; font-weight: 900; font-size: 12px; flex-shrink: 0; }",
    ".nrmp-rb-call { flex: 1; font-weight: 700; line-height: 1.25; user-select: text; }",
    ".nrmp-rb-speak-tag { font-family: 'Noto Sans', sans-serif; font-size: 10px; font-weight: 800; padding: 2px 5px; border-radius: 3px; opacity: 0.72; flex-shrink: 0; }",
    "#nrmp-roadbook-win.digital .nrmp-rb-speak-tag { background: rgba(15,23,42,0.85); color: #FDBA74; border: 1px solid rgba(251,146,60,0.35); }",
    "#nrmp-roadbook-win.paper .nrmp-rb-speak-tag { background: rgba(28,25,23,0.1); color: #7C2D12; }",
    ".nrmp-rb-row.called .nrmp-rb-speak-tag { opacity: 1; background: #16A34A !important; color: #FFFFFF !important; border-color: #16A34A !important; }",
    ".nrmp-rb-inp { user-select: text !important; -webkit-user-select: text !important; pointer-events: auto !important; font-family: 'Noto Sans', sans-serif; font-size: 12px; padding: 3px 5px; border-radius: 3px; border: 1px solid #64748B; background: rgba(255,255,255,0.92); color: #0F172A; }",
    ".nrmp-rb-tts { display: inline-flex; align-items: center; gap: 3px; font: 10px 'Noto Sans', sans-serif; white-space: nowrap; }",
    ".nrmp-rb-cuelist { flex-shrink: 0; display: flex; flex-direction: column; gap: 6px; margin-top: 10px; padding: 8px 6px 4px; border-top: 2px solid rgba(234,88,12,0.7); font-family: 'Noto Sans', 'Segoe UI', sans-serif; }",
    ".nrmp-rb-cuehead { display: flex; justify-content: space-between; align-items: center; gap: 8px; font-size: 10px; font-weight: 800; letter-spacing: 0.04em; opacity: 0.85; }",
    ".nrmp-rb-cuegrid { display: flex; flex-direction: column; gap: 6px; }",
    ".nrmp-rb-cuerow { display: flex; gap: 8px; align-items: stretch; }",
    ".nrmp-rb-cue-icon { position: relative; width: 56px; height: 56px; flex-shrink: 0; border-radius: 8px; cursor: pointer; display: inline-flex; align-items: center; justify-content: center; font-family: 'Noto Sans', sans-serif; font-weight: 900; font-size: 18px; box-shadow: 0 2px 6px rgba(0,0,0,0.4); transition: transform 0.1s ease, filter 0.1s ease; }",
    ".nrmp-rb-cue-icon * { pointer-events: none; }",
    ".nrmp-rb-cue-icon:hover { transform: scale(1.07); filter: brightness(1.15); }",
    ".nrmp-rb-cue-icon:active { transform: scale(0.95); }",
    ".nrmp-rb-cue-play { position: absolute; right: 3px; bottom: 1px; font-size: 10px; opacity: 0.85; }",
    ".nrmp-rb-cue { flex: 1; min-width: 0; display: flex; align-items: center; gap: 8px; text-align: left; border-radius: 6px; padding: 6px 10px; font-size: 14px; font-weight: 700; line-height: 1.25; cursor: pointer; font-family: inherit; }",
    ".nrmp-rb-cue * { pointer-events: none; }",
    "#nrmp-roadbook-win.digital .nrmp-rb-cue { background: rgba(30,41,59,0.9); border: 1px solid rgba(148,163,184,0.28); color: #F1F5F9; }",
    "#nrmp-roadbook-win.paper .nrmp-rb-cue { background: rgba(28,25,23,0.06); border: 1px dashed rgba(120,113,108,0.5); color: #1C1917; }",
    ".nrmp-rb-cue:hover { border-color: #EA580C !important; }",
    ".nrmp-rb-cue-d { min-width: 44px; color: #FDBA74; font-weight: 800; font-size: 12px; font-family: monospace; flex-shrink: 0; }",
    "#nrmp-roadbook-win.paper .nrmp-rb-cue-d { color: #7C2D12; }",
    ".nrmp-rb-cue-t { flex: 1; overflow-wrap: anywhere; }",
    ".nrmp-rb-cue-add { width: 48px; flex-shrink: 0; border-radius: 8px; border: 1px solid rgba(148,163,184,0.45); background: rgba(22,163,74,0.9); color: #FFFFFF; font-size: 26px; font-weight: 900; line-height: 1; cursor: pointer; }",
    ".nrmp-rb-cue-add:hover { background: #16A34A; filter: brightness(1.15); }",
    ".nrmp-rb-foot { display: flex; align-items: center; justify-content: space-between; gap: 8px; padding: 7px 24px 7px 10px; font-family: 'Noto Sans', 'Segoe UI', sans-serif; font-size: 11px; position: relative; flex-shrink: 0; }",
    "#nrmp-roadbook-win.digital .nrmp-rb-foot { background: #111827; border-top: 1px solid #1E293B; color: #94A3B8; }",
    "#nrmp-roadbook-win.paper .nrmp-rb-foot { background: #EAE2CE; border-top: 1px solid #C7BCA1; color: #44403C; }",
    ".nrmp-rb-pagebtn { border: none; padding: 5px 11px; border-radius: 4px; font-size: 11px; font-weight: 800; cursor: pointer; white-space: nowrap; }",
    ".nrmp-rb-pagebtn * { pointer-events: none; }",
    ".nrmp-rb-pagebtn.prev { background: rgba(71,85,105,0.85); color: #FFFFFF; }",
    ".nrmp-rb-pagebtn.next { background: #EA580C; color: #FFFFFF; }",
    ".nrmp-rb-pagebtn:disabled { opacity: 0.38; cursor: default; }",
    "#nrmp-rb-resize { position: absolute; right: 0; bottom: 0; width: 20px; height: 20px; cursor: nwse-resize; background: linear-gradient(135deg, transparent 50%, rgba(234,88,12,0.85) 50%); z-index: 5; }"
  ].join(" ");
  document.head.appendChild(styleEl);

  var driverHideStyleEl = document.getElementById("nrmp-driver-hide-notes-style");
  if (!driverHideStyleEl) {
    driverHideStyleEl = document.createElement("style");
    driverHideStyleEl.id = "nrmp-driver-hide-notes-style";
    document.head.appendChild(driverHideStyleEl);
  }

  var rootEl = document.createElement("div");
  rootEl.id = "nrmp-cef-root";
  rootEl.innerHTML = [
    '<div id="nrmp-pause-tab-wrap">',
    '  <button type="button" id="nrmp-pause-tab-btn" class="nrmp-pause-tab-btn">',
    '    <span class="nrmp-slash"></span>',
    '    <span id="nrmp-pause-tab-label">Rally Mode (2P)</span>',
    '  </button>',
    '</div>',
    '<div id="nrmp-invite-toast"></div>',
    '<div id="nrmp-selector-panel"></div>',
    '<div id="nrmp-hud-strip"></div>',
    '<div id="nrmp-subtitle" role="status" aria-live="polite"></div>',
    '<div id="nrmp-voice-panel"></div>',
    '<div id="nrmp-roadbook-win"></div>'
  ].join("");
  document.body.appendChild(rootEl);

  function callLua(expr) {
    if (window.bngApi && typeof window.bngApi.engineLua === "function") {
      window.bngApi.engineLua(expr);
    }
  }

  function luaStr(s) {
    return JSON.stringify(String(s == null ? "" : s));
  }

  function escHtml(s) {
    return String(s == null ? "" : s)
      .split("&").join("&amp;")
      .split("<").join("&lt;")
      .split(">").join("&gt;")
      .split('"').join("&quot;");
  }

  var savedRbPrefs = {};
  try {
    var rawPrefs = window.localStorage && window.localStorage.getItem("nrmp_codriver_rb_v1");
    if (rawPrefs) savedRbPrefs = JSON.parse(rawPrefs) || {};
  } catch (errP) {}

  var store = {
    mounted: true,
    inLevel: true,
    luaMenuOpen: false,
    panelOpen: false,
    forcedStandalone: false,
    statusNotice: "",
    lastInviteId: "",
    inviteExpiresAtMs: 0,
    dismissedProposalId: "",
    lastInviteSig: "",
    lastPanelSig: "",
    lastHudSig: "",
    lastRbSig: "",
    rb: {
      x: typeof savedRbPrefs.x === "number" ? savedRbPrefs.x : Math.max(24, (window.innerWidth || 1440) - 462),
      y: typeof savedRbPrefs.y === "number" ? savedRbPrefs.y : 72,
      width: typeof savedRbPrefs.width === "number" ? savedRbPrefs.width : 434,
      height: typeof savedRbPrefs.height === "number" ? savedRbPrefs.height : 478,
      fontScale: typeof savedRbPrefs.fontScale === "number" ? savedRbPrefs.fontScale : 1.0,
      visualStyle: savedRbPrefs.visualStyle || "grassroots_notepad",
      personality: savedRbPrefs.personality || "pro_descriptive",
      notesPerPage: Number(savedRbPrefs.notesPerPage) || 5,
      pageIndex: 0,
      flipAnim: "",
      editMode: false,
      draftTrackKey: "",
      draftNotes: [],
      selectedNoteId: "",
      lastCalledNoteId: "",
      lastSpokenNotice: "",
      nativeCueOpen: true,
      odometerM: 0,
      freeroamNotesOpen: false,
      freeroamMinimized: false
    },
    state: {
      rttMs: 0,
      role: "DRIVER",
      slot: 1,
      activeMissionId: "",
      stagedMissionId: "",
      currentTrackKey: "",
      aiVoiceMutedKeepOff: false,
      codriverClickToCallVoice: true,
      codriverHideDriverNotes: true,
      codriverWritableTrackNotes: true,
      roadbookCustomSaved: false,
      roadbookNotes: [],
      vehicleMode: "own_mp_car",
      defaultVehicleChoice: "host_chooses",
      requirePartnerReadyCheck: true,
      countdownDisplay: "3d",
      unlockNativeRallyFeatures: true,
      enableLiveSplitDeltaOverlay: true,
      maps: [],
      missions: [],
      lastSplit: null,
      peerState: {
        status: "FREEROAM",
        yourPlayerId: -1,
        currentLevel: "",
        recceEnabled: false,
        participationMode: "two_car",
        launchMode: "wrc_staggered",
        staggerSlotSeconds: 60,
        hasPendingProposal: false,
        pendingProposal: false,
        hasStagedMission: false,
        stagedMission: false
      }
    }
  };

  function persistRbPrefs() {
    try {
      if (window.localStorage) {
        window.localStorage.setItem("nrmp_codriver_rb_v1", JSON.stringify({
          x: store.rb.x,
          y: store.rb.y,
          width: store.rb.width,
          height: store.rb.height,
          fontScale: store.rb.fontScale,
          visualStyle: store.rb.visualStyle,
          personality: store.rb.personality,
          notesPerPage: store.rb.notesPerPage
        }));
      }
    } catch (errS) {}
  }

  function applyDriverHideNotesCss(hideBool) {
    if (!driverHideStyleEl) return;
    if (hideBool) {
      driverHideStyleEl.textContent = "[class*='VisualPacenotes'], [class*='visualPacenotes'], [class*='pacenotesApp'], rally-visual-pacenotes { display: none !important; opacity: 0 !important; visibility: hidden !important; pointer-events: none !important; }";
    } else if (driverHideStyleEl.textContent !== "") {
      driverHideStyleEl.textContent = "";
    }
  }

  function getActiveProposal() {
    var ps = (store.state && store.state.peerState) || {};
    var p = ps.pendingProposal;
    if (!p || typeof p !== "object" || !p.id || ps.hasPendingProposal === false) {
      return null;
    }
    if (store.dismissedProposalId && String(store.dismissedProposalId) === String(p.id)) {
      return null;
    }
    if (store.inviteExpiresAtMs > 0 && Date.now() > store.inviteExpiresAtMs) {
      return null;
    }
    return p;
  }

  function isLocalPlayerProposer(prop) {
    if (!prop) return false;
    if (prop.isProposer === true) return true;
    var ps = (store.state && store.state.peerState) || {};
    if (ps.yourPlayerId !== undefined && ps.yourPlayerId !== -1 && prop.proposerId !== undefined) {
      return Number(prop.proposerId) === Number(ps.yourPlayerId);
    }
    return false;
  }

  function getStagedMission() {
    var ps = (store.state && store.state.peerState) || {};
    var s = ps.stagedMission;
    if (!s || typeof s !== "object" || !s.missionId || ps.hasStagedMission === false) {
      return null;
    }
    return s;
  }

  function isLocalPlayerStagedProposer(staged) {
    if (!staged) return false;
    if (staged.isProposer === true) return true;
    var ps = (store.state && store.state.peerState) || {};
    if (ps.yourPlayerId !== undefined && ps.yourPlayerId !== -1 && staged.proposerId !== undefined) {
      return Number(staged.proposerId) === Number(ps.yourPlayerId);
    }
    return false;
  }

  function getProposalRemainingSec() {
    if (store.inviteExpiresAtMs <= 0) return 30;
    return Math.max(0, Math.ceil((store.inviteExpiresAtMs - Date.now()) / 1000));
  }

  function isRallyActiveStatus(stName) {
    return stName === "START_SCREEN" || stName === "LOOP_ACTIVE" || stName === "STAGE_STAGING" || stName === "STAGE_ACTIVE" || stName === "RECCE_ACTIVE";
  }

  function getVueRouteInfo() {
    try {
      var roots = document.querySelectorAll("[data-v-app], #vue-app, #main-vue, #app, body > div");
      for (var i = 0; i < roots.length; i++) {
        var app = roots[i] && roots[i].__vue_app__;
        if (app && app.config && app.config.globalProperties && app.config.globalProperties.$route) {
          var rt = app.config.globalProperties.$route;
          return {
            name: String(rt.name || "").toLowerCase(),
            path: String(rt.path || "").toLowerCase(),
            fullPath: String(rt.fullPath || "").toLowerCase()
          };
        }
      }
    } catch (err) {}
    return null;
  }

  function isExplicitPlayRoute() {
    var rt = getVueRouteInfo();
    if (rt && (rt.name || rt.path)) {
      if (rt.name === "play" || rt.name.indexOf("play.") === 0 || rt.path === "/play" || rt.path.indexOf("/play/") === 0) {
        return true;
      }
    }
    var h = String(window.location.hash || "").toLowerCase();
    if (h === "#/play" || h.indexOf("#/play/") === 0 || h.indexOf("#/play?") === 0) {
      return true;
    }
    return false;
  }

  function detectDomPauseOpen() {
    var rt = getVueRouteInfo();
    if (rt && (rt.name || rt.path)) {
      var rn = rt.name;
      var rp = rt.path;
      if (rn === "play" || rn.indexOf("play.") === 0 || rp === "/play" || rp.indexOf("/play/") === 0) {
        return false;
      }
      if (rn === "pause" || rn.indexOf("pause.") === 0 || rp === "/pause" || rp.indexOf("/pause/") === 0) {
        return true;
      }
      if (store.inLevel && (rn === "menu" || rn.indexOf("menu.") === 0 || rp.indexOf("/menu") === 0) && rn.indexOf("beammp") === -1 && rp.indexOf("beammp") === -1) {
        return true;
      }
    }

    var h = String(window.location.hash || "").toLowerCase();
    if (h === "#/play" || h.indexOf("#/play/") === 0 || h.indexOf("#/play?") === 0) {
      return false;
    }
    if (h.indexOf("pause") !== -1) {
      return true;
    }
    if (store.inLevel && h.indexOf("menu") !== -1 && h.indexOf("beammp") === -1) {
      return true;
    }

    var selectors = [
      "[bng-ui-scope*='pause']",
      "[class*='homeRail']",
      "[class*='home-rail']",
      "[class*='pause-menu']",
      "[class*='pauseMenu']",
      "[class*='pause-layout']",
      "[bng-ui-scope*='menu']",
      "[class*='menu-navbar']",
      "[class*='dashmenu']"
    ];
    for (var i = 0; i < selectors.length; i++) {
      var list = document.querySelectorAll(selectors[i]);
      for (var j = 0; j < list.length; j++) {
        var el = list[j];
        if (!rootEl.contains(el)) {
          var r = el.getBoundingClientRect();
          if (r.width > 40 && r.height > 24) return true;
        }
      }
    }
    return false;
  }

  function resolveThumbSrc(p) {
    if (!p) return "";
    if (p.indexOf("http") === 0 || p.indexOf("local://") === 0) return p;
    if (p.charAt(0) === "/") return "local://local" + p;
    return "local://local/" + p;
  }

  function renderInviteToast() {
    var toastEl = document.getElementById("nrmp-invite-toast");
    if (!toastEl) return;
    var prop = getActiveProposal();
    if (!prop || store.panelOpen) {
      if (store.lastInviteSig !== "hidden") {
        store.lastInviteSig = "hidden";
        toastEl.className = "";
        toastEl.innerHTML = "";
      }
      return;
    }

    var isProposer = isLocalPlayerProposer(prop);
    var isStartStaged = prop.actionType === "start_staged";
    var remSec = getProposalRemainingSec();
    var vehLabel = prop.vehicleMode === "stage_preset_car" ? "Stage Preset Car" : "Own MP Car";
    var sig = [prop.id, isProposer ? "1" : "0", isStartStaged ? "start" : "inv", prop.title, prop.levelName, vehLabel].join("|");

    if (sig === store.lastInviteSig) {
      var remNode = document.getElementById("nrmp-invite-rem");
      if (remNode) remNode.textContent = remSec + "s";
      return;
    }
    store.lastInviteSig = sig;
    toastEl.className = isProposer ? "visible proposer" : "visible";

    var html = [];
    if (isProposer) {
      html.push('<div class="nrmp-invite-top"><div><span class="nrmp-ready-kicker proposer">' + (isStartStaged ? "START READY CHECK" : "INVITE SENT") + '</span>Waiting for partner to ' + (isStartStaged ? "confirm Ready to launch " : "accept ") + '<strong>' + escHtml(prop.title) + '</strong> (' + escHtml(prop.levelName || "auto-map") + ' · ' + vehLabel + ')</div><span id="nrmp-invite-rem" class="nrmp-timer-pill">' + remSec + 's</span></div>');
      html.push('<div class="nrmp-invite-actions"><span class="nrmp-invite-hint">Partner can click Accept &amp; Ready, press Alt+A, or type /accept in chat</span><div class="nrmp-btn-row"><button type="button" class="nrmp-act-btn nrmp-act-cancel" data-act="cancel">Cancel (Alt+C)</button><button type="button" class="nrmp-act-btn nrmp-act-dismiss" data-act="dismissinvite" title="Hide banner">&times;</button></div></div>');
    } else {
      html.push('<div class="nrmp-invite-top"><div><span class="nrmp-ready-kicker">' + (isStartStaged ? "READY TO START RALLY" : "2P RALLY INVITE") + '</span><strong>' + escHtml(prop.proposerName) + '</strong> ' + (isStartStaged ? "is starting staged event " : "invited you to ") + '<strong>' + escHtml(prop.title) + '</strong> (' + escHtml(prop.levelName || "auto-map") + ' · ' + vehLabel + ')</div><span id="nrmp-invite-rem" class="nrmp-timer-pill">' + remSec + 's</span></div>');
      html.push('<div class="nrmp-invite-actions"><span class="nrmp-invite-hint">Shortcuts: Alt+A Accept · Alt+D Decline · or /accept in chat</span><div class="nrmp-btn-row"><button type="button" class="nrmp-act-btn nrmp-act-accept" data-act="accept">Accept &amp; Ready (Alt+A)</button><button type="button" class="nrmp-act-btn nrmp-act-decline" data-act="decline">Decline (Alt+D)</button><button type="button" class="nrmp-act-btn nrmp-act-dismiss" data-act="dismissinvite" title="Hide banner">&times;</button></div></div>');
    }
    toastEl.innerHTML = html.join("");
  }

  function renderHudStrip() {
    var hudEl = document.getElementById("nrmp-hud-strip");
    if (!hudEl) return;
    var st = store.state;
    var ps = st.peerState || {};
    var showSplit = st.enableLiveSplitDeltaOverlay && (isRallyActiveStatus(ps.status) || Boolean(st.lastSplit));

    if (!showSplit) {
      if (store.lastHudSig !== "hidden") {
        store.lastHudSig = "hidden";
        hudEl.className = "";
        hudEl.innerHTML = "";
      }
      return;
    }

    var splitKey = st.lastSplit ? (String(st.lastSplit.playerName) + "|" + String(st.lastSplit.splitLabel) + "|" + String(st.lastSplit.deltaSec)) : "nosplit";
    var sig = String(ps.participationMode || "two_car") + "::" + splitKey;
    if (sig === store.lastHudSig) {
      var rttNode = document.getElementById("nrmp-hud-rtt");
      if (rttNode) rttNode.textContent = "RTT " + Number(st.rttMs || 0) + "ms";
      return;
    }
    store.lastHudSig = sig;

    hudEl.className = "visible";
    var html = [];
    html.push('<div class="nrmp-hud-head"><span>' + (ps.participationMode === "codriver" ? "SHARED CO-DRIVER" : "BEAMMP 2P RALLY") + '</span><span id="nrmp-hud-rtt">RTT ' + Number(st.rttMs || 0) + 'ms</span></div>');
    if (st.lastSplit) {
      var d = st.lastSplit.deltaSec;
      var dTxt = "";
      if (d !== null && d !== undefined) {
        var dNum = Number(d);
        var col = dNum <= 0 ? "#66ff66" : "#ff6666";
        dTxt = '<span style="font-weight:700;color:' + col + '">' + (dNum <= 0 ? "" : "+") + dNum.toFixed(2) + 's</span>';
      }
      html.push('<div class="nrmp-hud-split"><span>' + escHtml(st.lastSplit.playerName) + ' · ' + escHtml(st.lastSplit.splitLabel) + '</span>' + dTxt + '</div>');
    }
    hudEl.innerHTML = html.join("");
  }

  function cleanNativeText(txt) {
    var t = String(txt == null ? "" : txt);
    if (t.indexOf('"') >= 0 || /^\s*[{(\[]/.test(t)) {
      var words = [], m, re = /"([^"]*)"/g;
      while ((m = re.exec(t)) !== null) { var w = m[1].trim(); if (w) words.push(w); }
      if (words.length) return words.join(" ");
      t = t.replace(/[{}()\[\]"]/g, "");
    }
    return t.replace(/\s+/g, " ").trim();
  }

  function resolveNoteDisplayLine(note) {
    if (!note) return "";
    if (note.customText && String(note.customText).length > 0) {
      return String(note.customText);
    }
    var p = store.rb.personality;
    if (p === "wrc_shorthand") return cleanNativeText(note.shorthandText || note.proText || "");
    if (p === "grassroots_clubman") return cleanNativeText(note.clubmanText || note.proText || "");
    return cleanNativeText(note.proText || "");
  }

  function resolveNoteSpokenLine(note) {
    if (!note) return "";
    if (note.customText && String(note.customText).length > 0) {
      return String(note.customText);
    }
    if (store.rb.personality === "grassroots_clubman" && note.clubmanText) {
      return cleanNativeText(note.clubmanText);
    }
    return cleanNativeText(note.proText || note.shorthandText || "");
  }

  function getIconBadgeMeta(iconCode, severity, isPaper) {
    var code = String(iconCode || "CR").toUpperCase();
    var sev = Number(severity || 4);
    var bg = "#16A34A";
    var fg = "#FFFFFF";
    if (code === "CAU") { bg = "#DC2626"; }
    else if (code === "CR" || code === "JMP") { bg = "#EA580C"; }
    else if (code === "HPL" || code === "HPR" || sev <= 2) { bg = "#DC2626"; }
    else if (code === "SQL" || code === "SQR" || sev === 3) { bg = "#D97706"; }
    else if (sev === 4) { bg = "#CA8A04"; }
    if (isPaper) {
      return { bg: "rgba(28,25,23,0.08)", fg: (sev <= 2 || code === "CAU") ? "#B91C1C" : "#1C1917", border: (sev <= 2 || code === "CAU") ? "1.5px solid #B91C1C" : "1.5px solid #44403C", code: code };
    }
    return { bg: bg, fg: fg, border: "none", code: code };
  }

  function getActiveRoadbookNotes() {
    if (store.rb.editMode) return store.rb.draftNotes || [];
    return store.state.roadbookNotes || [];
  }

  function isRoadbookVisibleNow() {
    var st = store.state;
    var ps = st.peerState || {};
    if (store.panelOpen) return false;
    var notes = getActiveRoadbookNotes();
    if (isRallyActiveStatus(ps.status)) {
      if (ps.participationMode === "codriver" && st.role === "DRIVER") return false;
      return ps.participationMode === "codriver" && st.role === "CODRIVER";
    }
    if (ps.status === "FREEROAM_STAGED" && notes && notes.length > 0) {
      if (store.rb.freeroamNotesOpen) return true;
      if (ps.participationMode === "codriver" && st.role === "CODRIVER" && !store.rb.freeroamMinimized) {
        return true;
      }
    }
    if (ps.participationMode === "codriver" && st.role === "CODRIVER") {
      return Boolean(notes && notes.length > 0 && st.activeMissionId);
    }
    return false;
  }

  function flipRoadbookPage(delta) {
    var notes = getActiveRoadbookNotes();
    var perPage = Math.max(1, Number(store.rb.notesPerPage) || 5);
    var totalPages = Math.max(1, Math.ceil(notes.length / perPage));
    var nextIdx = Math.max(0, Math.min(totalPages - 1, store.rb.pageIndex + delta));
    if (nextIdx === store.rb.pageIndex) return;
    store.rb.pageIndex = nextIdx;
    store.rb.flipAnim = delta > 0 ? "flip-next" : "flip-prev";
    renderRoadbookWindow(true);
    setTimeout(function() {
      store.rb.flipAnim = "";
      var sheetEl = document.getElementById("nrmp-rb-sheet");
      if (sheetEl) sheetEl.className = "nrmp-rb-sheet";
    }, 185);
  }

  function triggerSpeakNote(noteObj) {
    if (!noteObj) return;
    var spoken = resolveNoteSpokenLine(noteObj);
    if (!spoken) return;
    store.rb.selectedNoteId = String(noteObj.id || "");
    store.rb.lastCalledNoteId = String(noteObj.id || "");
    store.rb.lastSpokenNotice = 'Called aloud: "' + spoken + '"';
    renderRoadbookWindow(true);
    if (store.state.codriverClickToCallVoice !== false) {
      callLua(
        "extensions.nativeRallyBridge.vueTriggerManualCallout(" +
          luaStr(noteObj.id || "") + "," +
          luaStr(noteObj.iconCode || "CR") + "," +
          Number(noteObj.severity || 4) + "," +
          Number(noteObj.distanceM || 0) + "," +
          luaStr(spoken) + "," +
          luaStr(cleanNativeText(noteObj.nativeText || noteObj.proText || "")) + "," +
          (noteObj.speakText === true ? "true" : "false") +
        ")"
      );
    }
  }

  function callSelectedRoadbookNote() {
    var notes = getActiveRoadbookNotes();
    var perPage = Math.max(1, Number(store.rb.notesPerPage) || 5);
    var start = store.rb.pageIndex * perPage;
    var end = Math.min(notes.length, start + perPage);
    var target = start;
    for (var idx = start; idx < end; idx++) {
      if (String(notes[idx].id) === store.rb.selectedNoteId) { target = idx; break; }
    }
    if (!notes[target]) return;
    triggerSpeakNote(notes[target]);
    if (target + 1 < end) {
      store.rb.selectedNoteId = String(notes[target + 1].id);
    } else if (target + 1 < notes.length) {
      flipRoadbookPage(1);
      store.rb.selectedNoteId = String(notes[target + 1].id);
    }
    renderRoadbookWindow(true);
  }

  function renderRoadbookWindow(forceRebuild) {
    var winEl = document.getElementById("nrmp-roadbook-win");
    if (!winEl) return;
    if (!store.rb.editMode) setCefTyping(false);

    var st = store.state;
    var ps = st.peerState || {};
    var shouldHideDriverVisual = (ps.participationMode === "codriver" && st.role === "DRIVER" && st.codriverHideDriverNotes !== false);
    applyDriverHideNotesCss(shouldHideDriverVisual);

    if (!isRoadbookVisibleNow()) {
      if (store.lastRbSig !== "hidden") {
        store.lastRbSig = "hidden";
        winEl.className = "";
        winEl.innerHTML = "";
      }
      return;
    }

    var isPaper = store.rb.visualStyle === "grassroots_notepad";
    var notes = getActiveRoadbookNotes();
    var cueNotes = (st.roadbookNotes || []).filter(function(note) { return note && (note.nativeText || String(note.id || "").indexOf("_nb_") >= 0); });
    var perPage = Math.max(1, Number(store.rb.notesPerPage) || 5);
    var totalPages = Math.max(1, Math.ceil(notes.length / perPage));
    if (store.rb.pageIndex >= totalPages) store.rb.pageIndex = totalPages - 1;
    if (store.rb.pageIndex < 0) store.rb.pageIndex = 0;

    winEl.style.left = Math.max(8, Math.min((window.innerWidth || 1440) - 180, store.rb.x)) + "px";
    winEl.style.top = Math.max(8, Math.min((window.innerHeight || 900) - 140, store.rb.y)) + "px";
    winEl.style.width = Math.max(310, Math.min(720, store.rb.width)) + "px";
    winEl.style.height = Math.max(340, Math.min(840, store.rb.height)) + "px";
    winEl.className = "visible " + (isPaper ? "paper" : "digital");

    var rbSig = [
      isPaper ? "P" : "D",
      store.rb.personality,
      perPage,
      store.rb.pageIndex,
      store.rb.fontScale.toFixed(2),
      store.rb.editMode ? "E" : "R",
      store.rb.selectedNoteId,
      store.rb.lastCalledNoteId,
      store.rb.lastSpokenNotice,
      st.currentTrackKey || "",
      st.roadbookCustomSaved ? "saved" : "def",
      notes.length
    ].join("|");

    // While writing notes never rebuild the window on background updates: it destroys the text box you are typing in
    if (!forceRebuild && store.rb.editMode && winEl.firstChild) return;

    if (!forceRebuild && !store.rb.editMode && rbSig === store.lastRbSig) {
      var odoEl = document.getElementById("nrmp-rb-odo-val");
      if (odoEl) odoEl.textContent = "ODO " + Math.round(store.rb.odometerM) + "m";
      return;
    }
    store.lastRbSig = rbSig;

    var startIdx = store.rb.pageIndex * perPage;
    var endIdx = Math.min(notes.length, startIdx + perPage);
    var fontPx = Math.round(15 * store.rb.fontScale);
    var distPx = Math.round(12 * store.rb.fontScale);

    var h = [];
    if (isPaper) {
      h.push('<div class="nrmp-rb-spiral">');
      for (var sr = 0; sr < 11; sr++) h.push('<span class="nrmp-rb-ring"></span>');
      h.push('</div>');
    }

    var stagedObj = getStagedMission();
    var rbStageTitle = ps.activeMissionName || (stagedObj && stagedObj.title) || st.currentTrackKey || "STAGE";
    h.push('<div id="nrmp-rb-drag" class="nrmp-rb-dragbar" title="Drag to move Roadbook anywhere on screen">');
    h.push('  <span class="nrmp-rb-title">' + (isPaper ? "CO-DRIVER PACE PAD" : "DIGITAL ROADBOOK") + ' · ' + escHtml(rbStageTitle) + (ps.status === "FREEROAM_STAGED" ? " [PREP]" : "") + (st.roadbookCustomSaved ? " [SAVED]" : "") + '</span>');
    h.push('  <span id="nrmp-rb-odo-val" class="nrmp-rb-odo">ODO ' + Math.round(store.rb.odometerM) + 'm</span>');
    h.push('</div>');

    h.push('<div class="nrmp-rb-subbar">');
    h.push('  <div class="nrmp-rb-mini-group">');
    h.push('    <button type="button" class="nrmp-rb-chip ' + (!isPaper ? "active" : "") + '" data-rbact="style" data-val="digital_roadbook">Digital</button>');
    h.push('    <button type="button" class="nrmp-rb-chip ' + (isPaper ? "active" : "") + '" data-rbact="style" data-val="grassroots_notepad">Paper Pad</button>');
    h.push('    <button type="button" class="nrmp-rb-chip ' + (store.rb.personality === "pro_descriptive" ? "active" : "") + '" data-rbact="pers" data-val="pro_descriptive">Pro</button>');
    h.push('    <button type="button" class="nrmp-rb-chip ' + (store.rb.personality === "wrc_shorthand" ? "active" : "") + '" data-rbact="pers" data-val="wrc_shorthand">Short</button>');
    h.push('    <button type="button" class="nrmp-rb-chip ' + (store.rb.personality === "grassroots_clubman" ? "active" : "") + '" data-rbact="pers" data-val="grassroots_clubman">Clubman</button>');
    h.push('  </div>');
    h.push('  <div class="nrmp-rb-mini-group">');
    h.push('    <button type="button" class="nrmp-rb-chip" data-rbact="fontdown" title="Smaller text">A-</button>');
    h.push('    <button type="button" class="nrmp-rb-chip" data-rbact="fontup" title="Larger text">A+</button>');
    if (st.codriverWritableTrackNotes !== false) {
      h.push('    <button type="button" class="nrmp-rb-chip ' + (store.rb.editMode ? "active" : "") + '" data-rbact="toggleedit">' + (store.rb.editMode ? "Done" : "Write (Alt+N)") + '</button>');
    }
    if (ps.status === "FREEROAM_STAGED") {
      h.push('    <button type="button" class="nrmp-rb-chip" data-rbact="hidefreeroam" title="Tuck away while mingling in freeroam">Hide</button>');
    }
    if (cueNotes.length > 0) {
      h.push('    <button type="button" class="nrmp-rb-chip ' + (store.rb.nativeCueOpen ? "active" : "") + '" data-rbact="togglecues">Native Cues (' + cueNotes.length + ')</button>');
    }
    h.push('  </div>');
    h.push('</div>');

    if (store.rb.editMode) {
      h.push('<div class="nrmp-rb-subbar">');
      h.push('  <div class="nrmp-rb-mini-group">');
      h.push('    <button type="button" class="nrmp-rb-chip" data-rbact="stampcar">+ Stamp @ Car (' + Math.round(store.rb.odometerM) + 'm)</button>');
      h.push('    <button type="button" class="nrmp-rb-chip" data-rbact="addrow">+ Blank Row</button>');
      h.push('  </div>');
      h.push('  <div class="nrmp-rb-mini-group">');
      h.push('    <button type="button" class="nrmp-rb-chip save" data-rbact="savetrack">Save Track</button>');
      h.push('    <button type="button" class="nrmp-rb-chip" data-rbact="resettrack">Reset</button>');
      h.push('  </div>');
      h.push('</div>');
    }

    h.push('<div id="nrmp-rb-sheet" class="nrmp-rb-sheet ' + store.rb.flipAnim + '">');
    h.push('  <div class="nrmp-rb-rows">');

    if (notes.length === 0) {
      h.push('<div style="padding:18px;text-align:center;opacity:0.75;font-size:13px;">No notes on this sheet yet. Click Write to stamp notes along the track.</div>');
    } else {
      var iconOpts = ["L1","L2","L3","L4","L5","L6","R1","R2","R3","R4","R5","R6","HPL","HPR","SQL","SQR","CR","JMP","CAU"];
      for (var ni = startIdx; ni < endIdx; ni++) {
        var nt = notes[ni];
        var badge = getIconBadgeMeta(nt.iconCode, nt.severity, isPaper);
        var isSel = String(nt.id) === store.rb.selectedNoteId;
        var isCalled = String(nt.id) === store.rb.lastCalledNoteId;

        if (!store.rb.editMode) {
          var rowCls = "nrmp-rb-row read-row" + (isSel ? " selected" : "") + (isCalled ? " called" : "") + (nt.highlightHazard ? " hazard" : "");
          h.push('<div class="' + rowCls + '" data-rbact="speakrow" data-idx="' + ni + '" title="Play this pace note · ' + escHtml(callNoteKeyLabel()) + '">');
          h.push('  <span class="nrmp-rb-dist" style="font-size:' + distPx + 'px">' + Math.round(Number(nt.distanceM || 0)) + 'm</span>');
          h.push('  <span class="nrmp-rb-icon" style="background:' + badge.bg + ';color:' + badge.fg + ';border:' + badge.border + '">' + escHtml(badge.code) + '</span>');
          h.push('  <span class="nrmp-rb-call" style="font-size:' + fontPx + 'px">' + escHtml(resolveNoteDisplayLine(nt)) + (nt.highlightHazard ? ' (!)' : '') + '</span>');
          if (st.codriverClickToCallVoice !== false) {
            h.push('  <span class="nrmp-rb-speak-tag">' + (isCalled ? "CALLED" : "CALL") + '</span>');
          }
          h.push('</div>');
        } else {
          h.push('<div class="nrmp-rb-row' + (nt.highlightHazard ? ' hazard' : '') + '">');
          h.push('  <input type="number" class="nrmp-rb-inp" style="width:58px" data-rbfield="dist" data-idx="' + ni + '" value="' + Math.round(Number(nt.distanceM || 0)) + '" />');
          h.push('  <select class="nrmp-rb-inp" style="width:62px" data-rbfield="icon" data-idx="' + ni + '">');
          for (var io = 0; io < iconOpts.length; io++) {
            var ic = iconOpts[io];
            h.push('<option value="' + ic + '"' + (String(nt.iconCode) === ic ? " selected" : "") + '>' + ic + '</option>');
          }
          h.push('  </select>');
          h.push('  <input type="text" class="nrmp-rb-inp" style="flex:1;min-width:90px" data-rbfield="text" data-idx="' + ni + '" value="' + escHtml(resolveNoteDisplayLine(nt)) + '" />');
          h.push('  <label class="nrmp-rb-tts" title="Speak this row with text-to-speech"><input type="checkbox" data-rbfield="speakText" data-idx="' + ni + '"' + (nt.speakText === true ? " checked" : "") + ' />TTS</label>');
          h.push('  <button type="button" class="nrmp-rb-chip ' + (nt.highlightHazard ? "active" : "") + '" data-rbact="togglehaz" data-idx="' + ni + '" title="Toggle Caution Highlight">!</button>');
          h.push('  <button type="button" class="nrmp-rb-chip" data-rbact="delrow" data-idx="' + ni + '" title="Delete Row">&times;</button>');
          h.push('</div>');
        }
      }
    }

    h.push('  </div>');

    if (store.rb.nativeCueOpen && cueNotes.length > 0) {
      h.push('<div class="nrmp-rb-cuelist" aria-label="Native co-driver cue playlist">');
      h.push('<div class="nrmp-rb-cuehead"><span>NATIVE CUES &middot; tap an icon to hear it, + to copy into your notes</span><button type="button" class="nrmp-rb-chip" data-rbact="addallcues">+ Add All</button></div>');
      h.push('<div class="nrmp-rb-cuegrid">');
      for (var ci = 0; ci < cueNotes.length; ci++) {
        var cueText = cleanNativeText(cueNotes[ci].nativeText || cueNotes[ci].proText || resolveNoteDisplayLine(cueNotes[ci]));
        var cueBadge = getIconBadgeMeta(cueNotes[ci].iconCode, cueNotes[ci].severity, isPaper);
        h.push('<div class="nrmp-rb-cuerow">');
        h.push('  <button type="button" class="nrmp-rb-cue-icon" data-rbact="speakcue" data-idx="' + ci + '" title="Play: ' + escHtml(cueText) + '" style="background:' + cueBadge.bg + ';color:' + cueBadge.fg + ';border:' + (cueBadge.border === "none" ? "2px solid rgba(255,255,255,0.18)" : cueBadge.border) + '"><span class="nrmp-rb-cue-code">' + escHtml(cueBadge.code) + '</span><span class="nrmp-rb-cue-play">&#9654;</span></button>');
        h.push('  <button type="button" class="nrmp-rb-cue" data-rbact="speakcue" data-idx="' + ci + '" title="Play this native cue"><span class="nrmp-rb-cue-d">' + Math.round(Number(cueNotes[ci].distanceM || 0)) + 'm</span><span class="nrmp-rb-cue-t">' + escHtml(cueText) + '</span></button>');
        h.push('  <button type="button" class="nrmp-rb-cue-add" data-rbact="addcue" data-idx="' + ci + '" title="Copy this cue into your own notes">+</button>');
        h.push('</div>');
      }
      h.push('</div>');
      h.push('</div>');
    }

    h.push('</div>');

    h.push('<div class="nrmp-rb-foot">');
    h.push('  <button type="button" class="nrmp-rb-pagebtn prev" data-rbact="prevpage"' + (store.rb.pageIndex <= 0 ? ' disabled' : '') + '>&larr; Prev</button>');
    h.push('  <span style="text-align:center;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">Sheet <strong>' + (store.rb.pageIndex + 1) + ' / ' + totalPages + '</strong> · ' + escHtml(store.rb.lastSpokenNotice || (st.codriverClickToCallVoice !== false ? "Click any note for AI radio call" : "PgUp/PgDn Flip")) + '</span>');
    h.push('  <button type="button" class="nrmp-rb-pagebtn next" data-rbact="nextpage"' + (store.rb.pageIndex >= totalPages - 1 ? ' disabled' : '') + '>Flip Page &rarr;</button>');
    h.push('  <div id="nrmp-rb-resize" title="Drag corner to resize Roadbook"></div>');
    h.push('</div>');

    winEl.innerHTML = h.join("");
  }

  function renderSelectorPanel(forceRebuild) {
    var panelEl = document.getElementById("nrmp-selector-panel");
    var tabBtn = document.getElementById("nrmp-pause-tab-btn");
    if (!panelEl) return;

    if (!store.panelOpen) {
      store.lastPanelSig = "closed";
      panelEl.className = "";
      if (tabBtn) tabBtn.className = "nrmp-pause-tab-btn";
      renderInviteToast();
      return;
    }

    panelEl.className = "open";
    if (tabBtn) tabBtn.className = "nrmp-pause-tab-btn active";
    renderInviteToast();

    var st = store.state;
    var ps = st.peerState || {};
    var prop = getActiveProposal();
    var isProposer = isLocalPlayerProposer(prop);
    var staged = getStagedMission();
    var isStagedProp = isLocalPlayerStagedProposer(staged);
    var remSec = getProposalRemainingSec();
    var missions = st.missions || [];

    var panelSig = [
      "open",
      ps.status || "",
      ps.currentLevel || "",
      ps.participationMode || "",
      ps.launchMode || "",
      ps.staggerSlotSeconds || 60,
      ps.recceEnabled ? "1" : "0",
      st.vehicleMode || "",
      st.defaultVehicleChoice || "",
      st.countdownDisplay || "3d",
      store.statusNotice || "",
      prop ? (prop.id + ":" + (isProposer ? "1" : "0") + ":" + (prop.actionType || "")) : "noprop",
      staged ? (staged.missionId + ":" + (isStagedProp ? "1" : "0")) : "nostaged",
      missions.length
    ].join("|");

    if (!forceRebuild && panelSig === store.lastPanelSig) {
      var pRtt = document.getElementById("nrmp-panel-rtt");
      if (pRtt) pRtt.textContent = "RTT " + Number(st.rttMs || 0) + "ms";
      var pRem = document.getElementById("nrmp-panel-rem");
      if (pRem) pRem.textContent = remSec + "s";
      return;
    }
    store.lastPanelSig = panelSig;

    var loops = [];
    var stages = [];
    for (var i = 0; i < missions.length; i++) {
      if (missions[i].missionType === "rallyLoop") loops.push(missions[i]);
      else if (missions[i].missionType === "rallyStage") stages.push(missions[i]);
    }

    var h = [];
    h.push('<header class="nrmp-toolbar">');
    h.push('  <div class="nrmp-brand"><span class="nrmp-brand-slash"></span><div>');
    h.push('    <h2 class="nrmp-title">BeamMP Native Rally Mode</h2>');
    h.push('    <div class="nrmp-sub">Map: ' + escHtml((ps.currentLevel || "freeroam").toUpperCase()) + ' · <span id="nrmp-panel-rtt">RTT ' + Number(st.rttMs || 0) + 'ms</span> · All Maps &amp; Rally Modes Unlocked</div>');
    h.push('  </div></div>');
    h.push('  <div class="nrmp-controls">');

    if (st.defaultVehicleChoice === "host_chooses") {
      h.push('    <div class="nrmp-cluster"><span class="nrmp-cluster-lbl">Vehicle:</span>');
      h.push('      <button type="button" class="nrmp-seg ' + (st.vehicleMode === "own_mp_car" ? "active" : "") + '" data-act="veh" data-val="own_mp_car">Own MP Car</button>');
      h.push('      <button type="button" class="nrmp-seg ' + (st.vehicleMode === "stage_preset_car" ? "active" : "") + '" data-act="veh" data-val="stage_preset_car">Stage Preset Car</button>');
      h.push('    </div>');
    }

    h.push('    <div class="nrmp-cluster"><span class="nrmp-cluster-lbl">Crew:</span>');
    if (ps.participationMode === "codriver") {
      h.push('      <span class="nrmp-seg active" style="pointer-events:none;background:#2563eb;color:#fff;font-weight:700">Shared Co-Driver (Cockpit Active)</span>');
    } else {
      h.push('      <span class="nrmp-seg" style="pointer-events:none;color:#94a3b8">2-Car (Enter partner\'s car for Co-Driver)</span>');
    }
    h.push('    </div>');

    h.push('    <div class="nrmp-cluster"><span class="nrmp-cluster-lbl">Clock:</span>');
    h.push('      <button type="button" class="nrmp-seg ' + (ps.launchMode === "wrc_staggered" ? "active" : "") + '" data-act="clock" data-val="wrc_staggered">WRC +' + Number(ps.staggerSlotSeconds || 60) + 's</button>');
    h.push('      <button type="button" class="nrmp-seg ' + (ps.launchMode === "simultaneous_ghost" ? "active" : "") + '" data-act="clock" data-val="simultaneous_ghost">Simultaneous</button>');
    h.push('    </div>');

    h.push('    <button type="button" class="nrmp-close-btn" data-act="close">Close</button>');
    h.push('  </div>');
    h.push('</header>');

    h.push('<div class="nrmp-scroll-body">');

    if (store.statusNotice) {
      h.push('<div class="nrmp-status-bar"><span>' + escHtml(store.statusNotice) + '</span></div>');
    }

    if (prop) {
      var vText = prop.vehicleMode === "stage_preset_car" ? "Stage Preset Car" : "Own MP Car";
      var isStartCheck = prop.actionType === "start_staged";
      if (isProposer) {
        h.push('<div class="nrmp-ready-banner proposer">');
        h.push('  <div><span class="nrmp-ready-kicker proposer">' + (isStartCheck ? "START READY CHECK" : "INVITE SENT") + '</span>Waiting for partner to ' + (isStartCheck ? "confirm Ready to launch " : "accept ") + '<strong>' + escHtml(prop.title) + '</strong> (' + escHtml(prop.levelName || "auto-map") + ' · ' + vText + ') · <span id="nrmp-panel-rem" class="nrmp-timer-pill">' + remSec + 's</span></div>');
        h.push('  <div class="nrmp-btn-row">');
        h.push('    <button type="button" class="nrmp-act-btn nrmp-act-cancel" data-act="cancel">Cancel</button>');
        h.push('  </div>');
        h.push('</div>');
      } else {
        h.push('<div class="nrmp-ready-banner">');
        h.push('  <div><span class="nrmp-ready-kicker">' + (isStartCheck ? "READY TO START RALLY" : "2P RALLY INVITE") + '</span><strong>' + escHtml(prop.proposerName) + '</strong> ' + (isStartCheck ? "is starting staged event " : "invited you to ") + '<strong>' + escHtml(prop.title) + '</strong> (' + escHtml(prop.levelName || "auto-map") + ' · ' + vText + ') · <span id="nrmp-panel-rem" class="nrmp-timer-pill">' + remSec + 's</span></div>');
        h.push('  <div class="nrmp-btn-row">');
        h.push('    <button type="button" class="nrmp-act-btn nrmp-act-accept" data-act="accept">Accept &amp; Ready (Alt+A)</button>');
        h.push('    <button type="button" class="nrmp-act-btn nrmp-act-decline" data-act="decline">Decline (Alt+D)</button>');
        h.push('  </div>');
        h.push('</div>');
      }
    } else if (staged && ps.status === "FREEROAM_STAGED") {
      var stVehText = (st.vehicleMode || staged.vehicleMode) === "stage_preset_car" ? "Stage Preset Car" : "Own MP Car";
      h.push('<div class="nrmp-staged-banner">');
      h.push('  <div><span class="nrmp-staged-kicker">FREEROAM RALLY COURSE ACTIVE</span>Staged on <strong>' + escHtml(staged.levelName || ps.currentLevel) + '</strong>: <strong>' + escHtml(staged.title) + '</strong> (' + stVehText + ') · Barriers &amp; timing gates placed at start line!</div>');
      h.push('  <div class="nrmp-btn-row" style="margin-top:6px;margin-bottom:6px">');
      h.push('    <span style="font-size:11px;font-weight:700;color:#94a3b8;align-self:center;margin-right:4px">SPAWN AT START:</span>');
      h.push('    <button type="button" class="nrmp-act-btn" style="background:#2563eb" data-act="startline_car">Random Rally Car</button>');
      h.push('    <button type="button" class="nrmp-act-btn" style="background:#059669" data-act="startline_foot">On Foot</button>');
      h.push('    <button type="button" class="nrmp-act-btn" style="background:#475569" data-act="startline_curr">Teleport Car</button>');
      h.push('  </div>');
      h.push('  <div class="nrmp-btn-row">');
      if (isStagedProp) {
        h.push('    <button type="button" class="nrmp-act-btn nrmp-act-start" data-act="startstaged">Start Staged Event</button>');
      }
      h.push('    <button type="button" class="nrmp-act-btn nrmp-act-notes" data-act="openstagednotes">Route Notes</button>');
      if (isStagedProp) {
        h.push('    <button type="button" class="nrmp-act-btn nrmp-act-cancel" data-act="clearstaged">Clear Staged</button>');
      }
      h.push('  </div>');
      h.push('</div>');
    }

    if (loops.length > 0) {
      h.push('<section><div class="nrmp-cat-head"><span class="nrmp-slash"></span><h3 class="nrmp-cat-title">Rally Loop</h3><div class="nrmp-cat-line"></div></div><div class="nrmp-grid">');
      for (var li = 0; li < loops.length; li++) {
        var lp = loops[li];
        var lSrc = resolveThumbSrc(lp.previewFile);
        h.push('<button type="button" draggable="false" class="nrmp-card" data-act="mission" data-id="' + escHtml(lp.id) + '">');
        h.push('  <div class="nrmp-thumb">');
        if (lSrc) h.push('<img draggable="false" data-nrmp-thumb="1" src="' + escHtml(lSrc) + '" alt="' + escHtml(lp.name) + '" /><span class="nrmp-thumb-fallback" style="display:none">' + escHtml(lp.levelName || "RALLY LOOP") + '</span>');
        else h.push('<span class="nrmp-thumb-fallback">' + escHtml(lp.levelName || "RALLY LOOP") + '</span>');
        h.push('    <span class="nrmp-map-tag">' + escHtml(lp.levelName) + '</span>');
        h.push('  </div>');
        h.push('  <div class="nrmp-card-foot"><span class="nrmp-card-name">' + escHtml(lp.name) + '</span><span class="nrmp-card-sync">2P</span></div>');
        h.push('</button>');
      }
      h.push('</div></section>');
    }

    if (stages.length > 0) {
      h.push('<section><div class="nrmp-cat-head"><span class="nrmp-slash"></span><h3 class="nrmp-cat-title">Rally Stage</h3><div class="nrmp-cat-line"></div></div><div class="nrmp-grid">');
      for (var si = 0; si < stages.length; si++) {
        var sg = stages[si];
        var sSrc = resolveThumbSrc(sg.previewFile);
        h.push('<button type="button" draggable="false" class="nrmp-card" data-act="mission" data-id="' + escHtml(sg.id) + '">');
        h.push('  <div class="nrmp-thumb">');
        if (sSrc) h.push('<img draggable="false" data-nrmp-thumb="1" src="' + escHtml(sSrc) + '" alt="' + escHtml(sg.name) + '" /><span class="nrmp-thumb-fallback" style="display:none">' + escHtml(sg.levelName || "STAGE") + '</span>');
        else h.push('<span class="nrmp-thumb-fallback">' + escHtml(sg.levelName || "STAGE") + '</span>');
        h.push('    <span class="nrmp-map-tag">' + escHtml(sg.levelName) + '</span>');
        h.push('  </div>');
        h.push('  <div class="nrmp-card-foot"><span class="nrmp-card-name">' + escHtml(sg.name) + '</span><span class="nrmp-card-sync">2P</span></div>');
        h.push('</button>');
      }
      h.push('</div></section>');
    }

    h.push('</div>');

    if (st.unlockNativeRallyFeatures) {
      h.push('<footer class="nrmp-footer">');
      h.push('  <div class="nrmp-tools-row">');
      h.push('    <button type="button" class="nrmp-tool-btn" data-act="recce">' + (ps.recceEnabled ? "Stop 2P Recce" : "2-Player Recce App") + '</button>');
      h.push('    <button type="button" class="nrmp-tool-btn" data-act="voicesettings">Voice &amp; Pace Notes</button>');
      h.push('    <button type="button" class="nrmp-tool-btn" data-act="clockdisp">Clock: ' + escHtml((st.countdownDisplay || "3d").toUpperCase()) + '</button>');
      h.push('    <button type="button" class="nrmp-tool-btn" data-act="swap">Swap Slots</button>');
      h.push('    <button type="button" class="nrmp-tool-btn danger" data-act="stop">Stop Rally</button>');
      h.push('  </div>');
      h.push('</footer>');
    }

    panelEl.innerHTML = h.join("");
    var imgs = panelEl.querySelectorAll("img[data-nrmp-thumb]");
    for (var ti = 0; ti < imgs.length; ti++) {
      imgs[ti].addEventListener("error", function() {
        var cur = this.getAttribute("src") || "";
        if (!this.getAttribute("data-retried") && cur.indexOf("local://local/") === 0) {
          this.setAttribute("data-retried", "1");
          this.setAttribute("src", cur.replace("local://local", ""));
          return;
        }
        this.style.display = "none";
        if (this.nextElementSibling) this.nextElementSibling.style.display = "block";
      });
    }
  }

  function refreshPauseVisibility() {
    var wrapEl = document.getElementById("nrmp-pause-tab-wrap");
    if (!wrapEl) return;

    var explicitPlay = isExplicitPlayRoute();
    var domPause = detectDomPauseOpen();
    var isPauseNow = !explicitPlay && (domPause || (store.inLevel && store.luaMenuOpen));

    if (isPauseNow) {
      wrapEl.className = "visible";
    } else {
      wrapEl.className = "";
      if (!store.forcedStandalone && store.panelOpen) {
        store.panelOpen = false;
        renderSelectorPanel(false);
      }
    }

    renderInviteToast();
    if (store.panelOpen) {
      renderSelectorPanel(false);
    }
  }

  document.getElementById("nrmp-pause-tab-btn").addEventListener("pointerdown", function(ev) {
    if (ev.button !== undefined && ev.button !== 0) return;
    ev.stopPropagation();
    ev.preventDefault();
    store.forcedStandalone = false;
    store.panelOpen = !store.panelOpen;
    if (store.panelOpen) {
      callLua("extensions.nativeRallyBridge.vueRequestState()");
    }
    renderSelectorPanel(true);
  });

  rootEl.addEventListener("dragstart", function(ev) {
    ev.preventDefault();
  });

  function findActBtn(node) {
    var cur = node;
    while (cur && cur !== rootEl && cur !== document) {
      if (cur.nodeType === 1 && cur.getAttribute && cur.getAttribute("data-act")) {
        return cur;
      }
      cur = cur.parentNode;
    }
    return null;
  }

  var lastActionSig = "";
  var lastActionAt = 0;
  var downBtnAct = null;

  function clearLocalPendingProposal() {
    if (store.state && store.state.peerState) {
      store.state.peerState.hasPendingProposal = false;
      store.state.peerState.pendingProposal = false;
    }
    store.inviteExpiresAtMs = 0;
    renderInviteToast();
    if (store.panelOpen) renderSelectorPanel(true);
  }

  function executeActionByCode(act, val, mid) {
    var sig = String(act || "") + "|" + String(val || "") + "|" + String(mid || "");
    var nowT = Date.now();
    if (sig === lastActionSig && (nowT - lastActionAt) < 380) {
      return;
    }
    lastActionSig = sig;
    lastActionAt = nowT;

    if (act === "close") {
      store.panelOpen = false;
      store.forcedStandalone = false;
      renderSelectorPanel(false);
    } else if (act === "voicesettings") {
      openVoicePanel();
    } else if (act === "dismissinvite") {
      var curP = getActiveProposal();
      if (curP && curP.id) {
        store.dismissedProposalId = String(curP.id);
      }
      renderInviteToast();
    } else if (act === "veh") {
      store.state.vehicleMode = val;
      callLua("extensions.nativeRallyBridge.vueSetVehicleMode(" + luaStr(val) + ")");
      renderSelectorPanel(true);
    } else if (act === "crew") {
      callLua("extensions.nativeRallyBridge.vueSetMode(" + luaStr(val) + ")");
    } else if (act === "clock") {
      callLua("extensions.nativeRallyBridge.vueSetLaunchMode(" + luaStr(val) + ")");
    } else if (act === "mission") {
      var ps = store.state.peerState || {};
      store.statusNotice = "Sending 2P Rally invite for: " + String(mid) + " ...";
      renderSelectorPanel(true);
      callLua("extensions.nativeRallyBridge.vueProposeMission(" + luaStr(mid) + "," + luaStr(store.state.vehicleMode) + "," + luaStr(ps.participationMode || "two_car") + "," + luaStr(ps.launchMode || "wrc_staggered") + ")");
    } else if (act === "startline_car") {
      store.statusNotice = "Spawning Random Rally Car at starting line...";
      renderSelectorPanel(true);
      callLua("extensions.nativeRallyBridge.vueSpawnAtStartLine('random_rally')");
    } else if (act === "startline_foot") {
      store.statusNotice = "Spawning On Foot at starting line...";
      renderSelectorPanel(true);
      callLua("extensions.nativeRallyBridge.vueSpawnAtStartLine('on_foot')");
    } else if (act === "startline_curr") {
      store.statusNotice = "Teleporting car to starting line...";
      renderSelectorPanel(true);
      callLua("extensions.nativeRallyBridge.vueSpawnAtStartLine('current_car')");
    } else if (act === "startstaged") {
      store.statusNotice = store.state.requirePartnerReadyCheck === false ? "Starting staged Rally event..." : "Requesting Partner Ready-Check to start staged Rally event...";
      renderSelectorPanel(true);
      callLua("extensions.nativeRallyBridge.vueStartStagedEvent(" + luaStr(store.state.vehicleMode) + ")");
    } else if (act === "clearstaged") {
      store.statusNotice = "";
      store.rb.freeroamNotesOpen = false;
      callLua("extensions.nativeRallyBridge.vueClearStagedEvent()");
    } else if (act === "openstagednotes") {
      store.rb.freeroamNotesOpen = true;
      store.rb.freeroamMinimized = false;
      store.panelOpen = false;
      store.forcedStandalone = false;
      renderSelectorPanel(false);
      renderRoadbookWindow(true);
      callLua("if extensions and extensions.ui_router and type(extensions.ui_router.navigate)=='function' then pcall(extensions.ui_router.navigate,'play') end if guihooks then guihooks.trigger('MenuHide') end");
    } else if (act === "accept") {
      store.statusNotice = "Partner Ready confirmed — syncing Rally...";
      clearLocalPendingProposal();
      callLua("extensions.nativeRallyBridge.vueRespondProposal(true)");
    } else if (act === "decline") {
      store.statusNotice = "";
      clearLocalPendingProposal();
      callLua("extensions.nativeRallyBridge.vueRespondProposal(false)");
    } else if (act === "cancel") {
      store.statusNotice = "";
      clearLocalPendingProposal();
      callLua("extensions.nativeRallyBridge.vueCancelProposal()");
    } else if (act === "recce") {
      callLua("extensions.nativeRallyBridge.vueToggleRecce()");
    } else if (act === "clockdisp") {
      callLua("extensions.nativeRallyBridge.vueToggleCountdownDisplay()");
    } else if (act === "swap") {
      callLua("extensions.nativeRallyBridge.vueSwapSlots()");
    } else if (act === "stop") {
      store.statusNotice = "";
      callLua("extensions.nativeRallyBridge.vueStopMission()");
    }
  }

  function handleActionButton(btn) {
    if (!btn) return;
    executeActionByCode(
      btn.getAttribute("data-act"),
      btn.getAttribute("data-val"),
      btn.getAttribute("data-id") || ""
    );
  }

  function isImmediatePressAction(act) {
    return act === "accept" || act === "decline" || act === "cancel" || act === "dismissinvite" || act === "close" || act === "veh" || act === "crew" || act === "clock" || act === "startstaged" || act === "clearstaged" || act === "openstagednotes";
  }

  rootEl.addEventListener("pointerdown", function(ev) {
    if (ev.button !== undefined && ev.button !== 0) return;
    var btn = findActBtn(ev.target);
    if (!btn) {
      downBtnAct = null;
      return;
    }
    var act = btn.getAttribute("data-act");
    if (isImmediatePressAction(act)) {
      ev.stopPropagation();
      ev.preventDefault();
      downBtnAct = null;
      handleActionButton(btn);
      return;
    }
    downBtnAct = btn;
  });

  rootEl.addEventListener("mousedown", function(ev) {
    if (ev.button !== undefined && ev.button !== 0) return;
    var btn = findActBtn(ev.target);
    if (!btn) return;
    var act = btn.getAttribute("data-act");
    if (isImmediatePressAction(act)) {
      ev.stopPropagation();
      ev.preventDefault();
      handleActionButton(btn);
    }
  });

  rootEl.addEventListener("pointerup", function(ev) {
    if (ev.button !== undefined && ev.button !== 0) return;
    var upBtn = findActBtn(ev.target);
    if (upBtn && downBtnAct && upBtn === downBtnAct) {
      downBtnAct = null;
      handleActionButton(upBtn);
    }
  });

  function findRbBtn(node) {
    var cur = node;
    while (cur && cur !== rootEl && cur !== document) {
      if (cur.nodeType === 1 && cur.getAttribute && cur.getAttribute("data-rbact")) {
        return cur;
      }
      cur = cur.parentNode;
    }
    return null;
  }

  function cloneNotesArray(arr) {
    var out = [];
    for (var i = 0; i < (arr || []).length; i++) {
      var item = arr[i] || {};
      var copy = {};
      for (var k in item) {
        if (Object.prototype.hasOwnProperty.call(item, k)) copy[k] = item[k];
      }
      out.push(copy);
    }
    return out;
  }

  function handleRoadbookAction(btn) {
    if (!btn) return;
    var rbAct = btn.getAttribute("data-rbact");
    var val = btn.getAttribute("data-val") || "";
    var idx = Number(btn.getAttribute("data-idx") || 0);

    if (rbAct === "style") {
      store.rb.visualStyle = val;
      persistRbPrefs();
      renderRoadbookWindow(true);
    } else if (rbAct === "pers") {
      store.rb.personality = val;
      persistRbPrefs();
      renderRoadbookWindow(true);
    } else if (rbAct === "fontdown") {
      store.rb.fontScale = Math.max(0.82, Number((store.rb.fontScale - 0.08).toFixed(2)));
      persistRbPrefs();
      renderRoadbookWindow(true);
    } else if (rbAct === "fontup") {
      store.rb.fontScale = Math.min(1.45, Number((store.rb.fontScale + 0.08).toFixed(2)));
      persistRbPrefs();
      renderRoadbookWindow(true);
    } else if (rbAct === "prevpage") {
      flipRoadbookPage(-1);
    } else if (rbAct === "nextpage") {
      flipRoadbookPage(1);
    } else if (rbAct === "speakrow") {
      var rNotes = getActiveRoadbookNotes();
      if (rNotes[idx]) triggerSpeakNote(rNotes[idx]);
    } else if (rbAct === "togglecues") {
      store.rb.nativeCueOpen = !store.rb.nativeCueOpen;
      renderRoadbookWindow(true);
    } else if (rbAct === "speakcue") {
      var cueNotes = (store.state.roadbookNotes || []).filter(function(note) { return note && (note.nativeText || String(note.id || "").indexOf("_nb_") >= 0); });
      if (cueNotes[idx]) {
        var nativeCue = {};
        for (var cueKey in cueNotes[idx]) {
          if (Object.prototype.hasOwnProperty.call(cueNotes[idx], cueKey)) nativeCue[cueKey] = cueNotes[idx][cueKey];
        }
        nativeCue.customText = "";
        nativeCue.proText = cleanNativeText(nativeCue.nativeText || nativeCue.proText || "");
        nativeCue.clubmanText = nativeCue.proText;
        nativeCue.shorthandText = nativeCue.proText;
        nativeCue.speakText = false;
        triggerSpeakNote(nativeCue);
      }
    } else if (rbAct === "addcue" || rbAct === "addallcues") {
      var srcCues = (store.state.roadbookNotes || []).filter(function(note) { return note && (note.nativeText || String(note.id || "").indexOf("_nb_") >= 0); });
      var picks = rbAct === "addcue" ? (srcCues[idx] ? [srcCues[idx]] : []) : srcCues;
      if (picks.length === 0) return;
      if (!store.rb.editMode) {
        store.rb.draftTrackKey = String(store.state.currentTrackKey || store.state.activeMissionId || "default_track");
        store.rb.draftNotes = cloneNotesArray(store.state.roadbookNotes || []);
        store.rb.editMode = true;
      }
      var lastAdded = null;
      for (var pi = 0; pi < picks.length; pi++) {
        var src = picks[pi];
        var cueTxt = cleanNativeText(src.nativeText || src.proText || "");
        var dup = false;
        for (var di = 0; di < store.rb.draftNotes.length; di++) {
          var dn = store.rb.draftNotes[di];
          if (dn && dn.isCustom && dn.fromCueId === src.id) { dup = true; break; }
        }
        if (dup) continue;
        lastAdded = {
          id: "cust_" + Date.now() + "_" + pi,
          fromCueId: src.id,
          distanceM: Number(src.distanceM || 0),
          linkDistanceM: Number(src.linkDistanceM || 80),
          iconCode: src.iconCode || "CR",
          severity: src.severity || 4,
          proText: cueTxt,
          shorthandText: cueTxt,
          clubmanText: cueTxt,
          customText: cueTxt,
          highlightHazard: src.highlightHazard === true,
          isCustom: true
        };
        store.rb.draftNotes.push(lastAdded);
      }
      store.rb.draftNotes.sort(function(a, b) { return Number(a.distanceM || 0) - Number(b.distanceM || 0); });
      if (lastAdded) {
        var perPg = Math.max(1, Number(store.rb.notesPerPage) || 5);
        store.rb.pageIndex = Math.floor(store.rb.draftNotes.indexOf(lastAdded) / perPg);
        store.rb.selectedNoteId = String(lastAdded.id);
        store.rb.lastSpokenNotice = rbAct === "addcue" ? "Added to your notes - edit, then Save Track" : "Added " + picks.length + " cues - edit, then Save Track";
      } else {
        store.rb.lastSpokenNotice = "Already in your notes";
      }
      renderRoadbookWindow(true);
    } else if (rbAct === "toggleedit") {
      if (!store.rb.editMode) {
        store.rb.draftTrackKey = String(store.state.currentTrackKey || store.state.activeMissionId || "default_track");
        store.rb.draftNotes = cloneNotesArray(store.state.roadbookNotes || []);
        store.rb.editMode = true;
      } else {
        store.rb.editMode = false;
      }
      renderRoadbookWindow(true);
    } else if (rbAct === "togglehaz") {
      if (store.rb.draftNotes[idx]) {
        store.rb.draftNotes[idx].highlightHazard = !store.rb.draftNotes[idx].highlightHazard;
        renderRoadbookWindow(true);
      }
    } else if (rbAct === "delrow") {
      if (store.rb.draftNotes[idx]) {
        store.rb.draftNotes.splice(idx, 1);
        renderRoadbookWindow(true);
      }
    } else if (rbAct === "addrow") {
      var newNote = {
        id: "cust_" + Date.now(),
        distanceM: Math.round(store.rb.odometerM || 0),
        linkDistanceM: 80,
        iconCode: "CR",
        severity: 4,
        proText: "Caution over crest",
        shorthandText: "CAU / Cr",
        clubmanText: "Watch the crest here",
        customText: "Caution over crest",
        highlightHazard: false,
        isCustom: true
      };
      store.rb.draftNotes.push(newNote);
      var pp = Math.max(1, Number(store.rb.notesPerPage) || 5);
      store.rb.pageIndex = Math.max(0, Math.ceil(store.rb.draftNotes.length / pp) - 1);
      renderRoadbookWindow(true);
    } else if (rbAct === "stampcar") {
      var stamped = {
        id: "stamp_" + Date.now(),
        distanceM: Math.round(store.rb.odometerM || 0),
        linkDistanceM: 60,
        iconCode: "CAU",
        severity: 3,
        proText: "Stamped note at " + Math.round(store.rb.odometerM || 0) + "m",
        shorthandText: "CAU @ " + Math.round(store.rb.odometerM || 0) + "m",
        clubmanText: "Marked spot at " + Math.round(store.rb.odometerM || 0) + "m",
        customText: "Caution at " + Math.round(store.rb.odometerM || 0) + "m",
        highlightHazard: true,
        isCustom: true
      };
      store.rb.draftNotes.push(stamped);
      store.rb.draftNotes.sort(function(a, b) { return Number(a.distanceM || 0) - Number(b.distanceM || 0); });
      renderRoadbookWindow(true);
    } else if (rbAct === "savetrack") {
      store.rb.draftNotes.sort(function(a, b) { return Number(a.distanceM || 0) - Number(b.distanceM || 0); });
      var tKey = String(store.rb.draftTrackKey || store.state.currentTrackKey || store.state.activeMissionId || "default_track");
      store.state.roadbookNotes = cloneNotesArray(store.rb.draftNotes);
      store.state.roadbookCustomSaved = true;
      store.rb.editMode = false;
      store.rb.lastSpokenNotice = "Saved " + store.state.roadbookNotes.length + " notes for track";
      callLua("extensions.nativeRallyBridge.vueSaveEditedTrackNotes(" + luaStr(tKey) + "," + luaStr(JSON.stringify(store.state.roadbookNotes)) + ")");
      renderRoadbookWindow(true);
    } else if (rbAct === "resettrack") {
      var rKey = String(store.rb.draftTrackKey || store.state.currentTrackKey || store.state.activeMissionId || store.state.stagedMissionId || "default_track");
      store.rb.editMode = false;
      store.rb.lastSpokenNotice = "Restored default stage notes";
      callLua("extensions.nativeRallyBridge.vueResetTrackNotes(" + luaStr(rKey) + ")");
      renderRoadbookWindow(true);
    } else if (rbAct === "hidefreeroam") {
      store.rb.freeroamNotesOpen = false;
      store.rb.freeroamMinimized = true;
      renderRoadbookWindow(true);
    }
  }

  var rbDragMode = "";
  var rbStartMouseX = 0;
  var rbStartMouseY = 0;
  var rbStartX = 0;
  var rbStartY = 0;
  var rbStartW = 0;
  var rbStartH = 0;

  rootEl.addEventListener("pointerdown", function(ev) {
    if (ev.button !== undefined && ev.button !== 0) return;
    var t = ev.target;
    if (t && t.id === "nrmp-rb-resize") {
      ev.stopPropagation();
      ev.preventDefault();
      rbDragMode = "resize";
      rbStartMouseX = ev.clientX;
      rbStartMouseY = ev.clientY;
      rbStartW = store.rb.width;
      rbStartH = store.rb.height;
      return;
    }
    var dragBar = document.getElementById("nrmp-rb-drag");
    if (dragBar && (t === dragBar || dragBar.contains(t))) {
      ev.stopPropagation();
      ev.preventDefault();
      rbDragMode = "move";
      rbStartMouseX = ev.clientX;
      rbStartMouseY = ev.clientY;
      rbStartX = store.rb.x;
      rbStartY = store.rb.y;
      return;
    }
  }, true);

  window.addEventListener("pointermove", function(ev) {
    if (!rbDragMode) return;
    var winEl = document.getElementById("nrmp-roadbook-win");
    if (rbDragMode === "move") {
      store.rb.x = Math.max(8, Math.min((window.innerWidth || 1440) - 180, rbStartX + (ev.clientX - rbStartMouseX)));
      store.rb.y = Math.max(8, Math.min((window.innerHeight || 900) - 140, rbStartY + (ev.clientY - rbStartMouseY)));
      if (winEl) {
        winEl.style.left = store.rb.x + "px";
        winEl.style.top = store.rb.y + "px";
      }
    } else if (rbDragMode === "resize") {
      store.rb.width = Math.max(310, Math.min(720, rbStartW + (ev.clientX - rbStartMouseX)));
      store.rb.height = Math.max(340, Math.min(840, rbStartH + (ev.clientY - rbStartMouseY)));
      if (winEl) {
        winEl.style.width = store.rb.width + "px";
        winEl.style.height = store.rb.height + "px";
      }
    }
  });

  window.addEventListener("pointerup", function() {
    if (rbDragMode) {
      rbDragMode = "";
      persistRbPrefs();
    }
  });

  // Give the text boxes real keyboard focus (and stop the game from treating typed letters as driving controls)
  var cefTyping = false;
  function setCefTyping(on) {
    if (cefTyping === on) return;
    cefTyping = on;
    callLua("pcall(function() if setCEFTyping then setCEFTyping(" + (on ? "true" : "false") + ") end if setCEFFocus then setCEFFocus(" + (on ? "true" : "false") + ") end end)");
  }
  rootEl.addEventListener("focusin", function(ev) {
    var t = ev.target;
    if (t && t.getAttribute && t.getAttribute("data-rbfield")) setCefTyping(true);
  });
  rootEl.addEventListener("focusout", function(ev) {
    var n = ev.relatedTarget;
    if (!(n && n.getAttribute && n.getAttribute("data-rbfield"))) setCefTyping(false);
  });

  rootEl.addEventListener("input", function(ev) {
    var t = ev.target;
    if (!t || !t.getAttribute) return;
    var fld = t.getAttribute("data-rbfield");
    if (!fld) return;
    var idx = Number(t.getAttribute("data-idx") || 0);
    var item = store.rb.draftNotes[idx];
    if (!item) return;
    if (fld === "dist") {
      item.distanceM = Number(t.value || 0);
    } else if (fld === "icon") {
      item.iconCode = String(t.value || "CR");
      var d = parseInt(item.iconCode.slice(1), 10);
      if (!isNaN(d) && d >= 1 && d <= 6) item.severity = d;
    } else if (fld === "text") {
      item.customText = String(t.value || "");
      item.isCustom = true;
    } else if (fld === "speakText") {
      item.speakText = t.checked === true;
    }
  });

  rootEl.addEventListener("click", function(ev) {
    var rbBtn = findRbBtn(ev.target);
    if (rbBtn) {
      ev.stopPropagation();
      handleRoadbookAction(rbBtn);
      return;
    }
    var btn = findActBtn(ev.target);
    if (btn) {
      ev.stopPropagation();
      handleActionButton(btn);
    }
  });

  window.addEventListener("hashchange", refreshPauseVisibility);

  window.addEventListener("keydown", function(ev) {
    if (voicePrefs && voicePrefs.captureCallKey) {
      if (ev.key === "Escape") {
        voicePrefs.captureCallKey = false;
        renderVoicePanel();
        ev.preventDefault();
        return;
      }
      if (ev.key === "Control" || ev.key === "Alt" || ev.key === "Shift") return;
      voicePrefs.callNoteKey = { code: String(ev.code || ev.key || "Space"), ctrl: ev.ctrlKey === true, alt: ev.altKey === true, shift: ev.shiftKey === true };
      voicePrefs.captureCallKey = false;
      saveVoicePrefs();
      renderVoicePanel();
      ev.preventDefault();
      ev.stopPropagation();
      return;
    }
    if (ev.key === "Escape" && store.forcedStandalone && store.panelOpen) {
      store.panelOpen = false;
      store.forcedStandalone = false;
      renderSelectorPanel(false);
      return;
    }

    var activeTag = document.activeElement && document.activeElement.tagName ? String(document.activeElement.tagName).toLowerCase() : "";
    if (activeTag === "input" || activeTag === "textarea" || activeTag === "select") {
      return;
    }

    if (ev.altKey && String(ev.key || "").toLowerCase() === "v") {
      ev.preventDefault();
      openVoicePanel();
      return;
    }

    if (ev.altKey && String(ev.key || "").toLowerCase() === "t") {
      ev.preventDefault();
      toggleSubtitles(ev.shiftKey === true);
      return;
    }

    if (isRoadbookVisibleNow()) {
      if (ev.key === "PageDown" || (ev.altKey && String(ev.key || "").toLowerCase() === "x")) {
        ev.preventDefault();
        flipRoadbookPage(1);
        return;
      }
      if (ev.key === "PageUp" || (ev.altKey && String(ev.key || "").toLowerCase() === "z")) {
        ev.preventDefault();
        flipRoadbookPage(-1);
        return;
      }
      if (ev.altKey && String(ev.key || "").toLowerCase() === "n" && store.state.codriverWritableTrackNotes !== false) {
        ev.preventDefault();
        store.rb.editMode = !store.rb.editMode;
        if (store.rb.editMode) {
          store.rb.draftTrackKey = String(store.state.currentTrackKey || store.state.activeMissionId || "default_track");
          store.rb.draftNotes = cloneNotesArray(store.state.roadbookNotes || []);
        }
        renderRoadbookWindow(true);
        return;
      }
      if (matchesCallNoteKey(ev) && !store.rb.editMode && store.state.codriverClickToCallVoice !== false) {
        ev.preventDefault();
        callSelectedRoadbookNote();
        return;
      }
    }

    if (ev.altKey) {
      var prop = getActiveProposal();
      if (!prop) return;
      var k = String(ev.key || "").toLowerCase();
      if (!isLocalPlayerProposer(prop)) {
        if (k === "a") {
          ev.preventDefault();
          executeActionByCode("accept", "", "");
        } else if (k === "d") {
          ev.preventDefault();
          executeActionByCode("decline", "", "");
        }
      } else if (k === "c") {
        ev.preventDefault();
        executeActionByCode("cancel", "", "");
      }
    }
  });

  setInterval(refreshPauseVisibility, 200);

  // ---- Accessibility: on-screen subtitles for every spoken pacenote ----
  var subPrefs = { on: true, size: 1 };
  try {
    var rawSub = window.localStorage && window.localStorage.getItem("nrmp_subtitles_v1");
    if (rawSub) {
      var subObj = JSON.parse(rawSub) || {};
      subPrefs.on = subObj.on !== false;
      if (subObj.size === 0 || subObj.size === 1 || subObj.size === 2) subPrefs.size = subObj.size;
    }
  } catch (errSubP) {}
  var SUB_FONT_PX = [20, 28, 40];
  var subHideTimer = null;
  var lastSubText = "";
  var lastSubAt = 0;

  function saveSubPrefs() {
    try { if (window.localStorage) window.localStorage.setItem("nrmp_subtitles_v1", JSON.stringify(subPrefs)); } catch (errSubS) {}
  }

  function paintSubtitle(text, who, holdMs) {
    var el = document.getElementById("nrmp-subtitle");
    if (!el) return;
    el.style.fontSize = SUB_FONT_PX[subPrefs.size] + "px";
    el.innerHTML = (who ? '<span class="nrmp-sub-who">' + escHtml(who) + '</span>' : "") + escHtml(text);
    el.classList.add("visible");
    if (subHideTimer) clearTimeout(subHideTimer);
    subHideTimer = setTimeout(function() { el.classList.remove("visible"); }, holdMs);
  }

  function showSubtitle(pkt) {
    if (!subPrefs.on || !pkt) return;
    var text = String(pkt.text || "").trim();
    if (!text) return;
    var now = Date.now();
    if (text === lastSubText && (now - lastSubAt) < 1800) return;
    lastSubText = text;
    lastSubAt = now;
    var holdMs = Math.max(2800, Math.min(9000, text.length * 75));
    paintSubtitle(text, String(pkt.speaker || "CO-DRIVER"), holdMs);
  }

  function toggleSubtitles(cycleSize) {
    if (cycleSize) {
      subPrefs.size = (subPrefs.size + 1) % 3;
      subPrefs.on = true;
    } else {
      subPrefs.on = !subPrefs.on;
    }
    saveSubPrefs();
    if (subPrefs.on) {
      paintSubtitle("Subtitles ON  (Alt+T toggle · Alt+Shift+T text size)", "RALLY CAPTIONS", 2600);
    } else {
      var el = document.getElementById("nrmp-subtitle");
      if (el) el.classList.remove("visible");
    }
  }

  // ---- Fallback voice customisation (used when no native in-game voice sample exists) ----
  var VOICE_PRESETS = {
    pro:   { label: "Pro Co-Driver (fast, clear)", rate: 1.15, pitch: 1.0 },
    calm:  { label: "Calm Recce",                  rate: 0.95, pitch: 0.9 },
    rapid: { label: "Rapid Fire (WRC pace)",       rate: 1.4,  pitch: 1.05 },
    deep:  { label: "Deep Radio",                  rate: 1.05, pitch: 0.65 },
    bright:{ label: "Bright & Upbeat",             rate: 1.1,  pitch: 1.3 }
  };
  var voicePrefs = { ttsOn: true, voiceURI: "", rate: 1.15, pitch: 1.0, volume: 1.0, preferNative: true, callNoteKey: { code: "Space", alt: true, ctrl: false, shift: false }, captureCallKey: false };
  try {
    var rawVp = window.localStorage && window.localStorage.getItem("nrmp_voice_v1");
    if (rawVp) {
      var vpObj = JSON.parse(rawVp) || {};
      if (typeof vpObj.ttsOn === "boolean") voicePrefs.ttsOn = vpObj.ttsOn;
      if (typeof vpObj.preferNative === "boolean") voicePrefs.preferNative = vpObj.preferNative;
      if (typeof vpObj.voiceURI === "string") voicePrefs.voiceURI = vpObj.voiceURI;
      if (vpObj.callNoteKey && typeof vpObj.callNoteKey.code === "string") voicePrefs.callNoteKey = vpObj.callNoteKey;
      ["rate", "pitch", "volume"].forEach(function(k) {
        var n = Number(vpObj[k]);
        if (isFinite(n)) voicePrefs[k] = n;
      });
    }
  } catch (errVp) {}
  var voicePanelOpen = false;

  function saveVoicePrefs() {
    try { if (window.localStorage) window.localStorage.setItem("nrmp_voice_v1", JSON.stringify(voicePrefs)); } catch (errVs) {}
  }

  function callNoteKeyLabel() {
    var key = voicePrefs.callNoteKey || {};
    var parts = [];
    if (key.ctrl) parts.push("Ctrl");
    if (key.alt) parts.push("Alt");
    if (key.shift) parts.push("Shift");
    var keyName = key.code === "Space" ? "Space" : String(key.code || "").replace(/^Key/, "").replace(/^Digit/, "");
    parts.push(keyName || "Unbound");
    return parts.join("+");
  }

  function matchesCallNoteKey(ev) {
    var key = voicePrefs.callNoteKey || {};
    return String(ev.code || ev.key || "") === String(key.code || "Space") &&
      ev.ctrlKey === (key.ctrl === true) && ev.altKey === (key.alt === true) && ev.shiftKey === (key.shift === true);
  }

  function pushPreferNativeToLua() {
    callLua("extensions.nativeRallyBridge.vueSetPreferNativeVoice(" + (voicePrefs.preferNative ? "true" : "false") + ")");
  }
  setTimeout(pushPreferNativeToLua, 2000);

  function listSystemVoices() {
    try {
      if (window.speechSynthesis && typeof window.speechSynthesis.getVoices === "function") {
        return window.speechSynthesis.getVoices() || [];
      }
    } catch (errLv) {}
    return [];
  }

  function speakFallback(text, force) {
    if ((!voicePrefs.ttsOn && !force) || !window.speechSynthesis || typeof window.SpeechSynthesisUtterance !== "function") return;
    try {
      window.speechSynthesis.cancel();
      var utt = new window.SpeechSynthesisUtterance(String(text));
      var vs = listSystemVoices();
      for (var i = 0; i < vs.length; i++) {
        if (vs[i].voiceURI === voicePrefs.voiceURI) { utt.voice = vs[i]; utt.lang = vs[i].lang; break; }
      }
      utt.rate = Math.max(0.5, Math.min(2.0, voicePrefs.rate));
      utt.pitch = Math.max(0.3, Math.min(2.0, voicePrefs.pitch));
      utt.volume = Math.max(0, Math.min(1, voicePrefs.volume));
      window.speechSynthesis.speak(utt);
    } catch (errSf) {}
  }

  function renderVoicePanel() {
    var el = document.getElementById("nrmp-voice-panel");
    if (!el) return;
    if (!voicePanelOpen) { el.classList.remove("visible"); return; }

    var vs = listSystemVoices().slice().sort(function(a, b) {
      var ae = String(a.lang || "").toLowerCase().indexOf("en") === 0 ? 0 : 1;
      var be2 = String(b.lang || "").toLowerCase().indexOf("en") === 0 ? 0 : 1;
      if (ae !== be2) return ae - be2;
      return String(a.name).localeCompare(String(b.name));
    });
    var vOpts = ['<option value="">System default</option>'];
    for (var i = 0; i < vs.length; i++) {
      vOpts.push('<option value="' + escHtml(vs[i].voiceURI) + '"' + (vs[i].voiceURI === voicePrefs.voiceURI ? " selected" : "") + '>' + escHtml(vs[i].name + " (" + vs[i].lang + ")") + '</option>');
    }
    var pOpts = ['<option value="">Custom</option>'];
    for (var pk in VOICE_PRESETS) {
      if (Object.prototype.hasOwnProperty.call(VOICE_PRESETS, pk)) pOpts.push('<option value="' + pk + '">' + escHtml(VOICE_PRESETS[pk].label) + '</option>');
    }
    var sizeNames = ["Small", "Medium", "Large"];
    var sOpts = sizeNames.map(function(n, idx) { return '<option value="' + idx + '"' + (subPrefs.size === idx ? " selected" : "") + '>' + n + '</option>'; }).join("");

    el.innerHTML = [
      '<h3><span>Voice &amp; Pace Notes</span><button type="button" id="nrmp-vp-close">&#10005;</button></h3>',
      '<label><span>Subtitles</span><input type="checkbox" id="nrmp-vp-subs"' + (subPrefs.on ? " checked" : "") + '></label>',
      '<label><span>Subtitle size</span><select id="nrmp-vp-subsize">' + sOpts + '</select></label>',
      '<label><span>Use in-game co-driver voice for pace notes</span><input type="checkbox" id="nrmp-vp-native"' + (voicePrefs.preferNative ? " checked" : "") + '></label>',
      '<label><span>Game\'s automatic calls while driving</span><input type="checkbox" id="nrmp-vp-autocalls"' + (store.state.aiVoiceMutedKeepOff ? "" : " checked") + '></label>',
      '<label><span>Call timing</span><span><button type="button" id="nrmp-vp-earlier">Earlier 0.1s</button> <button type="button" id="nrmp-vp-later">Later 0.1s</button></span></label>',
      '<label><span>Speak fallback voice aloud</span><input type="checkbox" id="nrmp-vp-tts"' + (voicePrefs.ttsOn ? " checked" : "") + '></label>',
      '<label><span>Call selected note</span><button type="button" id="nrmp-vp-callkey">' + (voicePrefs.captureCallKey ? "Press a key..." : escHtml(callNoteKeyLabel())) + '</button></label>',
      '<label><span>Preset</span><select id="nrmp-vp-preset">' + pOpts.join("") + '</select></label>',
      '<label><span>Voice</span><select id="nrmp-vp-voice">' + vOpts.join("") + '</select></label>',
      '<label><span>Speed <b id="nrmp-vp-rate-v">' + voicePrefs.rate.toFixed(2) + '</b></span><input type="range" id="nrmp-vp-rate" min="0.6" max="1.8" step="0.05" value="' + voicePrefs.rate + '"></label>',
      '<label><span>Pitch <b id="nrmp-vp-pitch-v">' + voicePrefs.pitch.toFixed(2) + '</b></span><input type="range" id="nrmp-vp-pitch" min="0.4" max="1.6" step="0.05" value="' + voicePrefs.pitch + '"></label>',
      '<label><span>Volume <b id="nrmp-vp-vol-v">' + Math.round(voicePrefs.volume * 100) + '%</b></span><input type="range" id="nrmp-vp-vol" min="0" max="1" step="0.05" value="' + voicePrefs.volume + '"></label>',
      '<button type="button" id="nrmp-vp-test">&#9654; Test voice + caption</button>',
      '<div class="nrmp-vp-note">' + (vs.length ? vs.length + " system voices found. " : "No system voices reported by the game UI - the default voice will be used. ") + 'The in-game co-driver voice speaks every pace note that exists in the stage notebook (in any style: Pro, Short or Clubman). The browser fallback voice is only used for custom/stamped notes with no in-game recording. Captions always show. Shortcuts: Alt+T captions, Alt+V this panel.</div>'
    ].join("");

    function byId(id) { return document.getElementById(id); }
    byId("nrmp-vp-close").onclick = function() { voicePanelOpen = false; renderVoicePanel(); };
    byId("nrmp-vp-subs").onchange = function() { subPrefs.on = this.checked; saveSubPrefs(); if (!subPrefs.on) { var se = document.getElementById("nrmp-subtitle"); if (se) se.classList.remove("visible"); } };
    byId("nrmp-vp-subsize").onchange = function() { subPrefs.size = Number(this.value) || 0; saveSubPrefs(); };
    byId("nrmp-vp-native").onchange = function() { voicePrefs.preferNative = this.checked; saveVoicePrefs(); pushPreferNativeToLua(); };
    byId("nrmp-vp-autocalls").onchange = function() { callLua("extensions.nativeRallyBridge.vueToggleAiVoicepack()"); };
    byId("nrmp-vp-earlier").onclick = function() { callLua("extensions.nativeRallyBridge.vueNudgeCodriverTiming(true)"); };
    byId("nrmp-vp-later").onclick = function() { callLua("extensions.nativeRallyBridge.vueNudgeCodriverTiming(false)"); };
    byId("nrmp-vp-tts").onchange = function() { voicePrefs.ttsOn = this.checked; saveVoicePrefs(); };
    byId("nrmp-vp-callkey").onclick = function() { voicePrefs.captureCallKey = true; renderVoicePanel(); };
    byId("nrmp-vp-voice").onchange = function() { voicePrefs.voiceURI = this.value; saveVoicePrefs(); };
    byId("nrmp-vp-preset").onchange = function() {
      var pr = VOICE_PRESETS[this.value];
      if (!pr) return;
      voicePrefs.rate = pr.rate; voicePrefs.pitch = pr.pitch; saveVoicePrefs();
      byId("nrmp-vp-rate").value = pr.rate; byId("nrmp-vp-pitch").value = pr.pitch;
      byId("nrmp-vp-rate-v").textContent = pr.rate.toFixed(2); byId("nrmp-vp-pitch-v").textContent = pr.pitch.toFixed(2);
    };
    byId("nrmp-vp-rate").oninput = function() { voicePrefs.rate = Number(this.value); byId("nrmp-vp-rate-v").textContent = voicePrefs.rate.toFixed(2); byId("nrmp-vp-preset").value = ""; saveVoicePrefs(); };
    byId("nrmp-vp-pitch").oninput = function() { voicePrefs.pitch = Number(this.value); byId("nrmp-vp-pitch-v").textContent = voicePrefs.pitch.toFixed(2); byId("nrmp-vp-preset").value = ""; saveVoicePrefs(); };
    byId("nrmp-vp-vol").oninput = function() { voicePrefs.volume = Number(this.value); byId("nrmp-vp-vol-v").textContent = Math.round(voicePrefs.volume * 100) + "%"; saveVoicePrefs(); };
    byId("nrmp-vp-test").onclick = function() {
      var sample = "One hundred, left four, tightens three, don't cut";
      showSubtitle({ text: sample + " (voice test)", speaker: "CO-DRIVER" });
      speakFallback(sample, true);
    };
    el.classList.add("visible");
  }

  function openVoicePanel() { voicePanelOpen = !voicePanelOpen; renderVoicePanel(); }

  try {
    if (window.speechSynthesis) {
      window.speechSynthesis.onvoiceschanged = function() { if (voicePanelOpen) renderVoicePanel(); };
    }
  } catch (errOv) {}

  window.__NativeRallyMP = {
    mounted: true,
    openVoicePanel: openVoicePanel,
    showSubtitle: showSubtitle,
    toggleSubtitles: toggleSubtitles,
    updateState: function(payload) {
      if (!payload) return;
      var prevTrackKey = store.state.currentTrackKey;
      for (var k in payload) {
        if (Object.prototype.hasOwnProperty.call(payload, k)) {
          store.state[k] = payload[k];
        }
      }
      if (payload.currentTrackKey && payload.currentTrackKey !== prevTrackKey) {
        store.rb.pageIndex = 0;
        store.rb.selectedNoteId = "";
        store.rb.lastCalledNoteId = "";
        store.rb.lastSpokenNotice = "";
        store.rb.freeroamMinimized = false;
      }
      var ps = store.state.peerState || {};
      if (isRallyActiveStatus(ps.status)) {
        store.rb.freeroamNotesOpen = false;
        store.rb.freeroamMinimized = false;
      }
      var tabLblEl = document.getElementById("nrmp-pause-tab-label");
      if (tabLblEl) {
        tabLblEl.textContent = (ps.status === "FREEROAM_STAGED" && getStagedMission())
          ? "Rally Mode (2P) · Staged Ready"
          : "Rally Mode (2P)";
      }
      var p = ps.pendingProposal;
      if (p && typeof p === "object" && p.id && ps.hasPendingProposal !== false) {
        store.statusNotice = "";
        if (String(p.id) !== store.lastInviteId) {
          store.lastInviteId = String(p.id);
          store.dismissedProposalId = "";
          var rem = Number(p.remainingSec || p.timeoutSec || 30);
          store.inviteExpiresAtMs = Date.now() + Math.max(1, rem) * 1000;
        } else if (p.remainingSec !== undefined) {
          store.inviteExpiresAtMs = Date.now() + Math.max(1, Number(p.remainingSec)) * 1000;
        }
      } else {
        store.lastInviteId = "";
        store.inviteExpiresAtMs = 0;
        if (store.state.peerState) {
          store.state.peerState.hasPendingProposal = false;
          store.state.peerState.pendingProposal = false;
        }
      }
      renderInviteToast();
      renderHudStrip();
      renderRoadbookWindow(false);
      if (store.panelOpen) renderSelectorPanel(false);
      refreshPauseVisibility();
    },
    updateOdometer: function(meters) {
      store.rb.odometerM = Math.max(0, Number(meters || 0));
      var odoEl = document.getElementById("nrmp-rb-odo-val");
      if (odoEl) odoEl.textContent = "ODO " + Math.round(store.rb.odometerM) + "m";
    },
    setDriverHideVisualNotes: function(hideBool) {
      applyDriverHideNotesCss(Boolean(hideBool));
    },
    playManualCallout: function(pkt) {
      if (!pkt || !pkt.callText) return;
      showSubtitle({ text: pkt.callText, speaker: pkt.speaker || "CO-DRIVER" });
      if (pkt.forceTts || !pkt.nativeVoice) speakFallback(pkt.callText, pkt.forceTts === true);
      if (store.state.role === "CODRIVER") {
        store.rb.lastCalledNoteId = String(pkt.noteId || store.rb.lastCalledNoteId || "");
        store.rb.lastSpokenNotice = 'Spoken to Driver: "' + String(pkt.callText) + '"';
        renderRoadbookWindow(true);
      }
    },
    setNotice: function(msg) {
      store.statusNotice = String(msg || "");
      if (store.panelOpen) renderSelectorPanel(true);
    },
    setMenuState: function(inLevelBool, menuOpenBool) {
      store.inLevel = Boolean(inLevelBool);
      store.luaMenuOpen = Boolean(menuOpenBool);
      refreshPauseVisibility();
    },
    openStandalone: function() {
      store.forcedStandalone = true;
      store.panelOpen = true;
      store.statusNotice = "";
      renderRoadbookWindow(false);
      callLua("extensions.nativeRallyBridge.vueRequestState()");
      renderSelectorPanel(true);
    },
    closeAll: function() {
      store.panelOpen = false;
      store.forcedStandalone = false;
      store.statusNotice = "";
      renderSelectorPanel(false);
      renderInviteToast();
      renderRoadbookWindow(false);
    }
  };

  callLua("if extensions.nativeRallyBridge and extensions.nativeRallyBridge.onCefMountedAck then extensions.nativeRallyBridge.onCefMountedAck() end");
  callLua("extensions.nativeRallyBridge.vueRequestState()");
})();
]===]

local STATE = {
  hookedMissionManager = false,
  hookedMpVehicleGe = false,
  wrappedTrafficDelete = false,
  cefMountedAck = false,
  catalogScanned = false,
  wasMpSocketConnected = false,
  boundAddEventHandlerFn = nil,
  savedSpawnQueueSetting = nil,
  lastReportedGameVehId = nil,
  lastReportedServerVehId = "",
  forcedMpSendForVehId = nil,
  switchingMapFromServer = false,
  switchingTargetLevel = "",
  switchStartedAtMs = 0,
  switchingMapReleaseTimer = 0,
  worldReadyState = 0,
  launchingFromServer = false,
  launchingFromServerTimer = 0,
  spawnGhostGraceTimer = 0,
  allowLocalClockSkip = false,
  appliedSlotOffset = false,
  appliedBayOffset = false,
  appliedStageGridOffset = false,
  luaMenuOpen = false,
  lastSentInLvl = nil,
  lastSentMenuOpen = nil,
  pendingReadyMinDelay = nil,
  pendingReadyMaxWait = 0,
  waitingForSavedCarSpawn = false,
  inPartnerCar = false,
  partnerCarDriverPlayerId = nil,
  autoCrewCheckTimer = 0,
  queuedLaunchAfterSwitch = nil,
  pendingMapSwitchJob = nil,
  pendingMissionStartJob = nil,
  recentPackets = {},
  outboundQueue = {},
  rttMs = 0,
  probeTimer = 0,
  uiKeepAliveTimer = 0,
  routerPollTimer = 0,
  shieldTimer = 0,
  queueFlushCooldown = 0,
  pendingExplicitQueueFlushes = 0,
  collisionEnforceTimer = 0,
  vehicleSyncTimer = 0,
  lastTickClock = 0,
  slot = 1,
  role = "DRIVER",
  participationMode = "two_car",
  launchMode = "wrc_staggered",
  vehicleMode = (CFG.defaultVehicleChoice == "stage_preset_car") and "stage_preset_car" or "own_mp_car",
  savedPlayerVehicle = nil,
  countdownDisplay = "3d",
  slotOffsetSec = 0,
  activeMissionId = nil,
  activeMissionDir = nil,
  sawForegroundMission = false,
  stageEndReported = false,
  stagedMissionId = nil,
  stagedMissionDir = nil,
  freeroamSpawnMode = "random_rally",
  stagedStartPos = nil,
  pendingStartLinePlacement = nil,
  placedCoursePrefabs = {},
  driverServerVehId = "",
  aiVoiceMutedKeepOff = false,
  passengerCamLocked = false,
  passengerTrackedVehId = nil,
  allowingInternalPassengerCamSet = false,
  hookedCameraGuard = false,
  stageStartOriginPos = nil,
  liveOdometerM = 0,
  odometerPushTimer = 0,
  currentTrackKey = "",
  roadbookNotes = {},
  roadbookCustomSaved = false,
  sentStagedAtSS = false,
  simultaneousReleaseClientMs = nil,
  allMaps = {},
  globalMissions = {},
  peerState = { status = "FREEROAM", yourPlayerId = -1, currentLevel = "", peers = {}, hasPendingProposal = false, pendingProposal = false, hasStagedMission = false, stagedMission = false },
  peerStandings = {},
  lastSplitBroadcast = nil
}


-- ============================================================================
-- FORWARD DECLARATIONS (Prevents runtime global nil resolution across callers)
-- ============================================================================
local clearPlacedCoursePrefabs
local spawnSingleCoursePrefab
local placeRallyCourseInFreeroam
local spawnRallyVehicleAt
local spawnOnFootAt
local processStartLinePlacement
local computeStagingTransform
local teleportVehicleSafely
local RALLY_PRESET_CONFIGS

local function clientNowMs()
  return os.clock() * 1000.0
end

local function isMpSocketReady()
  if not TriggerServerEvent then return false end
  if MPGameNetwork and type(MPGameNetwork.launcherConnected) == "function" then
    local ok, conn = pcall(MPGameNetwork.launcherConnected)
    if ok then return conn == true end
  end
  return true
end

-- Sends colon-free BeamMP events immediately if MPGameNetwork TCP socket is ready, or queues until connected
local function sendServerEvent(eventName, payloadOrStr)
  local dataStr = "{}"
  if type(payloadOrStr) == "string" then
    dataStr = payloadOrStr
  elseif type(payloadOrStr) == "table" and jsonEncode then
    local ok, enc = pcall(jsonEncode, payloadOrStr)
    if ok and enc then dataStr = enc end
  end

  if isMpSocketReady() then
    pcall(TriggerServerEvent, eventName, dataStr)
  else
    if #STATE.outboundQueue < 20 then
      STATE.outboundQueue[#STATE.outboundQueue + 1] = { name = eventName, data = dataStr }
    end
    log("I", "nativeRallyBridge", "Queued outbound event '" .. tostring(eventName) .. "' while MPGameNetwork finishes connecting.")
  end
end

local function flushOutboundServerQueue()
  if #STATE.outboundQueue == 0 or not isMpSocketReady() then return end
  local q = STATE.outboundQueue
  STATE.outboundQueue = {}
  for _, item in ipairs(q) do
    pcall(TriggerServerEvent, item.name, item.data)
  end
end

-- Executes JavaScript inside CEF MainGEUI via BeamEngine's real C++ method be:executeJS(...)
local function execMainUiJs(jsCode)
  if not jsCode or jsCode == "" then return end
  if be and be.executeJS then
    pcall(function() be:executeJS(jsCode) end)
  elseif Engine and Engine.UI and Engine.UI.executeJS then
    pcall(function() Engine.UI.executeJS(jsCode) end)
  end
end

local function isLoadedInLevel()
  if getMissionFilename then
    local mf = getMissionFilename()
    if mf and mf ~= "" then return true end
  end
  if getCurrentLevelIdentifier then
    local id = getCurrentLevelIdentifier()
    if id and id ~= "" then return true end
  end
  return false
end

local function isUiLoadingScreenActive()
  if core_gamestate and type(core_gamestate.loading) == "function" then
    local ok, active = pcall(core_gamestate.loading)
    if ok and active == true then return true end
  end
  return false
end

-- Detects BeamNG v0.40+ ui_router 'pause' / 'pause.*' vs 'play' states
local function detectLuaRouterPause(inLvl)
  local rName = ""
  if ui_router then
    if type(ui_router.getCurrentRouteName) == "function" then
      local ok, v = pcall(ui_router.getCurrentRouteName)
      if ok and v then rName = tostring(v):lower() end
    elseif type(ui_router.getCurrentRoute) == "function" then
      local ok, v = pcall(ui_router.getCurrentRoute)
      if ok and type(v) == "table" then rName = tostring(v.name or v.path or ""):lower()
      elseif ok and type(v) == "string" then rName = v:lower() end
    elseif type(ui_router.currentRoute) == "table" then
      rName = tostring(ui_router.currentRoute.name or ui_router.currentRoute.path or ""):lower()
    elseif type(ui_router.currentRoute) == "string" then
      rName = ui_router.currentRoute:lower()
    end
  end
  if rName == "" and ui_router_routeManager and type(ui_router_routeManager.getCurrentRoute) == "function" then
    local ok, v = pcall(ui_router_routeManager.getCurrentRoute)
    if ok and type(v) == "table" then rName = tostring(v.name or v.path or ""):lower()
    elseif ok and type(v) == "string" then rName = v:lower() end
  end

  if rName ~= "" then
    if rName == "play" or rName:find("^play%.") or rName == "/play" then
      return false
    end
    if rName == "pause" or rName:find("^pause") or rName:find("^/pause") then
      return true
    end
    if inLvl and rName:find("^menu") and not rName:find("beammp") then
      return true
    end
  end

  if core_gamestate and core_gamestate.state and core_gamestate.state.state then
    local stName = tostring(core_gamestate.state.state):lower()
    if stName:find("pause") or (inLvl and stName:find("^menu")) then
      return true
    end
  end

  return STATE.luaMenuOpen
end

local function injectLiveCefPauseMenuUi()
  execMainUiJs(CEF_PAUSE_UI_JS)
end

local function pushMenuVisibilityToCef(forceSend)
  local inLvl = isLoadedInLevel()
  local openBool = detectLuaRouterPause(inLvl)
  if forceSend or (inLvl ~= STATE.lastSentInLvl) or (openBool ~= STATE.lastSentMenuOpen) then
    STATE.lastSentInLvl = inLvl
    STATE.lastSentMenuOpen = openBool
    execMainUiJs("try{if(window.__NativeRallyMP)window.__NativeRallyMP.setMenuState(" .. (inLvl and "true" or "false") .. "," .. (openBool and "true" or "false") .. ");}catch(e){}")
  end
end

local function getCurrentLevelName()
  if getCurrentLevelIdentifier then
    local cid = getCurrentLevelIdentifier()
    if cid and cid ~= "" then return tostring(cid):lower() end
  end
  if core_levels and getMissionFilename then
    local mf = getMissionFilename()
    if mf and mf ~= "" then
      local ln = core_levels.getLevelName(mf)
      if ln and ln ~= "" then return tostring(ln):lower() end
    end
  end
  return ""
end

-- Returns true ONLY if gameVehId belongs to a REMOTE BeamMP player (never false-positives on newly spawned local Stage Preset Cars)
local function isRemoteMpVehicle(gameVehId)
  if not gameVehId or not MPVehicleGE then return false end
  if type(MPVehicleGE.getVehicles) == "function" then
    local ok, vehs = pcall(MPVehicleGE.getVehicles)
    if ok and type(vehs) == "table" then
      for _, mpv in pairs(vehs) do
        if type(mpv) == "table" and tonumber(mpv.gameVehicleID) == tonumber(gameVehId) then
          if mpv.isLocal == false then return true end
          if MPVehicleGE.isOwn and not MPVehicleGE.isOwn(gameVehId) then return true end
        end
      end
    end
  end
  return false
end

-- Detects parked stage prefab vehicles (e.g., NGRC Utah simple_traffic safety ambulances 3,617 ft away), walking unicycles, and AI traffic
local function isAuxiliaryOrPropVehicle(vehId)
  if not CFG.strictSingleVehicleSync or not vehId then return false end
  local obj = (scenetree and scenetree.findObjectById and scenetree.findObjectById(vehId)) or (be and be:getObjectByID(vehId))
  if not obj then return false end

  local jbeam = ""
  if obj.getJBeamFilename then
    local okJ, jb = pcall(function() return obj:getJBeamFilename() end)
    if okJ and jb then jbeam = tostring(jb):lower() end
  end
  if jbeam == "" and obj.JBeam then jbeam = tostring(obj.JBeam):lower() end
  if jbeam == "" and obj.jbeam then jbeam = tostring(obj.jbeam):lower() end

  local partCfg = tostring(obj.partConfig or ""):lower()
  if partCfg == "" and core_vehicle_manager and type(core_vehicle_manager.getVehicleData) == "function" then
    local okD, vdata = pcall(core_vehicle_manager.getVehicleData, vehId)
    if okD and type(vdata) == "table" and type(vdata.config) == "table" then
      partCfg = tostring(vdata.config.partConfigFilename or ""):lower()
    end
  end

  if jbeam == "unicycle" then
    return false
  end
  if jbeam == "simple_traffic" or jbeam:find("^simple_") then
    return true
  end
  if partCfg:find("_parked", 1, true) or partCfg:find("simple_traffic", 1, true) then
    return true
  end

  local activePlayerVid = be and be:getPlayerVehicleID(0) or -1
  if tonumber(vehId) ~= tonumber(activePlayerVid) then
    if gameplay_traffic and type(gameplay_traffic.getTrafficData) == "function" then
      local okT, tData = pcall(gameplay_traffic.getTrafficData)
      if okT and type(tData) == "table" and tData[vehId] ~= nil then
        return true
      end
    end
    if gameplay_parking and type(gameplay_parking.getParkedCarsList) == "function" then
      local okP, pData = pcall(gameplay_parking.getParkedCarsList)
      if okP and type(pData) == "table" and pData[vehId] ~= nil then
        return true
      end
    end
  end

  return false
end

local function isUnicycleVeh(veh)
  if not veh then return false end
  local jb = ""
  if veh.getJBeamFilename then
    local ok, v = pcall(function() return veh:getJBeamFilename() end)
    if ok and v then jb = tostring(v):lower() end
  end
  return jb == "unicycle"
end

local function getOwnVehicle()
  local veh = be and be:getPlayerVehicle(0) or nil
  if not veh then return nil end
  local vid = veh:getID()
  if isRemoteMpVehicle(vid) then
    return nil
  end
  if isAuxiliaryOrPropVehicle(vid) then
    return nil
  end
  return veh
end

local function saveOwnPlayerVehicleConfig()
  local veh = getOwnVehicle()
  if not veh then return end
  local model = veh.getJBeamFilename and veh:getJBeamFilename() or nil
  local partCfg = nil
  if core_vehicles and core_vehicles.getCurrentVehicleDetails then
    local ok, details = pcall(core_vehicles.getCurrentVehicleDetails)
    if ok and details and details.current then
      model = details.current.key or model
      partCfg = details.current.config_key
    end
  end
  if model and model ~= "" then
    STATE.savedPlayerVehicle = { model = model, config = partCfg }
  end
end

local function ensureSavedPlayerVehicleRestored()
  if getOwnVehicle() ~= nil then return end
  if not STATE.savedPlayerVehicle or not core_vehicles or not core_vehicles.spawnNewVehicle then return end
  pcall(function()
    core_vehicles.spawnNewVehicle(STATE.savedPlayerVehicle.model, {
      config = STATE.savedPlayerVehicle.config,
      autoEnterVehicle = true
    })
  end)
end

local function setVehFreeze(veh, freezeBool)
  if not veh then return end
  if core_vehicleBridge and core_vehicleBridge.executeAction then
    core_vehicleBridge.executeAction(veh, "setFreeze", freezeBool)
  end
  veh:queueLuaCommand("controller.setFreeze(" .. (freezeBool and "1" or "0") .. ")")
end

local function normalizePeerState(ps)
  if type(ps) ~= "table" then
    ps = { status = "FREEROAM", yourPlayerId = -1, currentLevel = "", peers = {}, hasPendingProposal = false, pendingProposal = false, hasStagedMission = false, stagedMission = false }
  end
  if ps.hasPendingProposal == false or type(ps.pendingProposal) ~= "table" or not ps.pendingProposal.id then
    ps.hasPendingProposal = false
    ps.pendingProposal = false
  else
    ps.hasPendingProposal = true
  end
  if ps.hasStagedMission == false or type(ps.stagedMission) ~= "table" or not ps.stagedMission.missionId then
    ps.hasStagedMission = false
    ps.stagedMission = false
  else
    ps.hasStagedMission = true
  end
  return ps
end

-- Pushes state to Vue 3 SFCs (guihooks) AND live CEF MainGEUI Pause Menu tab (be:executeJS)
local function emitVueBridgeState()
  STATE.peerState = normalizePeerState(STATE.peerState)
  local payload = {
    peerState = STATE.peerState,
    role = STATE.role,
    slot = STATE.slot,
    activeMissionId = STATE.activeMissionId or "",
    stagedMissionId = STATE.stagedMissionId or "",
    currentTrackKey = STATE.currentTrackKey or "",
    aiVoiceMutedKeepOff = STATE.aiVoiceMutedKeepOff,
    codriverClickToCallVoice = CFG.codriverClickToCallVoice,
    codriverHideDriverNotes = CFG.codriverHideDriverNotes,
    codriverWritableTrackNotes = CFG.codriverWritableTrackNotes,
    roadbookCustomSaved = STATE.roadbookCustomSaved,
    roadbookNotes = STATE.roadbookNotes,
    lastSplit = STATE.lastSplitBroadcast,
    peerStandings = STATE.peerStandings,
    maps = STATE.allMaps,
    missions = STATE.globalMissions,
    vehicleMode = STATE.vehicleMode,
    freeroamSpawnMode = STATE.freeroamSpawnMode or "random_rally",
    hasStagedStartPos = (STATE.stagedStartPos ~= nil),
    defaultVehicleChoice = CFG.defaultVehicleChoice,
    requirePartnerReadyCheck = CFG.requirePartnerReadyCheck,
    countdownDisplay = STATE.countdownDisplay,
    unlockNativeRallyFeatures = CFG.unlockNativeRallyFeatures,
    enableLiveSplitDeltaOverlay = CFG.enableLiveSplitDeltaOverlay,
    rttMs = math.floor(STATE.rttMs + 0.5)
  }

  if guihooks then
    guihooks.trigger("NativeRallyVueState", payload)
    if guihooks.triggerStream then
      guihooks.triggerStream("nativeRallyPeer", payload)
    end
  end

  if jsonEncode then
    local ok, encoded = pcall(jsonEncode, payload)
    if ok and encoded then
      execMainUiJs("try{if(window.__NativeRallyMP)window.__NativeRallyMP.updateState(" .. encoded .. ");}catch(e){}")
    end
  end
  pushMenuVisibilityToCef(true)
end

-- Sub-millisecond fallback seed so cards are ready immediately without blocking mod activation
local function seedFallbackCatalog()
  if #STATE.globalMissions > 0 then return end
  local seeded = {}
  for _, fb in ipairs(OFFICIAL_RALLY_FALLBACKS) do
    local typeAllowed = (fb.missionType == "rallyLoop" and CFG.allowRallyLoop) or (fb.missionType == "rallyStage" and CFG.allowRallyStage)
    if typeAllowed then
      seeded[#seeded + 1] = {
        id = fb.id,
        missionDir = "/gameplay/missions/" .. fb.id,
        name = fb.name,
        missionType = fb.missionType,
        levelName = fb.levelName,
        previewFile = fb.previewFile
      }
    end
  end
  STATE.globalMissions = seeded
end

local function isSupportedNativeMission(mission)
  if type(mission) ~= "table" then return false end
  local mt = tostring(mission.missionType or "")
  if mt == "rallyLoop" and CFG.allowRallyLoop then return true end
  if mt == "rallyStage" and CFG.allowRallyStage then return true end
  return false
end

local function humanMissionName(rawName, fallbackId)
  local raw = tostring(rawName or fallbackId or "")
  if translateLanguage then
    local ok, tr = pcall(translateLanguage, raw, raw, true)
    if ok and tr and tr ~= "" then return tostring(tr) end
  end
  return raw
end

-- Resolves live BeamNG v0.40 mission instance by exact ID, getFilesData(), or fuzzy title/token match
local function resolveNativeMissionObject(missionId, missionName, missionType, levelName)
  if not gameplay_missions_missions then return nil end

  if gameplay_missions_missions.getMissionById and missionId then
    local okExact, exact = pcall(gameplay_missions_missions.getMissionById, missionId)
    if okExact and exact then return exact end
  end

  local wantName = tostring(missionName or ""):lower()
  local wantType = tostring(missionType or "")
  local wantLvl = tostring(levelName or ""):lower()

  local token = nil
  for _, fb in ipairs(OFFICIAL_RALLY_FALLBACKS) do
    if fb.id == missionId or fb.name:lower() == wantName then
      token = fb.token
      break
    end
  end

  local function searchMissionList(listTbl, instantiateViaGetById)
    if type(listTbl) ~= "table" then return nil end
    local levelFallback = nil
    for _, m in pairs(listTbl) do
      if isSupportedNativeMission(m) then
        local mId = tostring(m.id or "")
        local mIdLower = mId:lower()
        local disp = humanMissionName(m.name, mId):lower()
        if disp == wantName or (token and (mIdLower:find(token, 1, true) or disp:find(token, 1, true))) then
          if instantiateViaGetById and gameplay_missions_missions.getMissionById then
            local okI, inst = pcall(gameplay_missions_missions.getMissionById, mId)
            if okI and inst then return inst end
          end
          return m
        end
        if wantLvl ~= "" and mIdLower:find(wantLvl, 1, true) and (wantType == "" or tostring(m.missionType) == wantType) then
          levelFallback = levelFallback or m
        end
      end
    end
    if levelFallback then
      if instantiateViaGetById and gameplay_missions_missions.getMissionById and levelFallback.id then
        local okF, instF = pcall(gameplay_missions_missions.getMissionById, levelFallback.id)
        if okF and instF then return instF end
      end
      return levelFallback
    end
    return nil
  end

  if type(gameplay_missions_missions.get) == "function" then
    local ok, allM = pcall(gameplay_missions_missions.get)
    if ok then
      local hit = searchMissionList(allM, false)
      if hit then return hit end
    end
  end

  if type(gameplay_missions_missions.getFilesData) == "function" then
    local okF, filesM = pcall(gameplay_missions_missions.getFilesData)
    if okF then
      local hitF = searchMissionList(filesM, true)
      if hitF then return hitF end
    end
  end

  return nil
end

-- Preserves active MPCoreNetwork + MPGameNetwork TCP session across coordinated cross-map loads
local function installMpCrossMapSessionGuard()
  if not CFG.enableDynamicCrossMapSync then return end

  if MPCoreNetwork and type(MPCoreNetwork.onClientEndMission) == "function" and not MPCoreNetwork._nrmpGuarded then
    local origCoreEnd = MPCoreNetwork.onClientEndMission
    MPCoreNetwork._nrmpOrigOnClientEndMission = origCoreEnd
    MPCoreNetwork.onClientEndMission = function(...)
      if STATE.switchingMapFromServer or STATE.switchingMapReleaseTimer > 0 or STATE.launchingFromServer or STATE.launchingFromServerTimer > 0 then
        log("I", "nativeRallyBridge", "Preserving MPCoreNetwork session across coordinated map switch.")
        return
      end
      return origCoreEnd(...)
    end
    MPCoreNetwork._nrmpGuarded = true
    if extensions and type(extensions.hookUpdate) == "function" then
      pcall(extensions.hookUpdate, "onClientEndMission")
    end
  end

  if MPCoreNetwork and type(MPCoreNetwork.leaveServer) == "function" and not MPCoreNetwork._nrmpLeaveGuarded then
    local origLeaveServer = MPCoreNetwork.leaveServer
    MPCoreNetwork.leaveServer = function(...)
      if STATE.switchingMapFromServer or STATE.switchingMapReleaseTimer > 0 or STATE.launchingFromServer or STATE.launchingFromServerTimer > 0 then
        log("I", "nativeRallyBridge", "Prevented MPCoreNetwork.leaveServer during coordinated map travel.")
        return
      end
      return origLeaveServer(...)
    end
    MPCoreNetwork._nrmpLeaveGuarded = true
  end
end

local function buildMultiplayerUserSettings(mission, baseSettings, opts)
  opts = opts or {}
  local safe = {}
  if type(baseSettings) == "table" then
    for k, v in pairs(baseSettings) do safe[k] = v end
  end

  if mission and type(mission.getUserSettingsData) == "function" then
    local ok, schema = pcall(function() return mission:getUserSettingsData() end)
    if ok and type(schema) == "table" then
      for _, entry in ipairs(schema) do
        if entry.key and safe[entry.key] == nil and entry.value ~= nil then
          safe[entry.key] = entry.value
        end
      end
    end
  end

  local usePreset = (opts.vehicleMode == "stage_preset_car")
  if not usePreset then
    ensureSavedPlayerVehicleRestored()
    if getOwnVehicle() == nil then
      log("I", "nativeRallyBridge", "No personal MP vehicle spawned yet — falling back to official Stage Preset Car so Rally starts cleanly.")
      usePreset = true
    end
  end

  if usePreset then
    safe.usePlayerVehicle = false
    safe.prioritizePlayerVehicle = false
    if mission and mission.setupModules and mission.setupModules.vehicles then
      mission.setupModules.vehicles.prioritizePlayerVehicle = false
    end
  else
    safe.usePlayerVehicle = true
    safe.prioritizePlayerVehicle = true
    if mission and mission.setupModules and mission.setupModules.vehicles then
      mission.setupModules.vehicles.includePlayerVehicle = true
      mission.setupModules.vehicles.prioritizePlayerVehicle = true
    end
  end

  if CFG.disableLiaisonAiTraffic then
    safe.rallyEnableTraffic = false
  end
  if opts.enableFalseStarts ~= nil then
    safe.rallyEnableFalseStarts = opts.enableFalseStarts
  end
  if opts.repairOnRecovery ~= nil then
    safe.rallyRepairVehicleOnRecovery = opts.repairOnRecovery
  end

  if STATE.participationMode == "codriver" then
    if CFG.codriverMuteAiVoicepack or STATE.aiVoiceMutedKeepOff then
      safe.rallyAudioPacenotes = false
      safe.codriverAudio = false
    end
    if STATE.role == "DRIVER" and CFG.codriverHideDriverNotes then
      safe.rallyVisualPacenotes = false
      safe.visualPacenotes = false
    end
  elseif STATE.aiVoiceMutedKeepOff then
    safe.rallyAudioPacenotes = false
  end

  return safe
end

local function restoreAllRemoteMpVehicles()
  if not CFG.protectMpVehiclesFromClean then return end
  if not MPVehicleGE or not MPVehicleGE.getVehicles then return end

  for _, mpVeh in pairs(MPVehicleGE.getVehicles() or {}) do
    local gvid = mpVeh.gameVehicleID
    if gvid and (mpVeh.isLocal == false or (MPVehicleGE.isOwn and not MPVehicleGE.isOwn(gvid))) then
      local obj = scenetree.findObjectById(gvid) or be:getObjectByID(gvid)
      if obj and obj.getActive and obj:getActive() == false then
        obj:setActive(1)
      end
    end
  end
end

-- Blocks parked stage prefab vehicles (simple_traffic ambulances) from MPVehicleGE while leaving remote partner spawns untouched
local function installMpVehicleGeHooks()
  if not CFG.strictSingleVehicleSync or not MPVehicleGE then return end

  if type(MPVehicleGE.sendVehicle) == "function" and not MPVehicleGE._nrmpSendWrapped then
    local origSendVehicle = MPVehicleGE.sendVehicle
    MPVehicleGE.sendVehicle = function(gameVehicleID, ...)
      if CFG.strictSingleVehicleSync and isAuxiliaryOrPropVehicle(gameVehicleID) then
        log("I", "nativeRallyBridge", "Kept stage prop local-only (blocked MPVehicleGE.sendVehicle for vehId=" .. tostring(gameVehicleID) .. ")")
        return
      end
      return origSendVehicle(gameVehicleID, ...)
    end
    MPVehicleGE._nrmpSendWrapped = true
  end

  if type(MPVehicleGE.sendVehicleEdit) == "function" and not MPVehicleGE._nrmpEditWrapped then
    local origSendEdit = MPVehicleGE.sendVehicleEdit
    MPVehicleGE.sendVehicleEdit = function(gameVehicleID, ...)
      if CFG.strictSingleVehicleSync and isAuxiliaryOrPropVehicle(gameVehicleID) then
        return
      end
      return origSendEdit(gameVehicleID, ...)
    end
    MPVehicleGE._nrmpEditWrapped = true
  end

  if type(MPVehicleGE.onVehicleSwitched) == "function" and not MPVehicleGE._nrmpSwitchWrapped then
    local origOnSwitched = MPVehicleGE.onVehicleSwitched
    MPVehicleGE.onVehicleSwitched = function(oldId, newId, ...)
      if CFG.strictSingleVehicleSync and newId and not isRemoteMpVehicle(newId) and isAuxiliaryOrPropVehicle(newId) then
        return
      end
      return origOnSwitched(oldId, newId, ...)
    end
    MPVehicleGE._nrmpSwitchWrapped = true
  end

  if type(MPVehicleGE.onVehicleSpawned) == "function" and not MPVehicleGE._nrmpSpawnWrapped then
    local origOnSpawned = MPVehicleGE.onVehicleSpawned
    MPVehicleGE.onVehicleSpawned = function(gameVehicleID, ...)
      -- Never block remote partner vehicles being spawned by MPVehicleGE; only block local stage props/avatars
      if CFG.strictSingleVehicleSync and not isRemoteMpVehicle(gameVehicleID) and isAuxiliaryOrPropVehicle(gameVehicleID) then
        log("I", "nativeRallyBridge", "Kept prefab prop local-only (skipped MPVehicleGE.onVehicleSpawned for vehId=" .. tostring(gameVehicleID) .. ")")
        return
      end
      return origOnSpawned(gameVehicleID, ...)
    end
    MPVehicleGE._nrmpSpawnWrapped = true
    STATE.hookedMpVehicleGe = true
    if extensions and type(extensions.hookUpdate) == "function" then
      pcall(extensions.hookUpdate, "onVehicleSpawned")
    end
  end
end

local function findMpVehicleEntryByServerString(srvId)
  if not srvId or srvId == "" or not MPVehicleGE then return nil end
  if type(MPVehicleGE.getVehicleByServerID) == "function" then
    local okV, resV = pcall(MPVehicleGE.getVehicleByServerID, srvId)
    if okV and type(resV) == "table" then return resV end
  end
  if type(MPVehicleGE.getVehicles) == "function" then
    local okAll, vehs = pcall(MPVehicleGE.getVehicles)
    if okAll and type(vehs) == "table" then
      for sidKey, mpv in pairs(vehs) do
        if type(mpv) == "table" then
          local svs = tostring(mpv.serverVehicleString or "")
          local composed = (mpv.ownerID ~= nil and mpv.serverVehicleID ~= nil) and (tostring(mpv.ownerID) .. "-" .. tostring(mpv.serverVehicleID)) or ""
          if svs == srvId or composed == srvId or tostring(sidKey) == srvId then
            return mpv
          end
        end
      end
    end
  end
  return nil
end

local function resolveServerVehicleString(gameVehId)
  if not gameVehId or not MPVehicleGE or type(MPVehicleGE.getVehicles) ~= "function" then return "" end
  local okAll, vehs = pcall(MPVehicleGE.getVehicles)
  if not okAll or type(vehs) ~= "table" then return "" end
  for sidKey, mpv in pairs(vehs) do
    if type(mpv) == "table" and tonumber(mpv.gameVehicleID) == tonumber(gameVehId) then
      local svs = tostring(mpv.serverVehicleString or "")
      if svs ~= "" and svs:find("%-") then return svs end
      if mpv.ownerID ~= nil and mpv.serverVehicleID ~= nil then
        return tostring(mpv.ownerID) .. "-" .. tostring(mpv.serverVehicleID)
      end
      local keyStr = tostring(sidKey or "")
      if keyStr:find("%-") then return keyStr end
    end
  end
  return ""
end

-- Checks whether any connected partner car is still queued as an orange BeamMP sphere instead of a live 3D BeamNGVehicle
local function hasUnspawnedPartnerVehicle()
  if not MPVehicleGE then return false end

  local peers = STATE.peerState and STATE.peerState.peers or nil
  if type(peers) == "table" then
    for _, p in ipairs(peers) do
      local srvId = tostring(p.serverVehId or "")
      if srvId ~= "" and tonumber(p.slot) ~= tonumber(STATE.slot) then
        local mpv = findMpVehicleEntryByServerString(srvId)
        if not mpv then
          return true
        end
        local gvid = tonumber(mpv.gameVehicleID)
        if not gvid or gvid < 0 then
          return true
        end
        local liveObj = (scenetree and scenetree.findObjectById and scenetree.findObjectById(gvid)) or (be and be:getObjectByID(gvid))
        if not liveObj then
          return true
        end
      end
    end
  end

  if type(MPVehicleGE.getVehicles) == "function" then
    local okAll, vehs = pcall(MPVehicleGE.getVehicles)
    if okAll and type(vehs) == "table" then
      for _, mpv in pairs(vehs) do
        if type(mpv) == "table" and mpv.isLocal == false then
          local gvid = tonumber(mpv.gameVehicleID)
          if not gvid or gvid < 0 then
            return true
          end
          local liveObj = (scenetree and scenetree.findObjectById and scenetree.findObjectById(gvid)) or (be and be:getObjectByID(gvid))
          if not liveObj then
            return true
          end
        end
      end
    end
  end

  return false
end

-- Bypasses BeamMP's foreground-mission spawn queue so partner rally cars materialize immediately as 3D models (zero orange blobs)
local function flushMpSpawnQueueNow(forceFlush)
  if not CFG.immediatePartnerSpawnFlush then return end
  if isUiLoadingScreenActive and isUiLoadingScreenActive() then return end

  if settings and settings.setValue then
    if STATE.savedSpawnQueueSetting == nil and settings.getValue then
      local okS, curVal = pcall(settings.getValue, "enableSpawnQueue")
      if okS then STATE.savedSpawnQueueSetting = curVal end
    end
    if settings.getValue then
      local okG, enabled = pcall(settings.getValue, "enableSpawnQueue")
      if okG and enabled == true then
        pcall(settings.setValue, "enableSpawnQueue", false)
      end
    else
      pcall(settings.setValue, "enableSpawnQueue", false)
    end
  end

  if not forceFlush and not hasUnspawnedPartnerVehicle() then
    return
  end

  if MPVehicleGE then
    if type(MPVehicleGE.applyQueuedEvents) == "function" then
      pcall(MPVehicleGE.applyQueuedEvents)
    end
    if type(MPVehicleGE.applyQueue) == "function" then
      pcall(MPVehicleGE.applyQueue)
    end
  end
  if extensions and extensions.MPVehicleGE and extensions.MPVehicleGE ~= MPVehicleGE then
    if type(extensions.MPVehicleGE.applyQueuedEvents) == "function" then
      pcall(extensions.MPVehicleGE.applyQueuedEvents)
    end
  end
end

-- Enforces car-to-car physical collision policy ('always_solid' keeps full contact everywhere & clears vehicleGhost states)
local function enforceCollisionPolicy(isLaunchMoment)
  if not be or not be.setDynamicCollisionEnabled then return end

  if CFG.collisionPolicy == "always_solid" then
    STATE.spawnGhostGraceTimer = 0
    pcall(function() be:setDynamicCollisionEnabled(true) end)

    local ownVeh = getOwnVehicle()
    if ownVeh and ownVeh.queueLuaCommand then
      pcall(function() ownVeh:queueLuaCommand("if obj and obj.setGhostEnabled then obj:setGhostEnabled(false) end") end)
    end

    if MPVehicleGE and type(MPVehicleGE.getVehicles) == "function" then
      local okV, vehs = pcall(MPVehicleGE.getVehicles)
      if okV and type(vehs) == "table" then
        for _, mpv in pairs(vehs) do
          local gvid = type(mpv) == "table" and tonumber(mpv.gameVehicleID) or nil
          if gvid and gvid >= 0 then
            local vObj = (scenetree and scenetree.findObjectById and scenetree.findObjectById(gvid)) or be:getObjectByID(gvid)
            if vObj and vObj.queueLuaCommand then
              pcall(function() vObj:queueLuaCommand("if obj and obj.setGhostEnabled then obj:setGhostEnabled(false) end") end)
            end
          end
        end
      end
    end
  elseif CFG.collisionPolicy == "ghost_launch_only" then
    if isLaunchMoment and STATE.participationMode == "two_car" then
      STATE.spawnGhostGraceTimer = 8.0
      pcall(function() be:setDynamicCollisionEnabled(false) end)
    elseif STATE.spawnGhostGraceTimer <= 0 then
      pcall(function() be:setDynamicCollisionEnabled(true) end)
    end
  else
    pcall(function() be:setDynamicCollisionEnabled(false) end)
  end
end

-- Tracks the single active rally car for this driver, hides leftover pre-mission local cars, and notifies server to prune old slots
local function reconcileSingleActivePlayerVehicle()
  if not CFG.strictSingleVehicleSync or STATE.role == "CODRIVER" then return end
  if STATE.inPartnerCar then return end
  local rawPlayerVeh = be and be:getPlayerVehicle(0) or nil
  if isUnicycleVeh(rawPlayerVeh) then return end -- on foot: do NOT report/prune/hide the real car
  local ownVeh = getOwnVehicle()
  if not ownVeh then return end
  local activeId = ownVeh:getID()
  if not activeId or activeId < 0 then return end

  -- Ensure active rally car is registered with MPVehicleGE if a mission spawned it
  if MPVehicleGE then
    local isTrackedOwn = (type(MPVehicleGE.isOwn) == "function") and MPVehicleGE.isOwn(activeId) or false
    if not isTrackedOwn and STATE.forcedMpSendForVehId ~= activeId and type(MPVehicleGE.sendVehicle) == "function" then
      STATE.forcedMpSendForVehId = activeId
      pcall(MPVehicleGE.sendVehicle, activeId)
    end

    -- During an active Rally mission, hide any leftover pre-mission local player vehicle so it cannot sit on the road
    if STATE.activeMissionId and type(MPVehicleGE.getVehicles) == "function" then
      local okAll, vehs = pcall(MPVehicleGE.getVehicles)
      if okAll and type(vehs) == "table" then
        for _, mpv in pairs(vehs) do
          local gvid = type(mpv) == "table" and tonumber(mpv.gameVehicleID) or nil
          if gvid and gvid ~= activeId and mpv.isLocal == true and not isAuxiliaryOrPropVehicle(gvid) then
            local staleObj = (scenetree and scenetree.findObjectById and scenetree.findObjectById(gvid)) or be:getObjectByID(gvid)
            if staleObj and staleObj.getActive and staleObj:getActive() ~= false then
              pcall(function() staleObj:setActive(0) end)
            end
          end
        end
      end
    end

    -- Resolve serverVehicleString ('<pid>-<vid>') directly from MPVehicleGE.getVehicles() (never call MPVehicleGE.getServerVehicleID, which logs errors before spawn ACK)
    local srvId = resolveServerVehicleString(activeId)
    if srvId ~= "" and srvId:find("%-") and (srvId ~= STATE.lastReportedServerVehId or activeId ~= STATE.lastReportedGameVehId) then
      STATE.lastReportedServerVehId = srvId
      STATE.lastReportedGameVehId = activeId
      sendServerEvent("NativeRally_ActiveVehicle", {
        serverVehId = srvId,
        gameVehicleId = activeId
      })
    end
  end
end

local function installTrafficDeleteShield()
  if not CFG.protectMpVehiclesFromClean or STATE.wrappedTrafficDelete then return end
  if gameplay_traffic and type(gameplay_traffic.deleteVehicles) == "function" then
    local origTrafficDel = gameplay_traffic.deleteVehicles
    gameplay_traffic.deleteVehicles = function(...)
      if MPVehicleGE and MPVehicleGE.getVehicles and gameplay_traffic.removeTraffic then
        for _, mpVeh in pairs(MPVehicleGE.getVehicles() or {}) do
          if mpVeh.gameVehicleID then pcall(gameplay_traffic.removeTraffic, mpVeh.gameVehicleID) end
        end
      end
      local res = origTrafficDel(...)
      restoreAllRemoteMpVehicles()
      return res
    end
    STATE.wrappedTrafficDelete = true
  end
end

local function getVehicleRefRotQuat(veh)
  if veh and veh.getClusterRotationSlow and veh.getRefNodeId then
    local okR, rq = pcall(function() return veh:getClusterRotationSlow(veh:getRefNodeId()) end)
    if okR and rq then return quat(rq) end
  end
  if quatFromDir and veh and veh.getDirectionVector and veh.getDirectionVectorUp then
    local okD, qd = pcall(function() return quatFromDir(-veh:getDirectionVector(), veh:getDirectionVectorUp()) end)
    if okD and qd then return qd end
  end
  return quat(0, 0, 0, 1)
end

-- Frame-zero Slot 2 separation for solid full-contact cars (+4.8m lateral bay in Rally Loops; -6.5m staggered grid on standalone Stages)
local function checkAndApplySpawnSeparation()
  if STATE.slot ~= 2 or STATE.participationMode ~= "two_car" then return end
  local veh = getOwnVehicle()
  if not veh then return end

  local lm = gameplay_rallyLoop and gameplay_rallyLoop.getManager and gameplay_rallyLoop.getManager()
  local stallPos = lm and lm.fgVariables and lm.fgVariables.serviceStallPos
  if stallPos then
    if not STATE.appliedBayOffset then
      local baseVec = vec3(stallPos[1] or stallPos.x, stallPos[2] or stallPos.y, stallPos[3] or stallPos.z)
      if veh:getPosition():distance(baseVec) <= 3.4 then
        local sr = lm.fgVariables.serviceStallRot or { 0, 0, 0, 1 }
        local rotQuat = quat(sr[1] or sr.x or 0, sr[2] or sr.y or 0, sr[3] or sr.z or 0, sr[4] or sr.w or 1)
        local lateralRight = rotQuat * vec3(1, 0, 0)
        local shifted = baseVec + lateralRight * CFG.serviceBayLateralOffsetM
        veh:setPositionRotation(shifted.x, shifted.y, shifted.z + 0.2, rotQuat.x, rotQuat.y, rotQuat.z, rotQuat.w)
        if veh.resetBrokenFlexMesh then pcall(function() veh:resetBrokenFlexMesh() end) end
        STATE.appliedBayOffset = true
      end
    end
    return
  end

  -- Standalone rallyStage grid stagger (-6.5m behind Slot 1 along stage road) so solid cars never overlap on spawn
  if STATE.activeMissionId and not STATE.appliedStageGridOffset and STATE.launchingFromServerTimer > 0 then
    local fwd = veh.getDirectionVector and veh:getDirectionVector() or vec3(0, -1, 0)
    local rotQuat = getVehicleRefRotQuat(veh)
    local stagPos = veh:getPosition() - (fwd * 6.5) + vec3(0, 0, 0.22)
    if spawn and type(spawn.safeTeleport) == "function" then
      pcall(spawn.safeTeleport, veh, stagPos, rotQuat)
    else
      veh:setPositionRotation(stagPos.x, stagPos.y, stagPos.z, rotQuat.x, rotQuat.y, rotQuat.z, rotQuat.w)
    end
    if veh.resetBrokenFlexMesh then pcall(function() veh:resetBrokenFlexMesh() end) end
    STATE.appliedStageGridOffset = true
    return
  end

  -- Extra launch overlap guard if Slot 1's vehicle is within 2.8m during mission entry
  if STATE.launchingFromServerTimer > 0 and MPVehicleGE and type(MPVehicleGE.getVehicles) == "function" then
    local okAll, vehs = pcall(MPVehicleGE.getVehicles)
    if okAll and type(vehs) == "table" then
      for _, mpv in pairs(vehs) do
        local gvid = type(mpv) == "table" and tonumber(mpv.gameVehicleID) or nil
        if gvid and mpv.isLocal == false then
          local peerObj = (scenetree and scenetree.findObjectById and scenetree.findObjectById(gvid)) or be:getObjectByID(gvid)
          if peerObj and peerObj.getPosition and veh:getPosition():distance(peerObj:getPosition()) < 2.8 then
            local fwd = veh.getDirectionVector and veh:getDirectionVector() or vec3(0, -1, 0)
            local rotQuat = getVehicleRefRotQuat(veh)
            local safePos = peerObj:getPosition() - (fwd * 6.5) + vec3(0, 0, 0.22)
            if spawn and type(spawn.safeTeleport) == "function" then
              pcall(spawn.safeTeleport, veh, safePos, rotQuat)
            else
              veh:setPositionRotation(safePos.x, safePos.y, safePos.z, rotQuat.x, rotQuat.y, rotQuat.z, rotQuat.w)
            end
            if veh.resetBrokenFlexMesh then pcall(function() veh:resetBrokenFlexMesh() end) end
            break
          end
        end
      end
    end
  end
end

local function checkAndApplyServiceBayOffset()
  checkAndApplySpawnSeparation()
end

local function checkAndApplyWrcSlotScheduleOffset()
  if STATE.appliedSlotOffset or STATE.slotOffsetSec <= 0 then return end
  local lm = gameplay_rallyLoop and gameplay_rallyLoop.getManager and gameplay_rallyLoop.getManager()
  if not lm or not lm.events or #lm.events == 0 then return end

  for _, ev in ipairs(lm.events) do
    if ev.time then ev.time = ev.time + STATE.slotOffsetSec end
  end
  if lm.initTimecardData then lm:initTimecardData() end
  STATE.appliedSlotOffset = true
end

local function hookNativeGameplayRally()
  if not gameplay_rally or gameplay_rally._nrmpHooked then return end

  if CFG.patchGlobalVehicleResetBug and type(gameplay_rally.onVehicleResetted) == "function" then
    local origReset = gameplay_rally.onVehicleResetted
    gameplay_rally.onVehicleResetted = function(vehicleID, ...)
      if vehicleID and isRemoteMpVehicle(vehicleID) then
        return
      end
      return origReset(vehicleID, ...)
    end
  end

  if type(gameplay_rally.onRacePathnodeReached) == "function" then
    local origPathnode = gameplay_rally.onRacePathnodeReached
    gameplay_rally.onRacePathnodeReached = function(event, ...)
      local res = origPathnode(event, ...)
      if event and event.pathnode and STATE.activeMissionId then
        sendServerEvent("NativeRally_PathnodeSplit", {
          pathnodeId = event.pathnode.id,
          name = event.pathnode.name,
          timeSec = event.time
        })
      end
      return res
    end
  end

  gameplay_rally._nrmpHooked = true
end

local function hookNativeGameplayRallyLoop()
  if not gameplay_rallyLoop or gameplay_rallyLoop._nrmpHooked then return end

  if type(gameplay_rallyLoop.onUIStartButtonClicked) == "function" then
    local origStartBtn = gameplay_rallyLoop.onUIStartButtonClicked
    gameplay_rallyLoop.onUIStartButtonClicked = function(...)
      if not STATE.launchingFromServer and STATE.launchingFromServerTimer <= 0 then
        sendServerEvent("NativeRally_UIStartClicked", "{}")
      end
      local res = origStartBtn(...)
      checkAndApplySpawnSeparation()
      checkAndApplyWrcSlotScheduleOffset()
      enforceCollisionPolicy(false)
      flushMpSpawnQueueNow(true)
      return res
    end
  end

  if type(gameplay_rallyLoop.onGameplayInteract) == "function" then
    local origInteract = gameplay_rallyLoop.onGameplayInteract
    gameplay_rallyLoop.onGameplayInteract = function(...)
      local lm = gameplay_rallyLoop.getManager and gameplay_rallyLoop.getManager()
      if lm and lm:canSkip() and CFG.clockSkipPolicy == "consensus_both" and not STATE.allowLocalClockSkip then
        local nextEv = lm.events and lm.events[lm.nextEventIndex]
        local targetEpoch = (nextEv and nextEv.time) and (nextEv.time - 1) or (lm:getEpochTime() + 10)
        sendServerEvent("NativeRally_VoteClockSkip", { targetEpoch = targetEpoch })
        return
      end
      return origInteract(...)
    end
  end

  if type(gameplay_rallyLoop.onRallyDataUpdated) == "function" then
    local origDataUpdated = gameplay_rallyLoop.onRallyDataUpdated
    gameplay_rallyLoop.onRallyDataUpdated = function(data, ...)
      if data and data.vehicleProximity and STATE.launchMode == "simultaneous_ghost" and STATE.role == "DRIVER" then
        local vp = data.vehicleProximity
        if vp.isNear and vp.isStopped and not STATE.sentStagedAtSS then
          STATE.sentStagedAtSS = true
          local veh = getOwnVehicle()
          if veh then setVehFreeze(veh, true) end
          sendServerEvent("NativeRally_PlayerStagedAtSS", "{}")
        end
      end
      return origDataUpdated(data, ...)
    end
  end

  gameplay_rallyLoop._nrmpHooked = true
end

local function sanitizeClientTrackKey(rawKey)
  local s = tostring(rawKey or "default_track"):lower():gsub("[^a-z0-9_%-]", "_")
  if s == "" then s = "default_track" end
  return s:sub(1, 96)
end

local function getClientTrackNotesPath(trackKey)
  return "/settings/RallyMP/pacenotes/" .. sanitizeClientTrackKey(trackKey) .. ".json"
end

-- ============================================================================
-- NATIVE CO-DRIVER VOICE BRIDGE + SUBTITLES (accessibility)
-- Uses BeamNG's own rally audioManager / notebook pacenotes when available,
-- and always mirrors every spoken note to an on-screen caption.
-- ============================================================================
local function emitSubtitle(text, speaker)
  if not CFG.subtitlesForNotes then return end
  text = tostring(text or "")
  if text == "" or not jsonEncode then return end
  local payload = jsonEncode({ text = text, speaker = speaker or "CO-DRIVER" })
  if payload then
    execMainUiJs("try{if(window.__NativeRallyMP&&window.__NativeRallyMP.showSubtitle)window.__NativeRallyMP.showSubtitle(" .. payload .. ");}catch(e){}")
  end
end

-- Flattens any note shape the game uses (plain string, list of parts, or {before, note, after}) into one readable line
local function flattenNoteValue(v, depth)
  depth = depth or 0
  if depth > 4 then return "" end
  if type(v) == "string" then return v end
  if type(v) == "number" then return tostring(v) end
  if type(v) ~= "table" then return "" end
  local parts = {}
  if #v > 0 then
    for _, x in ipairs(v) do
      local t = flattenNoteValue(x, depth + 1)
      if t ~= "" then parts[#parts + 1] = t end
    end
    return table.concat(parts, " ")
  end
  for _, k in ipairs({ "before", "note", "freeform", "text", "after" }) do
    if v[k] ~= nil then
      local t = flattenNoteValue(v[k], depth + 1)
      if t ~= "" then parts[#parts + 1] = t end
    end
  end
  return table.concat(parts, " ")
end

local function extractPacenoteText(pn)
  if type(pn) == "string" then return pn end
  if type(pn) ~= "table" then return "" end
  for _, m in ipairs({ "noteOutputPreview", "noteOutputFreeform", "getNoteFieldFreeform", "joinedNote", "getNoteText", "getNote", "noteText" }) do
    local f = pn[m]
    if type(f) == "function" then
      local ok, v = pcall(f, pn)
      if ok then
        local t = flattenNoteValue(v)
        if t ~= "" then return t end
      end
    elseif type(f) == "string" or type(f) == "table" then
      local t = flattenNoteValue(f)
      if t ~= "" then return t end
    end
  end
  local direct = flattenNoteValue(pn.note)
  if direct ~= "" then return direct end
  if type(pn.notes) == "table" then
    local list = { pn.notes.english, pn.notes.en, pn.notes["en-US"] }
    for _, v in pairs(pn.notes) do list[#list + 1] = v end
    for _, v in ipairs(list) do
      local t = flattenNoteValue(v)
      if t ~= "" then return t end
    end
  end
  if type(pn.name) == "string" then return pn.name end
  return ""
end

local function getNativeAudioManager()
  if not (gameplay_rally and type(gameplay_rally.getRallyManager) == "function") then return nil, nil end
  local ok, rm = pcall(gameplay_rally.getRallyManager)
  if ok and type(rm) == "table" and type(rm.audioManager) == "table" then
    return rm, rm.audioManager
  end
  return nil, nil
end

local function listNativePacenotes(rm)
  local nb = nil
  if type(rm.notebook) == "table" then nb = rm.notebook end
  if not nb and type(rm.getNotebook) == "function" then
    local ok, v = pcall(rm.getNotebook, rm)
    if ok and type(v) == "table" then nb = v end
  end
  if not nb or type(nb.pacenotes) ~= "table" then return {} end
  local pns = nb.pacenotes
  local src = (type(pns.sorted) == "table" and pns.sorted) or (type(pns.objects) == "table" and pns.objects) or pns
  local out = {}
  for _, pn in ipairs(src) do out[#out + 1] = pn end
  return out
end

-- Turns off BeamNG's rally debug overlay (green pacenote markers + black text labels in the 3D world)
-- True while the in-game co-driver is still speaking or has phrases queued
function M.nativeVoiceBusy()
  local _, am = getNativeAudioManager()
  if not am then return false end
  if type(am.isPlaying) == "function" then
    local ok, playing = pcall(am.isPlaying, am)
    if ok and playing then return true end
  end
  if type(am.queue) == "table" and #am.queue > 0 then return true end
  return false
end

function M.disableRallyDebug()
  local changed = {}
  local function visitTable(tbl, selfArg, label)
    if type(tbl) ~= "table" then return end
    local done = {}
    local function visit(src)
      if type(src) ~= "table" then return end
      for k, v in pairs(src) do
        local ks = tostring(k)
        local lk = ks:lower()
        if not done[ks] and lk:find("debug", 1, true) and not lk:find("logging", 1, true) then
          done[ks] = true
          if type(v) == "boolean" then
            if v == true then
              pcall(function() tbl[k] = false end)
              changed[#changed + 1] = label .. "." .. ks .. "=false"
            end
          elseif type(v) == "function" then
            if lk:match("^set") or lk:match("^enable") then
              if selfArg ~= nil then pcall(v, selfArg, false) else pcall(v, false) end
              changed[#changed + 1] = label .. "." .. ks .. "(false)"
            elseif lk:match("^is") or lk:match("^get") then
              local ok, res = pcall(v, selfArg)
              local tg = tbl.toggleDebug
              if ok and res == true and type(tg) == "function" then
                pcall(tg, selfArg)
                changed[#changed + 1] = label .. ".toggleDebug()"
              end
            end
          end
        end
      end
    end
    visit(tbl)
    local mt = getmetatable(tbl)
    if mt and type(mt.__index) == "table" then visit(mt.__index) end
  end
  visitTable(gameplay_rally, nil, "gameplay_rally")
  visitTable(gameplay_rallyLoop, nil, "gameplay_rallyLoop")
  local rm, am = getNativeAudioManager()
  if rm then visitTable(rm, rm, "rallyManager") end
  if am then visitTable(am, am, "audioManager") end
  -- The green markers / black text labels come from the pacenote class's drawDebug* methods: make them do nothing
  if rm then
    local pns = listNativePacenotes(rm)
    local mt = pns[1] and getmetatable(pns[1])
    local cls = mt and type(mt.__index) == "table" and mt.__index or nil
    if cls and not cls._nrmpDebugDrawOff then
      cls._nrmpDebugDrawOff = true
      local n = 0
      for k, v in pairs(cls) do
        if type(k) == "string" and k:sub(1, 9) == "drawDebug" and type(v) == "function" then
          cls[k] = function() end
          n = n + 1
        end
      end
      changed[#changed + 1] = "pacenote.drawDebug*(" .. tostring(n) .. " silenced)"
    end
  end
  return changed
end

-- Writes what the game's pacenotes really look like to <BeamNG user folder>/settings/rallymp_probe.json (for debugging note text/voice binding)
function M.writeRallyProbe()
  local rm, am = getNativeAudioManager()
  if not rm or not jsonWriteFile then return false end
  local SKIP = { notebook = true, parent = true, rm = true, rallyManager = true, audioManager = true, codriver = true, path = true, segment = true }
  local function safeDump(v, depth, seen)
    local t = type(v)
    if t == "string" or t == "number" or t == "boolean" then return v end
    if t ~= "table" then return "<" .. t .. ">" end
    if depth <= 0 or seen[v] then return "<table>" end
    seen[v] = true
    local out, n = {}, 0
    for k, val in pairs(v) do
      local ks = tostring(k)
      if ks:sub(1, 1) ~= "_" and not SKIP[ks] and type(val) ~= "function" then
        n = n + 1
        if n > 40 then out["..."] = "truncated"; break end
        out[ks] = safeDump(val, depth - 1, seen)
      end
    end
    seen[v] = nil
    return out
  end
  local function members(t)
    local ks = {}
    if type(t) == "table" then
      for k, v in pairs(t) do ks[#ks + 1] = tostring(k) .. (type(v) == "function" and "()" or "") end
      local mt = getmetatable(t)
      if mt and type(mt.__index) == "table" then
        for k, v in pairs(mt.__index) do ks[#ks + 1] = tostring(k) .. (type(v) == "function" and "()" or "") end
      end
    end
    table.sort(ks)
    return ks
  end
  local pns = listNativePacenotes(rm)
  local raw, texts = {}, {}
  for i = 1, math.min(#pns, 6) do raw[#raw + 1] = safeDump(pns[i], 4, {}) end
  for i = 1, math.min(#pns, 15) do texts[#texts + 1] = extractPacenoteText(pns[i]) end
  local ok = pcall(jsonWriteFile, "/settings/rallymp_probe.json", {
    pacenoteCount = #pns,
    extractedTexts = texts,
    firstPacenotesRaw = raw,
    rallyManagerMembers = members(rm),
    audioManagerMembers = members(am),
    gameplayRallyMembers = members(gameplay_rally)
  }, true)
  log("I", "nativeRallyBridge", "[RallyProbe] rallyManager members: " .. table.concat(members(rm), ", "))
  log("I", "nativeRallyBridge", "[RallyProbe] gameplay_rally members: " .. table.concat(members(gameplay_rally), ", "))
  if ok then log("I", "nativeRallyBridge", "[RallyProbe] wrote settings/rallymp_probe.json (" .. tostring(#pns) .. " pacenotes)") end
  return ok
end

local function normNoteText(t)
  return (tostring(t or ""):lower():gsub("[^%w]+", " "):gsub("^%s+", ""):gsub("%s+$", ""))
end

-- Word-overlap similarity (0..1) between two notes, so small wording/style differences still bind to the right recording
local function noteSimilarity(a, b)
  local wa, wb, na, nb, hit = {}, {}, 0, 0, 0
  for w in normNoteText(a):gmatch("%S+") do if not wa[w] then wa[w] = true; na = na + 1 end end
  for w in normNoteText(b):gmatch("%S+") do if not wb[w] then wb[w] = true; nb = nb + 1 end end
  if na == 0 or nb == 0 then return 0 end
  for w in pairs(wa) do if wb[w] then hit = hit + 1 end end
  return hit / (na + nb - hit)
end

-- Finds the native pacenote for a roadbook note: exact text, then note-id slot (verified), then best word-overlap
local function findNativePacenote(pns, text, noteId)
  local want = normNoteText(text)
  if want ~= "" then
    for _, pn in ipairs(pns) do
      if normNoteText(extractPacenoteText(pn)) == want then return pn end
    end
  end
  local idx = tonumber(tostring(noteId or ""):match("_nb_(%d+)$"))
  if idx and pns[idx] and (want == "" or noteSimilarity(extractPacenoteText(pns[idx]), text) >= 0.5) then
    return pns[idx]
  end
  local best, bestScore = nil, 0
  for _, pn in ipairs(pns) do
    local sc = noteSimilarity(extractPacenoteText(pn), text)
    if sc > bestScore then best, bestScore = pn, sc end
  end
  if best and bestScore >= 0.6 then return best end
  return nil
end

local function logNativeVoiceProbeOnce(am, pn)
  if STATE._nrmpVoiceProbeLogged then return end
  STATE._nrmpVoiceProbeLogged = true
  local function keysOf(t)
    local ks = {}
    if type(t) == "table" then
      for k, v in pairs(t) do ks[#ks + 1] = tostring(k) .. (type(v) == "function" and "()" or "") end
      local mt = getmetatable(t)
      if mt and type(mt.__index) == "table" then
        for k, v in pairs(mt.__index) do ks[#ks + 1] = tostring(k) .. (type(v) == "function" and "()" or "") end
      end
    end
    table.sort(ks)
    return table.concat(ks, ", ")
  end
  log("I", "nativeRallyBridge", "[VoiceProbe] audioManager members: " .. keysOf(am))
  if pn then log("I", "nativeRallyBridge", "[VoiceProbe] pacenote members: " .. keysOf(pn)) end
end

-- Plays a note through BeamNG's native co-driver voice. Returns true only if a native pacenote was found and handed to the audioManager.
local function nativeSpeakPacenote(text, noteId)
  if not CFG.preferNativeVoice then return false end
  local rm, am = getNativeAudioManager()
  if not rm or not am then
    log("I", "nativeRallyBridge", "Native voice unavailable (no rally manager/audioManager) - using fallback voice + subtitles")
    return false
  end

  local pns = listNativePacenotes(rm)
  local target = findNativePacenote(pns, text, noteId)
  logNativeVoiceProbeOnce(am, target or pns[1])
  if not target then
    log("I", "nativeRallyBridge", "No native pacenote matches this note (custom/stamped note) - using fallback voice + subtitles")
    return false
  end

  -- Allow the mute hooks / settings through for a short window so a co-driver call is audible even when auto-voice is muted
  STATE.allowManualNativeVoice = true
  STATE.manualVoiceRestoreTimer = 4.0
  STATE.manualVoiceExtendLeft = 30
  if STATE.aiVoiceMutedKeepOff and settings and settings.setValue then
    pcall(settings.setValue, "rallyAudioPacenotes", true)
  end

  -- BeamNG's audio manager queues a pacenote's recorded phrases via enqueuePacenoteAudio (or enqueueAudioObjs)
  local played = false
  if type(am.enqueuePacenoteAudio) == "function" then
    played = pcall(am.enqueuePacenoteAudio, am, target)
  end
  if not played and type(am.enqueueAudioObjs) == "function" and type(target.audioObjs) == "function" then
    local okO, objs = pcall(target.audioObjs, target)
    if okO and objs then played = pcall(am.enqueueAudioObjs, am, objs) end
  end
  if played then log("I", "nativeRallyBridge", "Co-driver note queued on in-game voice: " .. tostring(text)) end
  if not played then
    STATE.allowManualNativeVoice = false
    STATE.manualVoiceRestoreTimer = 0
  end
  return played
end

-- Captions for BeamNG's own automatic pacenote calls (two-car mode / driver with voicepack ON)
local function installNativeSubtitleHook()
  if not CFG.subtitlesForNotes then return end
  local _, am = getNativeAudioManager()
  if not am or am._nrmpSubHooked then return end
  am._nrmpSubHooked = true
  local fname = (type(am.enqueuePacenoteAudio) == "function" and "enqueuePacenoteAudio") or nil
  if not fname then return end
  local orig = am[fname]
  am[fname] = function(selfAm, pn, ...)
    local silenced = STATE.aiVoiceMutedKeepOff and not STATE.allowManualNativeVoice
    if not silenced and not STATE.allowManualNativeVoice then
      local okT, txt = pcall(extractPacenoteText, pn)
      if okT and txt and txt ~= "" then emitSubtitle(txt, "CO-DRIVER") end
    end
    return orig(selfAm, pn, ...)
  end
  logNativeVoiceProbeOnce(am, nil)
end

-- Disables native AI voicepack (and keeps it off) when Shared Co-Driver is selected; hides Driver visual notes
local function silenceAiVoicepackAndEnforceHud()
  if STATE.participationMode == "codriver" and CFG.codriverMuteAiVoicepack then
    STATE.aiVoiceMutedKeepOff = true
  end

  local manualVoiceWindow = (tonumber(STATE.manualVoiceRestoreTimer) or 0) > 0

  if STATE.aiVoiceMutedKeepOff and not manualVoiceWindow and settings and settings.setValue then
    pcall(settings.setValue, "rallyAudioPacenotes", false)
  end

  if STATE.aiVoiceMutedKeepOff and not manualVoiceWindow and gameplay_rally and gameplay_rally.getRallyManager then
    local okRm, rm = pcall(gameplay_rally.getRallyManager)
    if okRm and rm and rm.audioManager then
      local am = rm.audioManager
      if am.resetQueue then pcall(am.resetQueue, am) end
      if not am._nrmpVoiceSilenced then
        local origEnq = am.enqueuePacenoteAudio
        if type(origEnq) == "function" then
          am.enqueuePacenoteAudio = function(selfAm, ...)
            if STATE.aiVoiceMutedKeepOff and not STATE.allowManualNativeVoice then return end
            return origEnq(selfAm, ...)
          end
        end
        local origPlay = am.enqueueAudioObjs
        if type(origPlay) == "function" then
          am.enqueueAudioObjs = function(selfAm, ...)
            if STATE.aiVoiceMutedKeepOff and not STATE.allowManualNativeVoice then return end
            return origPlay(selfAm, ...)
          end
        end
        am._nrmpVoiceSilenced = true
      end
    end
  end

  local hideDriverNotes = (STATE.participationMode == "codriver" and STATE.role == "DRIVER" and CFG.codriverHideDriverNotes)
  if settings and settings.setValue and hideDriverNotes then
    pcall(settings.setValue, "rallyVisualPacenotes", false)
  end
  execMainUiJs("try{if(window.__NativeRallyMP&&window.__NativeRallyMP.setDriverHideVisualNotes)window.__NativeRallyMP.setDriverHideVisualNotes(" .. (hideDriverNotes and "true" or "false") .. ");}catch(e){}")
end

local function installPassengerCameraLockGuard()
  if STATE.hookedCameraGuard or not core_camera then return end
  if type(core_camera.setByName) == "function" then
    local origSetByName = core_camera.setByName
    core_camera._nrmpOrigSetByName = origSetByName
    core_camera.setByName = function(player, camName, ...)
      if STATE.passengerCamLocked and not STATE.allowingInternalPassengerCamSet and tostring(camName) ~= "driver" then
        return
      end
      return origSetByName(player, camName, ...)
    end
  end
  if type(core_camera.changeCamera) == "function" then
    local origChangeCam = core_camera.changeCamera
    core_camera.changeCamera = function(...)
      if STATE.passengerCamLocked then
        return
      end
      return origChangeCam(...)
    end
  end
  STATE.hookedCameraGuard = true
end

local function despawnOwnExtraVehicleForCoDriver()
  if not CFG.codriverDespawnExtraCarAndLockCam then return end
  -- Free-roam / pre-event auto co-driver entry must never delete the player's parked car or walking avatar
  if not STATE.activeMissionId then return end
  pcall(saveOwnPlayerVehicleConfig)

  local toDeleteIds = {}
  if MPVehicleGE and type(MPVehicleGE.getVehicles) == "function" then
    local okAll, vehs = pcall(MPVehicleGE.getVehicles)
    if okAll and type(vehs) == "table" then
      for _, mpv in pairs(vehs) do
        local gvid = type(mpv) == "table" and tonumber(mpv.gameVehicleID) or nil
        if gvid and mpv.isLocal == true then
          local o = (scenetree and scenetree.findObjectById and scenetree.findObjectById(gvid)) or (be and be:getObjectByID(gvid))
          if not isUnicycleVeh(o) then
            toDeleteIds[#toDeleteIds + 1] = gvid
          end
        end
      end
    end
  end

  local own = getOwnVehicle()
  if own and own.getID then
    toDeleteIds[#toDeleteIds + 1] = own:getID()
  end

  local deletedMap = {}
  for _, gvid in ipairs(toDeleteIds) do
    if not deletedMap[gvid] and not isRemoteMpVehicle(gvid) then
      deletedMap[gvid] = true
      local obj = (scenetree and scenetree.findObjectById and scenetree.findObjectById(gvid)) or (be and be:getObjectByID(gvid))
      if obj and obj.delete then
        pcall(function() obj:delete() end)
      end
    end
  end

  sendServerEvent("NativeRally_DespawnCoDriverCars", "{}")
end

local function applyLockedPassengerBucketCamera(driverObj, gvid)
  if not driverObj then return end
  installPassengerCameraLockGuard()
  if be and be:getPlayerVehicleID(0) ~= gvid then
    pcall(function() be:enterVehicle(0, driverObj) end)
  end

  STATE.allowingInternalPassengerCamSet = true
  if core_camera and core_camera.setByName then
    pcall(core_camera.setByName, 0, "driver")
  end
  STATE.allowingInternalPassengerCamSet = false

  -- Shift onboard cockpit camera laterally into the right-hand passenger bucket seat (+0.39m)
  local lateralSeatM = 0.39
  if core_camera then
    if type(core_camera.setOffset) == "function" then
      pcall(core_camera.setOffset, 0, vec3(lateralSeatM, -0.03, 0.01))
    end
    if type(core_camera.getVehicleData) == "function" then
      local okVd, vCamData = pcall(core_camera.getVehicleData, gvid)
      if okVd and type(vCamData) == "table" and type(vCamData.cameras) == "table" and vCamData.cameras.driver then
        local dCam = vCamData.cameras.driver
        if not dCam._nrmpOrigCamBasePos and dCam.camBasePos then
          dCam._nrmpOrigCamBasePos = vec3(dCam.camBasePos)
        end
        if dCam._nrmpOrigCamBasePos then
          dCam.camBasePos = vec3(dCam._nrmpOrigCamBasePos.x - lateralSeatM, dCam._nrmpOrigCamBasePos.y, dCam._nrmpOrigCamBasePos.z)
        end
      end
    end
  end

  if CFG.codriverDespawnExtraCarAndLockCam then
    STATE.passengerCamLocked = true
  end
  STATE.passengerTrackedVehId = gvid
end

local function releaseCoDriverPassengerLock(restoreCarBool)
  local prevGvid = STATE.passengerTrackedVehId
  STATE.passengerCamLocked = false
  STATE.passengerTrackedVehId = nil

  if core_camera then
    if type(core_camera.setOffset) == "function" then
      pcall(core_camera.setOffset, 0, vec3(0, 0, 0))
    end
    if prevGvid and type(core_camera.getVehicleData) == "function" then
      local okVd, vCamData = pcall(core_camera.getVehicleData, prevGvid)
      if okVd and type(vCamData) == "table" and type(vCamData.cameras) == "table" and vCamData.cameras.driver and vCamData.cameras.driver._nrmpOrigCamBasePos then
        vCamData.cameras.driver.camBasePos = vec3(vCamData.cameras.driver._nrmpOrigCamBasePos)
      end
    end
  end

  if restoreCarBool and STATE.participationMode == "two_car" and getOwnVehicle() == nil then
    ensureSavedPlayerVehicleRestored()
  end
end

-- No invented notes: the roadbook only ever shows the game's real pacenotes (or notes you write/stamp yourself)
local function buildStructuredFallbackNotesForTrack(_trackKey)
  return {}
end

local function extractIconAndSeverityFromText(txt, idx)
  local lower = tostring(txt or ""):lower()
  local dir = lower:find("left", 1, true) and "L" or (lower:find("right", 1, true) and "R" or "")
  if lower:find("hairpin", 1, true) then
    return (dir == "L" and "HPL" or "HPR"), 1
  elseif lower:find("square", 1, true) then
    return (dir == "L" and "SQL" or "SQR"), 2
  elseif lower:find("jump", 1, true) then
    return "JMP", 3
  elseif dir ~= "" then
    for d = 1, 6 do
      if lower:find(tostring(d), 1, true) then
        return (dir .. tostring(d)), d
      end
    end
    return (dir .. "4"), 4
  elseif lower:find("caution", 1, true) or lower:find("care", 1, true) then
    return "CAU", 2
  end
  return "CR", ((idx % 2 == 0) and 4 or 5)
end

-- Native notes can arrive as a dumped table string like { "six right", "crest" }; turn that into plain words
local function cleanNativeNoteText(txt)
  local t = tostring(txt or "")
  if t:find('"', 1, true) or t:match("^%s*[{%(%[]") then
    local words = {}
    for q in t:gmatch('"([^"]*)"') do
      q = q:gsub("^%s+", ""):gsub("%s+$", "")
      if q ~= "" then words[#words + 1] = q end
    end
    if #words > 0 then return table.concat(words, " ") end
    t = t:gsub("[{}%(%)%[%]\"]", "")
  end
  t = t:gsub("%s+", " "):gsub("^%s+", ""):gsub("%s+$", "")
  return t
end

-- Turns a list of { text = "...", dist = optional metres } into roadbook notes
local function buildRoadbookFromEntries(entries, trackKey)
  local parsed = {}
  for idx, e in ipairs(entries) do
    local sourceIndex = tonumber(e.nativeIndex) or idx
    local noteTxt = cleanNativeNoteText(e.text)
    if noteTxt == "" then noteTxt = "Pacenote " .. tostring(sourceIndex) end
    local ic, sev = extractIconAndSeverityFromText(noteTxt, sourceIndex)
    local distEst = tonumber(e.dist) or (sourceIndex * 85)
    local lower = noteTxt:lower()
    local isHaz = lower:find("caution", 1, true) ~= nil or lower:find("don't cut", 1, true) ~= nil or sev <= 2
    parsed[#parsed + 1] = {
      id = sanitizeClientTrackKey(trackKey) .. "_nb_" .. tostring(sourceIndex),
      nativeIndex = sourceIndex,
      distanceM = math.floor(distEst),
      linkDistanceM = 85,
      iconCode = ic,
      severity = sev,
      proText = noteTxt,
      nativeText = noteTxt,
      shorthandText = ic .. " · " .. noteTxt:sub(1, 28),
      clubmanText = noteTxt,
      highlightHazard = isHaz
    }
  end
  if #parsed > 0 then return parsed end
  return nil
end

-- Reads the real pacenotes from the notebook file shipped with the mission
local function tryParseNativeMissionNotebook(missionDir, trackKey)
  if not FS or not jsonReadFile or not missionDir or missionDir == "" then return nil end
  local okF, files = pcall(function() return FS:findFiles(missionDir, "*.notebook.json", -1, true, false) end)
  if not okF or type(files) ~= "table" or #files == 0 then return nil end
  local nb = jsonReadFile(files[1])
  if type(nb) ~= "table" then return nil end
  local source = type(nb.notebook) == "table" and nb.notebook or (type(nb.data) == "table" and nb.data or nb)
  local rawList = source.pacenotes or source.values or source.notes or nb.pacenotes or nb.values
  if type(rawList) == "table" and #rawList == 0 then
    for _, key in ipairs({ "sorted", "objects", "values", "entries", "notes", "data" }) do
      if type(rawList[key]) == "table" and #rawList[key] > 0 then
        rawList = rawList[key]
        break
      end
    end
  end
  if type(rawList) ~= "table" or #rawList == 0 then return nil end
  local entries = {}
  for idx, item in ipairs(rawList) do
    local txt = extractPacenoteText(item)
    local dist = nil
    if type(item) == "table" then
      if txt == "" then txt = tostring(item.note or item.name or "") end
      dist = item.distanceM or item.dist
    end
    if txt ~= "" then
      entries[#entries + 1] = { text = txt, dist = dist, nativeIndex = idx }
    end
  end
  if #entries == 0 then return nil end
  return buildRoadbookFromEntries(entries, trackKey)
end

-- Reads the real pacenotes straight from the running rally stage (same list the in-game co-driver speaks from)
local function tryReadLiveNotebook(trackKey)
  local rm = select(1, getNativeAudioManager())
  if not rm then return nil end
  local pns = listNativePacenotes(rm)
  if #pns == 0 then return nil end
  local entries = {}
  for idx, pn in ipairs(pns) do
    local d = nil
    if type(pn) == "table" then d = tonumber(pn.distanceM or pn.dist or pn.distanceFromStart) end
    entries[#entries + 1] = { text = extractPacenoteText(pn), dist = d, nativeIndex = idx }
  end
  return buildRoadbookFromEntries(entries, trackKey)
end
M.tryReadLiveNotebook = tryReadLiveNotebook -- exposed on M so the per-frame tick doesn't need another upvalue

local function mergeSavedRoadbookNotes(savedNotes, nativeNotes)
  if type(savedNotes) ~= "table" then return nativeNotes or {} end
  if type(nativeNotes) ~= "table" or #nativeNotes == 0 then return savedNotes end

  local savedById, merged, used = {}, {}, {}
  for _, note in ipairs(savedNotes) do
    if type(note) == "table" and note.id then savedById[tostring(note.id)] = note end
  end
  for _, nativeNote in ipairs(nativeNotes) do
    local note = {}
    for k, v in pairs(nativeNote) do note[k] = v end
    local saved = savedById[tostring(nativeNote.id or "")]
    if saved then
      for k, v in pairs(saved) do
        if k ~= "nativeText" then note[k] = v end
      end
      note.nativeText = nativeNote.nativeText or nativeNote.proText
      used[tostring(nativeNote.id)] = true
    end
    merged[#merged + 1] = note
  end
  for _, saved in ipairs(savedNotes) do
    if type(saved) == "table" and not used[tostring(saved.id or "")] then
      merged[#merged + 1] = saved
    end
  end
  table.sort(merged, function(a, b) return (tonumber(a.distanceM) or 0) < (tonumber(b.distanceM) or 0) end)
  return merged
end

local function loadOrBuildTrackRoadbook(missionId, missionDir)
  local trackKey = tostring(missionId or getCurrentLevelName() or "default_track")
  STATE.currentTrackKey = trackKey
  local liveNotes = tryReadLiveNotebook(trackKey)
  local nativeNotes = liveNotes or tryParseNativeMissionNotebook(missionDir, trackKey)
  STATE.roadbookFromLive = (liveNotes ~= nil)

  if jsonReadFile then
    local okR, localSaved = pcall(jsonReadFile, getClientTrackNotesPath(trackKey))
    if okR and type(localSaved) == "table" and type(localSaved.notes) == "table" and #localSaved.notes > 0 then
      STATE.roadbookNotes = mergeSavedRoadbookNotes(localSaved.notes, nativeNotes)
      STATE.roadbookCustomSaved = true
      sendServerEvent("NativeRally_RequestTrackNotes", { trackKey = trackKey })
      return
    end
  end

  if nativeNotes then
    STATE.roadbookNotes = nativeNotes
    STATE.roadbookCustomSaved = false
    STATE.roadbookFromLive = (liveNotes ~= nil)
  else
    STATE.roadbookNotes = buildStructuredFallbackNotesForTrack(trackKey)
    STATE.roadbookCustomSaved = false
  end

  sendServerEvent("NativeRally_RequestTrackNotes", { trackKey = trackKey })
end

local function updateCoDriverStageOdometer(dtReal)
  local isPreEventScout = (STATE.stagedMissionId ~= nil and STATE.activeMissionId == nil)
  if not isPreEventScout and (STATE.participationMode ~= "codriver" or STATE.role ~= "CODRIVER") then return end
  STATE.odometerPushTimer = STATE.odometerPushTimer + dtReal
  if STATE.odometerPushTimer < 0.14 then return end
  STATE.odometerPushTimer = 0

  local dObj = nil
  if isPreEventScout then
    -- During pre-event Freeroam Mingle & Route Prep, both cars stay active; track own freeroam vehicle for live '+ Stamp @ Car'
    dObj = getOwnVehicle()
  else
    local gvid = STATE.passengerTrackedVehId
    if not gvid and STATE.driverServerVehId ~= "" then
      local mpv = findMpVehicleEntryByServerString(STATE.driverServerVehId)
      if mpv and mpv.gameVehicleID then
        gvid = tonumber(mpv.gameVehicleID)
      end
    end
    if not gvid then return end
    dObj = (scenetree and scenetree.findObjectById and scenetree.findObjectById(gvid)) or (be and be:getObjectByID(gvid))
    if dObj and CFG.codriverDespawnExtraCarAndLockCam and be and be:getPlayerVehicleID(0) ~= gvid then
      applyLockedPassengerBucketCamera(dObj, gvid)
    end
  end

  if not dObj or not dObj.getPosition then return end

  local curPos = dObj:getPosition()
  if not STATE.stageStartOriginPos then
    STATE.stageStartOriginPos = vec3(curPos)
    STATE.liveOdometerM = 0
  else
    local stepDist = curPos:distance(STATE.stageStartOriginPos)
    STATE.liveOdometerM = math.max(0, stepDist)
  end

  execMainUiJs("try{if(window.__NativeRallyMP&&window.__NativeRallyMP.updateOdometer)window.__NativeRallyMP.updateOdometer(" .. tostring(math.floor(STATE.liveOdometerM)) .. ");}catch(e){}")
end

local function bindSharedCoDriverCrew(driverServerVehId, missionId, missionDir)
  silenceAiVoicepackAndEnforceHud()
  despawnOwnExtraVehicleForCoDriver()
  loadOrBuildTrackRoadbook(missionId, missionDir)
  STATE.stageStartOriginPos = nil
  STATE.liveOdometerM = 0

  if not MPVehicleGE or driverServerVehId == "" then return end
  local mpVeh = findMpVehicleEntryByServerString(driverServerVehId)
  if not mpVeh or not mpVeh.gameVehicleID then return end

  local gvid = mpVeh.gameVehicleID
  if gameplay_seatOccupants and gameplay_seatOccupants.getSeats and gameplay_seatOccupants.clearDummyOccupant then
    for _, seat in ipairs(gameplay_seatOccupants.getSeats(gvid) or {}) do
      if not seat.isDriver then
        pcall(gameplay_seatOccupants.clearDummyOccupant, gvid, seat.seatId)
      end
    end
  end

  local driverObj = scenetree.findObjectById(gvid) or be:getObjectByID(gvid)
  if driverObj then
    applyLockedPassengerBucketCamera(driverObj, gvid)
  end

  if gameplay_rally and gameplay_rally.loadMission and missionId and missionDir then
    pcall(gameplay_rally.loadMission, missionId, missionDir, nil, nil, { owner = "external" })
    local rm = gameplay_rally.getRallyManager and gameplay_rally.getRallyManager()
    if rm and rm.vehicleTracker then
      rm.vehicleTracker.getVehicleId = function() return gvid end
    end
  end
  silenceAiVoicepackAndEnforceHud()
end

local function injectPeerIntoNativeEndScreen()
  if not CFG.injectEndScreenLeaderboard or not core_flowgraphManager then return end
  if not core_flowgraphManager.getAllManagers then return end

  for _, mgr in pairs(core_flowgraphManager.getAllManagers() or {}) do
    if mgr and mgr.modules and mgr.modules.ui and not mgr.modules.ui._nativeRallyWrapped then
      local uiMod = mgr.modules.ui
      local origAdd = uiMod.addUIElement
      if type(origAdd) == "function" then
        uiMod.addUIElement = function(selfUi, elem, ...)
          if type(elem) == "table" and type(elem.leaderboard) == "table" and #STATE.peerStandings > 0 then
            for _, peer in ipairs(STATE.peerStandings) do
              if peer.slot ~= STATE.slot and peer.totalSec and peer.totalSec > 0 then
                table.insert(elem.leaderboard, {
                  name = "[MP] " .. tostring(peer.name),
                  isPlayer = false,
                  isMultiplayerPeer = true,
                  totalTime = peer.totalSec,
                  time = peer.totalSec,
                  penalty = peer.penaltySec or 0,
                  stageTimes = peer.stageTimes or {}
                })
              end
            end
            table.sort(elem.leaderboard, function(a, b)
              local ta = tonumber(a.totalTime or a.time) or 999999
              local tb = tonumber(b.totalTime or b.time) or 999999
              return ta < tb
            end)
          end
          return origAdd(selfUi, elem, ...)
        end
        uiMod._nativeRallyWrapped = true
      end
    end
  end
end

-- Scans ALL installed BeamNG maps + ALL official/modded rallyLoop & rallyStage missions (pairs-safe for v0.40+)
local function scanAllMapsAndRallyMissions()
  pcall(extensions.load, "gameplay_missions_missions")
  pcall(extensions.load, "gameplay_missions_missionManager")
  pcall(extensions.load, "gameplay_rally")
  pcall(extensions.load, "gameplay_rallyLoop")

  local curLvl = getCurrentLevelName()
  local mapsOut = {}
  if core_levels and type(core_levels.getList) == "function" then
    local okL, rawLevels = pcall(core_levels.getList)
    if okL and type(rawLevels) == "table" then
      for _, lv in pairs(rawLevels) do
        if type(lv) == "table" then
          local ln = tostring(lv.levelName or ""):lower()
          if ln ~= "" then
            mapsOut[#mapsOut + 1] = {
              levelName = ln,
              title = humanMissionName(lv.title, ln),
              mapInfoPath = "/levels/" .. ln .. "/info.json",
              misFilePath = tostring(lv.misFilePath or ("/levels/" .. ln .. "/main.level.json"))
            }
          end
        end
      end
    end
  end
  STATE.allMaps = mapsOut

  local seenIds = {}
  local seenNames = {}
  local missionsOut = {}

  local function collectFromTable(tbl)
    if type(tbl) ~= "table" then return end
    for _, m in pairs(tbl) do
      if isSupportedNativeMission(m) and m.id then
        local mid = tostring(m.id)
        local mLvl = (m.startTrigger and m.startTrigger.level) and tostring(m.startTrigger.level):lower() or ""
        if mLvl == "" and mid:find("/") then
          mLvl = mid:match("^([^/]+)"):lower()
        end
        if CFG.unlockAllGameMapsCatalog or curLvl == "" or mLvl == curLvl then
          local dispName = humanMissionName(m.name, mid)
          local normName = dispName:lower()
          if not seenIds[mid] and not seenNames[normName] then
            seenIds[mid] = true
            seenNames[normName] = true
            missionsOut[#missionsOut + 1] = {
              id = mid,
              missionDir = tostring(m.missionFolder or ("/gameplay/missions/" .. mid)),
              name = dispName,
              missionType = tostring(m.missionType),
              levelName = mLvl,
              previewFile = tostring(m.previewFile or m.thumbFile or ("/gameplay/missions/" .. mid .. "/preview.jpg"))
            }
          end
        end
      end
    end
  end

  if gameplay_missions_missions then
    if type(gameplay_missions_missions.get) == "function" then
      local okM, allMissions = pcall(gameplay_missions_missions.get)
      if okM then collectFromTable(allMissions) end
    end
    if type(gameplay_missions_missions.getFilesData) == "function" then
      local okF, filesData = pcall(gameplay_missions_missions.getFilesData)
      if okF then collectFromTable(filesData) end
    end
  end

  if CFG.unlockAllGameMapsCatalog then
    for _, fb in ipairs(OFFICIAL_RALLY_FALLBACKS) do
      local normFb = fb.name:lower()
      local typeAllowed = (fb.missionType == "rallyLoop" and CFG.allowRallyLoop) or (fb.missionType == "rallyStage" and CFG.allowRallyStage)
      if typeAllowed and not seenIds[fb.id] and not seenNames[normFb] then
        missionsOut[#missionsOut + 1] = {
          id = fb.id,
          missionDir = "/gameplay/missions/" .. fb.id,
          name = fb.name,
          missionType = fb.missionType,
          levelName = fb.levelName,
          previewFile = fb.previewFile
        }
      end
    end
  end

  STATE.globalMissions = missionsOut
  STATE.catalogScanned = true
  log("I", "nativeRallyBridge", "Scanned " .. tostring(#missionsOut) .. " Rally missions across " .. tostring(#mapsOut) .. " BeamNG maps.")

  sendServerEvent("NativeRally_HostCatalog", {
    currentLevel = curLvl,
    maps = mapsOut,
    missions = missionsOut
  })
  emitVueBridgeState()
end

local function findCatalogMission(missionId)
  for _, m in ipairs(STATE.globalMissions) do
    if m.id == missionId then return m end
  end
  local lvl = tostring(missionId):match("^([^/]+)") or ""
  return {
    id = tostring(missionId),
    missionDir = "/gameplay/missions/" .. tostring(missionId),
    name = tostring(missionId),
    missionType = tostring(missionId):find("rallyLoop") and "rallyLoop" or "rallyStage",
    levelName = lvl:lower()
  }
end

local function hookMissionManager()
  if STATE.hookedMissionManager or not gameplay_missions_missionManager then return end

  if type(gameplay_missions_missionManager.startWithFade) == "function" then
    local origStart = gameplay_missions_missionManager.startWithFade
    gameplay_missions_missionManager.startWithFade = function(mission, userSettings, ...)
      local resolved = (type(mission) == "string" and gameplay_missions_missions)
        and gameplay_missions_missions.getMissionById(mission) or mission

      if resolved and isSupportedNativeMission(resolved) and not STATE.launchingFromServer and STATE.launchingFromServerTimer <= 0 and TriggerServerEvent then
        M.vueProposeMission(tostring(resolved.id), STATE.vehicleMode, STATE.participationMode, STATE.launchMode)
        return
      end

      installMpVehicleGeHooks()
      local res = origStart(mission, buildMultiplayerUserSettings(resolved, userSettings, { vehicleMode = STATE.vehicleMode }), ...)
      restoreAllRemoteMpVehicles()
      installTrafficDeleteShield()
      hookNativeGameplayRally()
      hookNativeGameplayRallyLoop()
      checkAndApplySpawnSeparation()
      enforceCollisionPolicy(false)
      reconcileSingleActivePlayerVehicle()
      flushMpSpawnQueueNow(true)
      return res
    end
  end

  if type(gameplay_missions_missionManager.startFromMainMenu) == "function" then
    local origMainMenu = gameplay_missions_missionManager.startFromMainMenu
    gameplay_missions_missionManager.startFromMainMenu = function(mission, userSettings, ...)
      local resolved = (type(mission) == "string" and gameplay_missions_missions)
        and gameplay_missions_missions.getMissionById(mission) or mission

      if resolved and isSupportedNativeMission(resolved) and not STATE.launchingFromServer and STATE.launchingFromServerTimer <= 0 and TriggerServerEvent then
        M.vueProposeMission(tostring(resolved.id), STATE.vehicleMode, STATE.participationMode, STATE.launchMode)
        return
      end

      return origMainMenu(mission, userSettings, ...)
    end
  end

  STATE.hookedMissionManager = true
end

-- ============================================================================
-- Vue 3 & CEF MainGEUI Pause Menu Bridge API
-- ============================================================================
function M.onCefMountedAck()
  if not STATE.cefMountedAck then
    STATE.cefMountedAck = true
    log("I", "nativeRallyBridge", "MainGEUI Pause Menu Rally Tab mounted via be:executeJS.")
  end
  pushMenuVisibilityToCef(true)
end

function M.onCefNeedsMount()
  STATE.cefMountedAck = false
  injectLiveCefPauseMenuUi()
  emitVueBridgeState()
end

function M.onCefBootModuleReady()
  STATE.cefMountedAck = false
  injectLiveCefPauseMenuUi()
  emitVueBridgeState()
end

function M.vueRequestState()
  if not STATE.catalogScanned and isLoadedInLevel() then
    scanAllMapsAndRallyMissions()
  else
    emitVueBridgeState()
  end
end

function M.vueSetVehicleMode(vehMode)
  if CFG.defaultVehicleChoice == "host_chooses" then
    STATE.vehicleMode = (vehMode == "stage_preset_car") and "stage_preset_car" or "own_mp_car"
    emitVueBridgeState()
  end
end

function M.vueProposeMission(missionId, vehicleMode, partMode, launchMode)
  if not missionId or missionId == "" then return end
  pcall(saveOwnPlayerVehicleConfig)
  local entry = findCatalogMission(missionId)
  local chosenVeh = vehicleMode or STATE.vehicleMode
  STATE.vehicleMode = chosenVeh

  log("I", "nativeRallyBridge", "Proposing Rally event -> id=" .. tostring(entry.id) .. " map=" .. tostring(entry.levelName) .. " veh=" .. tostring(chosenVeh))
  sendServerEvent("NativeRally_ProposeEvent", {
    actionType = "mission",
    currentLevel = getCurrentLevelName(),
    missionId = entry.id,
    missionDir = entry.missionDir,
    missionName = entry.name,
    missionType = entry.missionType,
    levelName = entry.levelName,
    vehicleMode = chosenVeh,
    participationMode = partMode or STATE.participationMode,
    launchMode = launchMode or STATE.launchMode
  })
end

function M.vueRespondProposal(acceptBool)
  pcall(saveOwnPlayerVehicleConfig)
  local decision = acceptBool and "accept" or "decline"
  log("I", "nativeRallyBridge", "Responding to Partner Ready-Check -> decision=" .. decision)
  if STATE.peerState then
    STATE.peerState.hasPendingProposal = false
    STATE.peerState.pendingProposal = false
  end
  emitVueBridgeState()
  sendServerEvent("NativeRally_RespondProposal", {
    decision = decision
  })
end

function M.vueCancelProposal()
  log("I", "nativeRallyBridge", "Cancelling active Rally invite proposal.")
  if STATE.peerState then
    STATE.peerState.hasPendingProposal = false
    STATE.peerState.pendingProposal = false
  end
  emitVueBridgeState()
  sendServerEvent("NativeRally_RespondProposal", { decision = "cancel" })
end

function M.vueSetMode(modeStr)
  sendServerEvent("NativeRally_UIAction", { action = "setMode", mode = tostring(modeStr) })
end

function M.vueSetLaunchMode(launchModeStr)
  sendServerEvent("NativeRally_UIAction", { action = "setLaunchMode", launchMode = tostring(launchModeStr) })
end

function M.vueSwapSlots()
  sendServerEvent("NativeRally_UIAction", { action = "swapSlots" })
end


function M.vueSpawnAtStartLine(mode)
  local targetMode = mode or STATE.freeroamSpawnMode or "random_rally"
  STATE.freeroamSpawnMode = targetMode
  if STATE.stagedStartPos and STATE.stagedStartPos.pos then
    local targetPos, targetRot = computeStagingTransform(STATE.stagedStartPos.pos, STATE.stagedStartPos.rot, STATE.slot, targetMode)
    STATE.pendingStartLinePlacement = {
      pos = targetPos,
      rot = targetRot,
      mode = targetMode,
      timer = 0.05,
      attempts = 0,
      spawnInitiated = false
    }
    if ui_message then
      local lbl = targetMode == "on_foot" and "On Foot" or (targetMode == "current_car" and "Current Car" or "Random Rally Car")
      ui_message("Spawning at Start Line: " .. lbl .. "...", 3, "nativeRally")
    end
  else
    if ui_message then ui_message("No staged rally start line found. Select an event first!", 3, "nativeRally") end
  end
  emitVueBridgeState()
end

function M.vueSetFreeroamSpawnMode(mode)
  if mode == "random_rally" or mode == "on_foot" or mode == "current_car" then
    STATE.freeroamSpawnMode = mode
    emitVueBridgeState()
  end
end

function M.vueStartStagedEvent(vehicleMode)
  pcall(saveOwnPlayerVehicleConfig)
  local chosenVeh = vehicleMode or STATE.vehicleMode
  STATE.vehicleMode = chosenVeh
  log("I", "nativeRallyBridge", "Requesting start of staged Rally event -> veh=" .. tostring(chosenVeh))
  sendServerEvent("NativeRally_UIAction", {
    action = "startStagedEvent",
    vehicleMode = chosenVeh
  })
end

function M.vueClearStagedEvent()
  STATE.stagedMissionId = nil
  STATE.stagedMissionDir = nil
  sendServerEvent("NativeRally_UIAction", { action = "clearStagedEvent" })
end

function M.vueStopMission()
  sendServerEvent("NativeRally_UIAction", { action = "stopMission" })
end

function M.vueToggleRecce()
  if not CFG.unlockNativeRallyFeatures then return end
  extensions.load("gameplay_rally")
  local nextVal = not (STATE.peerState and STATE.peerState.recceEnabled)
  if gameplay_rally and gameplay_rally.enableRecceApp then
    pcall(gameplay_rally.enableRecceApp, nextVal)
  end
  sendServerEvent("NativeRally_UIAction", { action = "toggleRecce", enabled = nextVal })
end

function M.vueNudgeCodriverTiming(earlierBool)
  if not CFG.unlockNativeRallyFeatures then return end
  extensions.load("gameplay_rally")
  if gameplay_rally then
    if earlierBool and gameplay_rally.actionCodriverCallsEarlier then
      gameplay_rally.actionCodriverCallsEarlier()
    elseif not earlierBool and gameplay_rally.actionCodriverCallsLater then
      gameplay_rally.actionCodriverCallsLater()
    end
  end
end

function M.vueToggleCountdownDisplay()
  local nextDisp = (STATE.countdownDisplay == "3d") and "2d" or "3d"
  STATE.countdownDisplay = nextDisp
  if settings and settings.setValue then
    pcall(settings.setValue, "rallyStartCountdownDisplay", nextDisp)
  end
  emitVueBridgeState()
end

function M.vueToggleAiVoicepack()
  STATE.aiVoiceMutedKeepOff = not STATE.aiVoiceMutedKeepOff
  if settings and settings.setValue then
    pcall(settings.setValue, "rallyAudioPacenotes", not STATE.aiVoiceMutedKeepOff)
  end
  silenceAiVoicepackAndEnforceHud()
  emitVueBridgeState()
end

function M.vueSaveEditedTrackNotes(trackKey, notesJson)
  if not CFG.codriverWritableTrackNotes then return end
  local parsed = jsonDecode and jsonDecode(notesJson) or nil
  if type(parsed) ~= "table" then return end
  local tKey = tostring(trackKey or STATE.currentTrackKey or STATE.activeMissionId or STATE.stagedMissionId or "default_track")
  STATE.currentTrackKey = tKey
  STATE.roadbookNotes = parsed
  STATE.roadbookCustomSaved = true

  if jsonWriteFile then
    pcall(jsonWriteFile, getClientTrackNotesPath(tKey), {
      trackKey = tKey,
      notes = parsed
    }, true)
  end

  sendServerEvent("NativeRally_SaveTrackNotes", {
    trackKey = tKey,
    notes = parsed
  })
  emitVueBridgeState()
end

function M.vueResetTrackNotes(trackKey)
  local tKey = tostring(trackKey or STATE.currentTrackKey or STATE.activeMissionId or STATE.stagedMissionId or "default_track")
  if FS and FS.removeFile then
    pcall(function() FS:removeFile(getClientTrackNotesPath(tKey)) end)
  end
  STATE.roadbookCustomSaved = false
  local nativeNotes = tryReadLiveNotebook(tKey) or tryParseNativeMissionNotebook(STATE.activeMissionDir or STATE.stagedMissionDir, tKey)
  STATE.roadbookNotes = nativeNotes or buildStructuredFallbackNotesForTrack(tKey)
  sendServerEvent("NativeRally_SaveTrackNotes", {
    trackKey = tKey,
    resetDefault = true
  })
  emitVueBridgeState()
end

function M.vueSetPreferNativeVoice(flag)
  CFG.preferNativeVoice = (flag == true or flag == "true")
end

function M.vueTriggerManualCallout(noteId, iconCode, severity, distanceM, callText, nativeText, speakText)
  if not CFG.codriverClickToCallVoice then return end
  local cleanText = tostring(callText or "")
  if cleanText == "" then return end
  if isMpSocketReady() then
    sendServerEvent("NativeRally_TriggerManualCallout", {
      noteId = tostring(noteId or ""),
      iconCode = tostring(iconCode or "CR"),
      severity = tonumber(severity) or 4,
      distanceM = tonumber(distanceM) or 0,
      callText = cleanText,
      nativeText = tostring(nativeText or ""),
      speakText = speakText == true
    })
  else
    local nativeOkLocal = speakText ~= true and nativeSpeakPacenote((tostring(nativeText or "") ~= "" and tostring(nativeText)) or cleanText, noteId) or false
    local fallbackJson = jsonEncode and jsonEncode({ noteId = tostring(noteId or ""), callText = cleanText, nativeVoice = nativeOkLocal, forceTts = speakText == true, speaker = "CO-DRIVER" }) or nil
    if fallbackJson then
      execMainUiJs("try{if(window.__NativeRallyMP&&window.__NativeRallyMP.playManualCallout)window.__NativeRallyMP.playManualCallout(" .. fallbackJson .. ");}catch(e){}")
    end
  end
end

-- Network Event Callbacks & Single-Shot Transition Jobs
local function isDuplicatePacket(tag, rawJson, windowMs)
  local now = clientNowMs()
  local sig = tostring(rawJson or "")
  local prev = STATE.recentPackets[tag]
  if prev and prev.sig == sig and (now - prev.atMs) < (windowMs or 500) then
    return true
  end
  STATE.recentPackets[tag] = { sig = sig, atMs = now }
  return false
end

local function onClockAck(rawJson)
  local pkt = jsonDecode(rawJson) or {}
  local now = clientNowMs()
  local sent = tonumber(pkt.clientSentMs) or now
  STATE.rttMs = math.max(1, now - sent)
end

local function stopAnyRunningForegroundMission()
  if not gameplay_missions_missionManager then return false end
  local fgId = gameplay_missions_missionManager.getForegroundMissionId and gameplay_missions_missionManager.getForegroundMissionId() or nil
  if not fgId then return false end
  local fgObj = (gameplay_missions_missions and gameplay_missions_missions.getMissionById and gameplay_missions_missions.getMissionById(fgId)) or fgId
  if type(gameplay_missions_missionManager.stop) == "function" then
    local okStop = pcall(gameplay_missions_missionManager.stop, fgObj, { instant = true })
    if not okStop then pcall(gameplay_missions_missionManager.stop, fgObj) end
  end
  if type(gameplay_missions_missionManager.attemptAbandonMission) == "function" then
    pcall(gameplay_missions_missionManager.attemptAbandonMission, fgObj)
  end
  return true
end

local function onPeerState(rawJson)
  local prevMode = STATE.participationMode
  STATE.peerState = normalizePeerState(jsonDecode(rawJson) or STATE.peerState)
  if STATE.peerState.participationMode then STATE.participationMode = STATE.peerState.participationMode end
  if STATE.peerState.launchMode then STATE.launchMode = STATE.peerState.launchMode end

  if type(STATE.peerState.peers) == "table" and STATE.peerState.yourPlayerId ~= nil then
    for _, p in ipairs(STATE.peerState.peers) do
      if tonumber(p.playerId) == tonumber(STATE.peerState.yourPlayerId) then
        STATE.slot = tonumber(p.slot) or STATE.slot
        STATE.role = (STATE.participationMode == "codriver" and STATE.slot == 2) and "CODRIVER" or "DRIVER"
        break
      end
    end
  end

  if STATE.participationMode == "codriver" then
    silenceAiVoicepackAndEnforceHud()
  elseif prevMode == "codriver" and STATE.participationMode == "two_car" then
    releaseCoDriverPassengerLock(true)
    silenceAiVoicepackAndEnforceHud()
  end

  flushMpSpawnQueueNow(false)
  emitVueBridgeState()
end

local function onOpenMenu(rawJson)
  if isDuplicatePacket("OpenMenu", rawJson, 350) then return end
  injectLiveCefPauseMenuUi()
  execMainUiJs("try{if(window.__NativeRallyMP)window.__NativeRallyMP.openStandalone();}catch(e){}")
end

local function executeMapTravelJob(job)
  if not job or not job.targetLevel then return end
  local targetLevel = job.targetLevel
  local mapInfoPath = job.mapInfoPath
  local misFilePath = job.misFilePath

  execMainUiJs("try{if(window.__NativeRallyMP)window.__NativeRallyMP.closeAll();}catch(e){}")
  pcall(saveOwnPlayerVehicleConfig)
  installMpCrossMapSessionGuard()

  if getCurrentLevelName() == targetLevel then
    STATE.switchingMapFromServer = false
    STATE.switchingTargetLevel = ""
    sendServerEvent("NativeRally_ClientLevelReady", { level = targetLevel })
    return
  end

  log("I", "nativeRallyBridge", "Coordinated cross-map travel -> " .. tostring(targetLevel) .. " (" .. tostring(mapInfoPath) .. ")")
  STATE.activeMissionId = nil
  STATE.stagedMissionId = nil
  STATE.stagedMissionDir = nil
  STATE.switchingMapFromServer = true
  STATE.switchingTargetLevel = targetLevel
  STATE.switchStartedAtMs = clientNowMs()
  STATE.worldReadyState = 0
  STATE.pendingReadyMinDelay = nil
  STATE.pendingMissionStartJob = nil
  STATE.catalogScanned = false

  stopAnyRunningForegroundMission()

  if spawn then
    spawn.preventPlayerSpawning = true
  end

  extensions.load("freeroam_freeroam")
  if freeroam_freeroam and type(freeroam_freeroam.startFreeroam) == "function" then
    freeroam_freeroam.startFreeroam(mapInfoPath)
  elseif freeroam_freeroam and type(freeroam_freeroam.startFreeroamByName) == "function" then
    freeroam_freeroam.startFreeroamByName(targetLevel)
  elseif core_levels and type(core_levels.startLevel) == "function" then
    core_levels.startLevel(misFilePath or ("/levels/" .. targetLevel .. "/main.level.json"))
  end
end

local function scheduleMapTravelTo(targetLevel, mapInfoPath, misFilePath)
  targetLevel = tostring(targetLevel or ""):lower()
  if targetLevel == "" then return end

  if STATE.switchingMapFromServer and STATE.switchingTargetLevel == targetLevel and (clientNowMs() - STATE.switchStartedAtMs) < 45000 then
    log("W", "nativeRallyBridge", "Ignoring duplicate map switch request while already transitioning to '" .. targetLevel .. "'.")
    return
  end
  if STATE.pendingMapSwitchJob and STATE.pendingMapSwitchJob.targetLevel == targetLevel then
    return
  end

  installMpCrossMapSessionGuard()
  STATE.switchingMapFromServer = true
  STATE.switchingTargetLevel = targetLevel
  STATE.switchStartedAtMs = clientNowMs()
  STATE.pendingMapSwitchJob = {
    delay = 0.06,
    targetLevel = targetLevel,
    mapInfoPath = mapInfoPath or ("/levels/" .. targetLevel .. "/info.json"),
    misFilePath = misFilePath or ("/levels/" .. targetLevel .. "/main.level.json")
  }
end

local function onSwitchMap(rawJson)
  if isDuplicatePacket("SwitchMap", rawJson, 4000) then return end
  local cmd = jsonDecode(rawJson) or {}
  local targetLevel = tostring(cmd.levelName or ""):lower()
  if targetLevel == "" then return end
  if cmd.vehicleMode then STATE.vehicleMode = tostring(cmd.vehicleMode) end
  if cmd.pendingMissionId and cmd.pendingMissionId ~= "" then
    STATE.pendingCoursePlacement = {
      missionId = cmd.pendingMissionId,
      missionDir = cmd.pendingMissionDir,
      missionName = cmd.pendingMissionName,
      missionType = cmd.pendingMissionType,
      vehicleMode = cmd.vehicleMode or STATE.vehicleMode
    }
    log("I", "nativeRallyBridge", "Switching map to '" .. targetLevel .. "' for rally course: " .. tostring(cmd.pendingMissionName or cmd.pendingMissionId))
  else
    STATE.pendingCoursePlacement = nil
  end
  local mapInfoPath = cmd.mapInfoPath or ("/levels/" .. targetLevel .. "/info.json")
  scheduleMapTravelTo(targetLevel, mapInfoPath, cmd.misFilePath)
end

local function onSyncFeature(rawJson)
  if isDuplicatePacket("SyncFeature", rawJson, 300) then return end
  local pkt = jsonDecode(rawJson) or {}
  if pkt.feature == "recce" and CFG.unlockNativeRallyFeatures then
    extensions.load("gameplay_rally")
    if gameplay_rally and gameplay_rally.enableRecceApp then
      pcall(gameplay_rally.enableRecceApp, pkt.enabled == true)
    end
  end
end


-- ============================================================================
-- FREEROAM RALLY COURSE PREFABS & START LINE SPAWN LOGIC (ON FOOT / RALLY CAR)
-- ============================================================================
RALLY_PRESET_CONFIGS = {
  { model = "sunburst2", config = "vehicles/sunburst2/rally_pro_gravel.pc", name = "Hirochi Sunburst2 Rally Pro Gravel" },
  { model = "bx", config = "vehicles/bx/240bx_coupe_rally_gravel.pc", name = "Ibishu 240BX Rally Gravel" },
  { model = "bx", config = "vehicles/bx/diana_rally_gravel.pc", name = "Ibishu Diana Rally Gravel" },
  { model = "vivace", config = "vehicles/vivace/rally.pc", name = "Cherrier Vivace Rally" },
  { model = "covet", config = "vehicles/covet/rally_gravel.pc", name = "Ibishu Covet Rally Gravel" },
  { model = "etki", config = "vehicles/etki/rally.pc", name = "ETK I-Series Rally" },
  { model = "pessima", config = "vehicles/pessima/rally.pc", name = "Ibishu Pessima Rally" },
  { model = "sunburst", config = "vehicles/sunburst/rally.pc", name = "Hirochi Sunburst Rally" }
}


-- Returns only rally configs that really exist on this PC (BeamNG 0.40 removed/renamed several), plus auto-discovered *rally*.pc files
getValidRallyConfigs = function()
  local valid, seen = {}, {}
  local function addCfg(model, config, name)
    if not model or not config or seen[config] then return end
    local abs = tostring(config)
    if abs:sub(1, 1) ~= "/" then abs = "/" .. abs end
    if FS and type(FS.fileExists) == "function" and FS:fileExists(abs) then
      seen[config] = true
      valid[#valid + 1] = { model = model, config = config, name = name or (model .. " Rally") }
    end
  end
  for _, c in ipairs(RALLY_PRESET_CONFIGS) do addCfg(c.model, c.config, c.name) end
  if #valid == 0 and FS and type(FS.findFiles) == "function" then
    local okF, files = pcall(FS.findFiles, FS, "/vehicles/", "*rally*.pc", -1, true, false)
    if okF and type(files) == "table" then
      for _, f in ipairs(files) do
        local lf = tostring(f):lower()
        local model = lf:match("^/?vehicles/([^/]+)/")
        if model and not lf:find("parked", 1, true) and not lf:find("traffic", 1, true)
           and not lf:find("police", 1, true) and not lf:find("ai_", 1, true) then
          addCfg(model, (tostring(f):gsub("^/", "")), model .. " Rally")
        end
      end
    end
  end
  return valid
end

-- Finds real ground height under the start position so nothing spawns floating above (or buried in) the road
getGroundZ = function(x, y, refZ)
  if be and be.getSurfaceHeightBelow and vec3 then
    local ok, h = pcall(function() return be:getSurfaceHeightBelow(vec3(x, y, refZ + 3.0)) end)
    if ok and type(h) == "number" and h > -1e5 and math.abs(h - refZ) < 8.0 then
      return h
    end
  end
  return refZ
end

clearPlacedCoursePrefabs = function()
  if type(STATE.placedCoursePrefabs) ~= "table" then return end
  for _, p in ipairs(STATE.placedCoursePrefabs) do
    if p then
      if p.unload then pcall(function() p:unload() end) end
      if p.deleteObject then pcall(function() p:deleteObject() end) end
    end
  end
  STATE.placedCoursePrefabs = {}
  if be and be.reloadCollision then pcall(function() be:reloadCollision() end) end
end

spawnSingleCoursePrefab = function(prefabPath)
  if not prefabPath or prefabPath == "" then return end
  local cleanPath = tostring(prefabPath)
  if cleanPath:find("^/") == nil and cleanPath:find("^%a:") == nil and STATE.stagedMissionDir then
    cleanPath = STATE.stagedMissionDir .. "/" .. cleanPath
  end
  if FS and type(FS.fileExists) == "function" and not FS:fileExists(cleanPath) then
    if STATE.stagedMissionId then
      local altPath = "/gameplay/missions/" .. tostring(STATE.stagedMissionId) .. "/" .. tostring(prefabPath)
      if FS:fileExists(altPath) then cleanPath = altPath end
    end
  end
  local pName = "nrmp_freeroam_course_prefab_" .. tostring(#STATE.placedCoursePrefabs + 1)
  local spawned = nil
  if spawnPrefab then
    local okSp, pObj = pcall(spawnPrefab, pName, cleanPath, "0 0 0", "1 0 0 0", "1 1 1")
    if okSp and pObj then spawned = pObj end
  end
  if not spawned and createObject and scenetree and scenetree.MissionGroup then
    local okCr, pObj2 = pcall(function()
      local p = Sim.upcast(createObject("Prefab"))
      if p then
        p:setField("filename", 0, cleanPath)
        p:setPosition(Point3F(0, 0, 0))
        p:registerObject(pName)
        scenetree.MissionGroup:addObject(p.obj)
        p:load()
        return p
      end
      return nil
    end)
    if okCr and pObj2 then spawned = pObj2 end
  end
  if spawned then
    STATE.placedCoursePrefabs[#STATE.placedCoursePrefabs + 1] = spawned
    log("I", "nativeRallyBridge", "Spawned freeroam rally course prefab: " .. tostring(cleanPath))
  end
end

teleportVehicleSafely = function(veh, pos, rot)
  if not veh then return end
  if spawn and type(spawn.safeTeleport) == "function" and vec3 and quat then
    local targetVec = vec3(pos[1], pos[2], pos[3])
    local targetQuat = quat(rot[1], rot[2], rot[3], rot[4])
    local okSt = pcall(spawn.safeTeleport, veh, targetVec, targetQuat)
    if not okSt then
      veh:setPositionRotation(pos[1], pos[2], pos[3], rot[1], rot[2], rot[3], rot[4])
    end
  else
    veh:setPositionRotation(pos[1], pos[2], pos[3], rot[1], rot[2], rot[3], rot[4])
  end
  veh:queueLuaCommand("if recovery and type(recovery.stop) == 'function' then recovery.stop() end")
  if veh.applyClusterVelocityScaleAdd and veh.getRefNodeId then
    pcall(function() veh:applyClusterVelocityScaleAdd(veh:getRefNodeId(), 0, 0, 0, 0) end)
  end
end

computeStagingTransform = function(rawPos, rawRot, slotNum, mode)
  local bx = tonumber(rawPos[1] or rawPos.x) or 0
  local by = tonumber(rawPos[2] or rawPos.y) or 0
  local bz = tonumber(rawPos[3] or rawPos.z) or 0
  local rot = rawRot or {0, 0, 0, 1}
  local rx = tonumber(rot[1] or rot.x) or 0
  local ry = tonumber(rot[2] or rot.y) or 0
  local rz = tonumber(rot[3] or rot.z) or 0
  local rw = tonumber(rot[4] or rot.w) or 1

  -- Calculate forward (+Y) and lateral right (+X) vectors with BeamNG quat or fallback
  local fx, fy, fz
  local rx_vec, ry_vec, rz_vec
  if quat and vec3 then
    local okQ, qObj = pcall(quat, rx, ry, rz, rw)
    if okQ and qObj then
      local fVec = qObj * vec3(0, 1, 0)
      local rVec = qObj * vec3(1, 0, 0)
      fx, fy, fz = fVec.x, fVec.y, fVec.z
      rx_vec, ry_vec, rz_vec = rVec.x, rVec.y, rVec.z
    end
  end
  if not fx then
    -- Mathematical rotation matrix column 1 for (0, 1, 0)
    fx = 2 * (rx * ry - rw * rz)
    fy = 1 - 2 * (rx * rx + rz * rz)
    fz = 2 * (ry * rz + rw * rx)
    -- Column 0 for (1, 0, 0)
    rx_vec = 1 - 2 * (ry * ry + rz * rz)
    ry_vec = 2 * (rx * ry + rw * rz)
    rz_vec = 2 * (rx * rz - rw * ry)
  end

  local px, py, pz = bx, by, bz

  if mode == "on_foot" then
    -- On foot: spawn on the shoulder beside the stage start box (near marshal tent/bench)
    -- Setback 2.2m before line, lateral offset 2.5m to the left (-right)
    px = bx - 2.2 * fx - 2.5 * rx_vec
    py = by - 2.2 * fy - 2.5 * ry_vec
    pz = getGroundZ(px, py, bz - 2.2 * fz) + 0.1
  else
    -- Vehicles:
    -- Slot 1 (Car 1): Set back 2.8 meters so the front bumper rests right at the orange start line,
    -- perfectly staged between the timing sensors without prematurely breaking the beam.
    -- Slot 2 (Car 2): Staged 7.2 meters directly behind Slot 1 (10.0m total from start line) in single file.
    local setback = (tonumber(slotNum) == 2) and 10.0 or 2.8
    px = bx - setback * fx
    py = by - setback * fy
    pz = getGroundZ(px, py, bz - setback * fz) + 0.15
  end

  return { px, py, pz }, { rx, ry, rz, rw }
end

spawnRallyVehicleAt = function(cfg, pos, rot)
  local posVec = (vec3 and vec3(pos[1], pos[2], pos[3])) or nil
  local rotQuat = (quat and quat(rot[1], rot[2], rot[3], rot[4])) or nil

  -- 1. Try replacing existing player car first
  local curVeh = be:getPlayerVehicle(0)
  if curVeh and core_vehicles and core_vehicles.replaceVehicle then
    local okRep, resRep = pcall(core_vehicles.replaceVehicle, cfg.model, {
      config = cfg.config,
      pos = posVec,
      rot = rotQuat
    })
    if okRep and resRep then return resRep end
  end

  -- 2. Try spawnNewVehicle
  if core_vehicles and core_vehicles.spawnNewVehicle then
    local okSp, resSp = pcall(core_vehicles.spawnNewVehicle, cfg.model, {
      config = cfg.config,
      pos = posVec,
      rot = rotQuat,
      autoEnterVehicle = true
    })
    if okSp and resSp then return resSp end
  end

  -- 3. Try global spawn.spawnVehicle
  if spawn and spawn.spawnVehicle then
    local okSp2, resSp2 = pcall(spawn.spawnVehicle, cfg.model, cfg.config, posVec, rotQuat)
    if okSp2 and resSp2 then return resSp2 end
  end

  -- 4. Fallback: teleport whatever car exists to start line
  if curVeh then
    teleportVehicleSafely(curVeh, pos, rot)
    return curVeh
  end
  return nil
end

spawnOnFootAt = function(pos, rot)
  local posVec = (vec3 and vec3(pos[1], pos[2], pos[3])) or nil
  local rotQuat = (quat and quat(rot[1], rot[2], rot[3], rot[4])) or nil

  -- 1. Switch to native walking mode if available
  local isWalking = false
  if gameplay_walk and gameplay_walk.isWalking then
    local okW, w = pcall(gameplay_walk.isWalking)
    if okW then isWalking = w end
  end

  if not isWalking and gameplay_walk and gameplay_walk.setWalkingMode then
    pcall(gameplay_walk.setWalkingMode, true)
    STATE._nrmpWalkTries = (STATE._nrmpWalkTries or 0) + 1
    local nowVeh = be:getPlayerVehicle(0)
    if not isUnicycleVeh(nowVeh) and STATE._nrmpWalkTries < 6 then
      return nil -- give BeamNG a few ticks to create the walking avatar, then teleport it
    end
  end
  STATE._nrmpWalkTries = nil

  -- 2. Teleport walking character (unicycle) to start line (never teleport a car "on foot")
  local curVeh = be:getPlayerVehicle(0)
  if curVeh and isUnicycleVeh(curVeh) then
    teleportVehicleSafely(curVeh, pos, rot)
    return curVeh
  end

  -- 3. Directly spawn unicycle if not yet present
  if core_vehicles and core_vehicles.spawnNewVehicle then
    local okUn, resUn = pcall(core_vehicles.spawnNewVehicle, "unicycle", {
      pos = posVec,
      rot = rotQuat,
      autoEnterVehicle = true
    })
    if okUn and resUn then return resUn end
  end

  if spawn and spawn.spawnVehicle then
    local okUn2, resUn2 = pcall(spawn.spawnVehicle, "unicycle", nil, posVec, rotQuat)
    if okUn2 and resUn2 then return resUn2 end
  end

  return nil
end

processStartLinePlacement = function(dtReal)
  if not STATE.pendingStartLinePlacement then return end
  local job = STATE.pendingStartLinePlacement
  job.timer = (job.timer or 0) - (tonumber(dtReal) or 0.016)
  if job.timer > 0 then return end

  job.attempts = (job.attempts or 0) + 1
  local mode = job.mode or STATE.freeroamSpawnMode or "random_rally"
  local pos = job.pos
  local rot = job.rot

  if mode == "on_foot" then
    local res = spawnOnFootAt(pos, rot)
    if res or job.attempts >= 25 then
      STATE.pendingStartLinePlacement = nil
      log("I", "nativeRallyBridge", "Spawned player on foot at rally start line: " .. tostring(pos[1]) .. ", " .. tostring(pos[2]) .. ", " .. tostring(pos[3]))
      if ui_message then ui_message("Spawned on foot at Rally Start Line!", 4, "nativeRally") end
    else
      job.timer = 0.25
    end
  elseif mode == "random_rally" then
    if not job.spawnInitiated then
      math.randomseed(os.time() + (tonumber(STATE.slot) or 1) * 31)
      local pool = getValidRallyConfigs()
      if #pool == 0 then
        log("W", "nativeRallyBridge", "No installed rally car configs found - spawning on foot at start line instead")
        job.mode = "on_foot"
        job.attempts = 0
        job.timer = 0
        return
      end
      local cfg = pool[math.random(1, #pool)]
      job.chosenCfg = cfg
      job.spawnInitiated = true
      spawnRallyVehicleAt(cfg, pos, rot)
      job.timer = 0.8
    else
      local veh = be:getPlayerVehicle(0)
      if veh then
        teleportVehicleSafely(veh, pos, rot)
        local cName = (job.chosenCfg and (job.chosenCfg.name or job.chosenCfg.model)) or "Rally Car"
        log("I", "nativeRallyBridge", "Spawned " .. cName .. " at rally start line: " .. tostring(pos[1]) .. ", " .. tostring(pos[2]) .. ", " .. tostring(pos[3]))
        if ui_message then ui_message("Spawned at Rally Start Line in " .. cName .. "!", 5, "nativeRally") end
        STATE.pendingStartLinePlacement = nil
      elseif job.attempts >= 30 then
        STATE.pendingStartLinePlacement = nil
      else
        job.timer = 0.25
      end
    end
  else -- "current_car"
    local veh = be:getPlayerVehicle(0)
    if veh then
      teleportVehicleSafely(veh, pos, rot)
      log("I", "nativeRallyBridge", "Teleported player car to rally start line: " .. tostring(pos[1]) .. ", " .. tostring(pos[2]) .. ", " .. tostring(pos[3]))
      if ui_message then ui_message("Teleported car to Rally Start Line!", 4, "nativeRally") end
      STATE.pendingStartLinePlacement = nil
    elseif job.attempts >= 30 then
      STATE.pendingStartLinePlacement = nil
    else
      job.timer = 0.25
    end
  end
end

-- Finds the race file for a mission. Rally LOOPS (NGRC) have no race.race.json at their root, so look inside the folder
-- and then inside the stages the loop refers to. Returns raceData, folderUsed
local function resolveRaceDataForMission(missionDir)
  if not jsonReadFile or not missionDir or missionDir == "" then return nil, nil end
  local function tryRead(path)
    local okR, tbl = pcall(jsonReadFile, path)
    if okR and type(tbl) == "table" then return tbl end
    return nil
  end
  local direct = tryRead(missionDir .. "/race.race.json")
  if direct then return direct, missionDir end

  if FS and type(FS.findFiles) == "function" then
    local okF, files = pcall(FS.findFiles, FS, missionDir, "*.race.json", -1, true, false)
    if okF and type(files) == "table" and #files > 0 then
      table.sort(files)
      local t = tryRead(files[1])
      if t then return t, (files[1]:match("^(.*)/[^/]+$") or missionDir) end
    end
  end

  -- Loop mission: follow the stages it references (info.json variables like stage1_rallyStage = "italy/rallyStage/ngrc25-riviera-fastello")
  local stageIds, seenIds, preferred = {}, {}, {}
  local function addStageIds(raw)
    for ref in tostring(raw or ""):gmatch("([%w_%-]+/rallyStage/[%w_%-]+)") do
      if not seenIds[ref] then seenIds[ref] = true; stageIds[#stageIds + 1] = ref end
    end
  end
  if FS and type(FS.findFiles) == "function" and jsonEncode then
    local okJ, jfiles = pcall(FS.findFiles, FS, missionDir, "*.json", -1, true, false)
    if okJ and type(jfiles) == "table" then
      table.sort(jfiles)
      for _, jf in ipairs(jfiles) do
        local lower = tostring(jf):lower()
        if not (lower:find("%.race%.json") or lower:find("%.notebook%.json") or lower:find("%.prefab")) then
          local t = tryRead(jf)
          if t then
            local okE, raw = pcall(jsonEncode, t)
            if okE then addStageIds(raw) end
          end
        end
      end
    end
  end
  -- Also use the scanned mission catalog: stages of the same level whose name starts with the loop's tag (e.g. "ngrc25-...")
  local loopId = tostring(missionDir):match("/gameplay/missions/(.+)$") or ""
  local lvl = loopId:match("^([^/]+)/") or ""
  local tag = (loopId:match("([^/]+)$") or ""):match("^[^%-]+") or ""
  if tag ~= "" and type(STATE.globalMissions) == "table" then
    local cat = {}
    for _, m in ipairs(STATE.globalMissions) do
      local id = tostring(m.id or "")
      if id:find("^" .. lvl .. "/rallyStage/") and id:find(tag, 1, true) then cat[#cat + 1] = m end
    end
    -- put "SS1" first so the loop starts on its first stage
    table.sort(cat, function(x, y)
      local xs = tostring(x.name or ""):find("SS1", 1, true) and 0 or 1
      local ys = tostring(y.name or ""):find("SS1", 1, true) and 0 or 1
      if xs ~= ys then return xs < ys end
      return tostring(x.id) < tostring(y.id)
    end)
    for _, m in ipairs(cat) do preferred[#preferred + 1] = tostring(m.id) end
  end
  for _, ref in ipairs(stageIds) do preferred[#preferred + 1] = ref end
  for _, ref in ipairs(preferred) do
    local stageDir = "/gameplay/missions/" .. ref
    local t = tryRead(stageDir .. "/race.race.json")
    if t then return t, stageDir end
  end
  return nil, nil
end

placeRallyCourseInFreeroam = function(missionId, missionDir)
  if not missionId or missionId == "" then return end
  clearPlacedCoursePrefabs()
  STATE.placedCoursePrefabs = {}
  -- Never reuse the previous stage's start line (this is what dropped cars at Backroads coordinates on other maps)
  STATE.stagedStartPos = nil
  STATE.pendingStartLinePlacement = nil
  STATE.stagedMissionId = missionId
  STATE.stagedMissionDir = missionDir or ("/gameplay/missions/" .. tostring(missionId))

  -- 1. Load Roadbook & Pacenotes
  loadOrBuildTrackRoadbook(missionId, STATE.stagedMissionDir)
  -- 2. Inspect the race file for course prefabs and start line positions (loops: first referenced stage)
  local raceData, raceDirUsed = resolveRaceDataForMission(STATE.stagedMissionDir)
  if raceDirUsed and raceDirUsed ~= STATE.stagedMissionDir then
    log("I", "nativeRallyBridge", "Loop mission has no race file at its root; using stage folder: " .. tostring(raceDirUsed))
  end
  if gameplay_rally and gameplay_rally.loadMission then
    pcall(gameplay_rally.loadMission, missionId, raceDirUsed or STATE.stagedMissionDir, nil, nil, { owner = "external" })
  end

  local pData = raceData and (raceData.pathData or raceData.path or raceData.race) or nil
  if pData then
    if type(pData.prefabs) == "table" then
      for _, pf in ipairs(pData.prefabs) do spawnSingleCoursePrefab(pf) end
    end
    if type(pData.forwardPrefabs) == "table" then
      for _, pf in ipairs(pData.forwardPrefabs) do spawnSingleCoursePrefab(pf) end
    end
  end

  -- Scan mission folder for any additional *.prefab.json or *.prefab files
  if FS and type(FS.findFiles) == "function" then
    local okF, foundPrefabs = pcall(FS.findFiles, FS, STATE.stagedMissionDir, "*.prefab*", -1, true, false)
    if okF and type(foundPrefabs) == "table" then
      for _, fPath in ipairs(foundPrefabs) do
        local already = false
        for _, sp in ipairs(STATE.placedCoursePrefabs) do
          if sp and sp.filename == fPath then already = true; break end
        end
        if not already then spawnSingleCoursePrefab(fPath) end
      end
    end
  end

  -- 3. Reload collision physics so all barriers, hay bales, and props are solid
  if be and be.reloadCollision then
    pcall(function() be:reloadCollision() end)
  end

  -- 4. Locate Rally Stage Start Line coordinates
  local startPos = nil
  if pData and type(pData.startPositions) == "table" and #pData.startPositions > 0 then
    local defIdx = tonumber(pData.defaultStartPosition) or 1
    startPos = pData.startPositions[defIdx] or pData.startPositions[1]
  elseif raceData and type(raceData.startPositions) == "table" and #raceData.startPositions > 0 then
    startPos = raceData.startPositions[1]
  elseif type(STATE.roadbookNotes) == "table" and #STATE.roadbookNotes > 0 then
    for _, note in ipairs(STATE.roadbookNotes) do
      if note.pos then
        startPos = { pos = note.pos, rot = note.rot or {0, 0, 0, 1} }
        break
      end
    end
  end

  if startPos and startPos.pos then
    local bx = tonumber(startPos.pos[1] or startPos.pos.x) or 0
    local by = tonumber(startPos.pos[2] or startPos.pos.y) or 0
    local bz = tonumber(startPos.pos[3] or startPos.pos.z) or 0
    local rot = startPos.rot or {0, 0, 0, 1}
    local rx = tonumber(rot[1] or rot.x) or 0
    local ry = tonumber(rot[2] or rot.y) or 0
    local rz = tonumber(rot[3] or rot.z) or 0
    local rw = tonumber(rot[4] or rot.w) or 1

    -- Store the RAW base start line coordinates (unmodified by slot)
    STATE.stagedStartPos = {
      pos = { bx, by, bz },
      rot = { rx, ry, rz, rw }
    }

    -- Compute local vehicle staging coordinates based on slot & spawn mode
    local localPos, localRot = computeStagingTransform(STATE.stagedStartPos.pos, STATE.stagedStartPos.rot, STATE.slot, STATE.freeroamSpawnMode or "random_rally")

    -- Setup deferred start-line placement job
    STATE.pendingStartLinePlacement = {
      pos = localPos,
      rot = localRot,
      mode = STATE.freeroamSpawnMode or "random_rally",
      timer = 0.25,
      attempts = 0,
      spawnInitiated = false
    }

    -- If a vehicle is already active and user chose current car, teleport immediately
    local currentVeh = be:getPlayerVehicle(0)
    if currentVeh and STATE.freeroamSpawnMode == "current_car" then
      teleportVehicleSafely(currentVeh, localPos, localRot)
      STATE.pendingStartLinePlacement = nil
    end
  end

  if not STATE.stagedStartPos then
    log("W", "nativeRallyBridge", "No start line found for '" .. tostring(missionId) .. "' - leaving cars where they are")
  end
  emitVueBridgeState()
  log("I", "nativeRallyBridge", "Rally course '" .. tostring(missionId) .. "' loaded in Freeroam with solid collision & start positions staged!")
end

local function executeMissionLaunchJob(job)
  if not job or not job.cmd then return end
  local cmd = job.cmd
  local reqLvl = job.reqLvl or ""

  extensions.load("gameplay_missions_missions")
  extensions.load("gameplay_missions_missionManager")
  extensions.load("gameplay_rally")
  extensions.load("gameplay_rallyLoop")
  installMpVehicleGeHooks()
  hookMissionManager()
  hookNativeGameplayRally()
  hookNativeGameplayRallyLoop()
  installTrafficDeleteShield()

  local mission = resolveNativeMissionObject(cmd.missionId, cmd.missionName, cmd.missionType, reqLvl)

  -- If another foreground mission is currently ongoing, cleanly stop it first and re-queue launch
  local fgRunningId = (gameplay_missions_missionManager and gameplay_missions_missionManager.getForegroundMissionId)
    and gameplay_missions_missionManager.getForegroundMissionId() or nil
  if (fgRunningId ~= nil or (mission and mission._isOngoing)) and (job.stopRetries or 0) < 4 then
    log("I", "nativeRallyBridge", "Stopping ongoing foreground mission (" .. tostring(fgRunningId or (mission and mission.id)) .. ") before launching new Rally event...")
    stopAnyRunningForegroundMission()
    STATE.pendingMissionStartJob = {
      delay = 0.45,
      cmd = cmd,
      reqLvl = reqLvl,
      stopRetries = (job.stopRetries or 0) + 1
    }
    return
  end

  if STATE.role == "CODRIVER" then
    local resolvedId = mission and mission.id or cmd.missionId
    local resolvedDir = (mission and mission.missionFolder) or cmd.missionDir
    flushMpSpawnQueueNow(true)
    bindSharedCoDriverCrew(STATE.driverServerVehId, resolvedId, resolvedDir)
    enforceCollisionPolicy(true)
    emitVueBridgeState()
    return
  end

  if not mission then
    log("E", "nativeRallyBridge", "Could not resolve native Rally mission object for id=" .. tostring(cmd.missionId) .. " name=" .. tostring(cmd.missionName))
    if ui_message then ui_message("Missing native Rally mission locally: " .. tostring(cmd.missionName or cmd.missionId), 5, "nativeRallyErr") end
    return
  end

  log("I", "nativeRallyBridge", "Launching native BeamNG Rally mission: " .. tostring(mission.id) .. " (type=" .. tostring(mission.missionType) .. ", vehMode=" .. tostring(STATE.vehicleMode) .. ", collision=" .. tostring(CFG.collisionPolicy) .. ")")
  clearPlacedCoursePrefabs()
  STATE.activeMissionId = mission.id
  STATE.sawForegroundMission = false
  STATE.stageEndReported = false
  local settingsTbl = buildMultiplayerUserSettings(mission, cmd.userSettings, {
    vehicleMode = STATE.vehicleMode,
    freeroamSpawnMode = STATE.freeroamSpawnMode or "random_rally",
    hasStagedStartPos = (STATE.stagedStartPos ~= nil),
    enableFalseStarts = cmd.enableFalseStarts,
    repairOnRecovery = cmd.repairOnRecovery
  })

  enforceCollisionPolicy(true)

  STATE.launchingFromServer = true
  STATE.launchingFromServerTimer = 5.0
  STATE.pendingExplicitQueueFlushes = 4

  local startedOk = false
  if gameplay_missions_missionManager then
    if type(gameplay_missions_missionManager.startWithFade) == "function" then
      local okS, errS = pcall(gameplay_missions_missionManager.startWithFade, mission, settingsTbl)
      if okS then
        startedOk = true
      else
        log("E", "nativeRallyBridge", "startWithFade error: " .. tostring(errS))
      end
    end
    if not startedOk and type(gameplay_missions_missionManager.start) == "function" then
      local okS2, errS2 = pcall(gameplay_missions_missionManager.start, mission, settingsTbl)
      if okS2 then
        startedOk = true
      else
        log("E", "nativeRallyBridge", "missionManager.start error: " .. tostring(errS2))
      end
    end
    if not startedOk and type(gameplay_missions_missionManager.startAsScenario) == "function" then
      local okS3, errS3 = pcall(gameplay_missions_missionManager.startAsScenario, mission, settingsTbl)
      if okS3 then
        startedOk = true
      else
        log("E", "nativeRallyBridge", "missionManager.startAsScenario error: " .. tostring(errS3))
      end
    end
  end

  STATE.launchingFromServer = false
  silenceAiVoicepackAndEnforceHud()
  restoreAllRemoteMpVehicles()
  checkAndApplySpawnSeparation()
  enforceCollisionPolicy(false)
  reconcileSingleActivePlayerVehicle()
  flushMpSpawnQueueNow(true)
  emitVueBridgeState()
end

local function onExecuteLaunch(rawJson)
  if isDuplicatePacket("ExecuteLaunch", rawJson, 2500) then return end
  local cmd = jsonDecode(rawJson) or {}
  if not cmd.missionId then return end

  execMainUiJs("try{if(window.__NativeRallyMP)window.__NativeRallyMP.closeAll();}catch(e){}")

  local reqLvl = tostring(cmd.missionId):match("^([^/]+)") or ""
  reqLvl = reqLvl:lower()
  local curLvl = getCurrentLevelName()
  if reqLvl ~= "" and curLvl ~= "" and reqLvl ~= curLvl and CFG.enableDynamicCrossMapSync then
    log("I", "nativeRallyBridge", "Mission '" .. tostring(cmd.missionId) .. "' requires map '" .. reqLvl .. "' (currently on '" .. curLvl .. "'); switching map first.")
    STATE.queuedLaunchAfterSwitch = rawJson
    scheduleMapTravelTo(reqLvl, "/levels/" .. reqLvl .. "/info.json", "/levels/" .. reqLvl .. "/main.level.json")
    return
  end

  STATE.slot = tonumber(cmd.slot) or 1
  STATE.role = tostring(cmd.role or "DRIVER")
  STATE.participationMode = tostring(cmd.participationMode or "two_car")
  STATE.launchMode = tostring(cmd.launchMode or "wrc_staggered")
  STATE.vehicleMode = tostring(cmd.vehicleMode or "own_mp_car")
  STATE.slotOffsetSec = tonumber(cmd.slotOffsetSec) or 0
  STATE.activeMissionId = cmd.missionId
  STATE.sawForegroundMission = false
  STATE.stageEndReported = false
  STATE.activeMissionDir = cmd.missionDir
  STATE.stagedMissionId = nil
  STATE.stagedMissionDir = nil
  STATE.driverServerVehId = tostring(cmd.driverServerVehId or "")
  STATE.appliedSlotOffset = false
  STATE.appliedBayOffset = false
  STATE.appliedStageGridOffset = false
  STATE.forcedMpSendForVehId = nil
  STATE.sentStagedAtSS = false
  STATE.simultaneousReleaseClientMs = nil

  local wasPaused = detectLuaRouterPause(true)
  STATE.luaMenuOpen = false
  if wasPaused then
    if extensions and extensions.ui_router and type(extensions.ui_router.navigate) == "function" then
      pcall(extensions.ui_router.navigate, "play")
    end
    if guihooks then guihooks.trigger("MenuHide") end
  end
  pushMenuVisibilityToCef(true)

  STATE.launchingFromServerTimer = 5.0
  STATE.pendingMissionStartJob = {
    delay = wasPaused and 0.30 or 0.12,
    cmd = cmd,
    reqLvl = reqLvl
  }
end

local function onStartLoopClock(rawJson)
  if isDuplicatePacket("StartLoopClock", rawJson, 1000) then return end
  if gameplay_rallyLoop and gameplay_rallyLoop.onUIStartButtonClicked then
    STATE.launchingFromServer = true
    pcall(gameplay_rallyLoop.onUIStartButtonClicked)
    STATE.launchingFromServer = false
  end
  checkAndApplySpawnSeparation()
  checkAndApplyWrcSlotScheduleOffset()
  enforceCollisionPolicy(false)
  flushMpSpawnQueueNow(true)
end

local function onCommitClockSkip(rawJson)
  if isDuplicatePacket("CommitClockSkip", rawJson, 600) then return end
  local data = jsonDecode(rawJson) or {}
  local targetEpoch = tonumber(data.targetEpoch)
  local lm = gameplay_rallyLoop and gameplay_rallyLoop.getManager and gameplay_rallyLoop.getManager()
  if lm and targetEpoch and targetEpoch > lm:getEpochTime() then
    local oldClock = lm.clock
    lm.clock = targetEpoch
    if guihooks then
      guihooks.trigger("RallyClockSkipped", {
        oldTime = oldClock,
        newTime = targetEpoch,
        skippedSeconds = targetEpoch - oldClock
      })
    end
  end
end

local function onReleaseSimultaneousCountdown(rawJson)
  if isDuplicatePacket("ReleaseCountdown", rawJson, 600) then return end
  local pkt = jsonDecode(rawJson) or {}
  local waitMs = math.max(0, (tonumber(pkt.releaseServerMs) or 0) - (tonumber(pkt.serverNowMs) or 0) - (STATE.rttMs * 0.5))
  STATE.simultaneousReleaseClientMs = clientNowMs() + waitMs
end

local function onPeerSplitBroadcast(rawJson)
  STATE.lastSplitBroadcast = jsonDecode(rawJson)
  emitVueBridgeState()
end

local function onPeerStandings(rawJson)
  local data = jsonDecode(rawJson) or {}
  if type(data.competitors) == "table" then
    STATE.peerStandings = data.competitors
    injectPeerIntoNativeEndScreen()
    emitVueBridgeState()
  end
end

local function onFlushSpawnQueue(_rawJson)
  STATE.pendingExplicitQueueFlushes = 3
  flushMpSpawnQueueNow(true)
end

local function onDespawnCoDriverCarsClient(_rawJson)
  despawnOwnExtraVehicleForCoDriver()
end

local function onTrackNotesData(rawJson)
  local data = jsonDecode(rawJson) or {}
  local tKey = tostring(data.trackKey or STATE.currentTrackKey or STATE.activeMissionId or STATE.stagedMissionId or "")
  if tKey == "" then return end
  if data.resetDefault == true then
    if FS and FS.removeFile then
      pcall(function() FS:removeFile(getClientTrackNotesPath(tKey)) end)
    end
    local nativeNotes = tryReadLiveNotebook(tKey) or tryParseNativeMissionNotebook(STATE.activeMissionDir or STATE.stagedMissionDir, tKey)
    STATE.roadbookNotes = nativeNotes or buildStructuredFallbackNotesForTrack(tKey)
    STATE.roadbookCustomSaved = false
    emitVueBridgeState()
    return
  end
  if type(data.notes) == "table" and #data.notes > 0 then
    STATE.currentTrackKey = tKey
    local nativeNotes = tryReadLiveNotebook(tKey) or tryParseNativeMissionNotebook(STATE.activeMissionDir or STATE.stagedMissionDir, tKey)
    STATE.roadbookNotes = mergeSavedRoadbookNotes(data.notes, nativeNotes)
    STATE.roadbookCustomSaved = true
    if jsonWriteFile then
      pcall(jsonWriteFile, getClientTrackNotesPath(tKey), {
        trackKey = tKey,
        notes = data.notes
      }, true)
    end
    emitVueBridgeState()
  end
end



local function onSpawnStartLine(rawJson)
  local pkt = jsonDecode(rawJson) or {}
  M.vueSpawnAtStartLine(pkt.mode)
end

local function onPreloadStagedNotes(rawJson)
  local pkt = jsonDecode(rawJson) or {}
  local mid = tostring(pkt.missionId or "")
  if mid == "" then return end
  local mdir = tostring(pkt.missionDir or ("/gameplay/missions/" .. mid))
  STATE.stagedMissionId = mid
  STATE.stagedMissionDir = mdir
  STATE.stageStartOriginPos = nil
  STATE.liveOdometerM = 0
  if type(pkt.savedNotes) == "table" and #pkt.savedNotes > 0 then
    STATE.currentTrackKey = tostring(pkt.trackKey or mid)
    local nativeNotes = tryParseNativeMissionNotebook(mdir, STATE.currentTrackKey) or tryReadLiveNotebook(STATE.currentTrackKey)
    STATE.roadbookNotes = mergeSavedRoadbookNotes(pkt.savedNotes, nativeNotes)
    STATE.roadbookCustomSaved = true
  else
    loadOrBuildTrackRoadbook(mid, mdir)
  end
  placeRallyCourseInFreeroam(mid, mdir)
  emitVueBridgeState()
end

local function onClearStagedNotes(_rawJson)
  clearPlacedCoursePrefabs()
  STATE.stagedMissionId = nil
  STATE.stagedMissionDir = nil
  STATE.stageStartOriginPos = nil
  STATE.liveOdometerM = 0
  emitVueBridgeState()
end

-- Native mission stopped on THIS client (finish screen closed / abandoned): tell the server and
-- go back to the pre-stage instead of being left in plain freeroam with stale rally state.
local function reportStageEnded()
  local mid = STATE.activeMissionId
  if not mid then return end
  STATE.activeMissionId = nil          -- stops the 0.2s in-stage shield loop
  STATE.pendingMissionStartJob = nil
  STATE.appliedBayOffset = false
  STATE.appliedStageGridOffset = false
  STATE.sentStagedAtSS = false
  STATE.simultaneousReleaseClientMs = nil
  STATE.stageStartOriginPos = nil
  STATE.liveOdometerM = 0
  releaseCoDriverPassengerLock(true)
  local veh = getOwnVehicle()
  if veh then setVehFreeze(veh, false) end
  if be and be.setDynamicCollisionEnabled then be:setDynamicCollisionEnabled(true) end
  if getOwnVehicle() == nil then ensureSavedPlayerVehicleRestored() end
  reconcileSingleActivePlayerVehicle()
  flushMpSpawnQueueNow(true)
  log("I", "nativeRallyBridge", "Native mission '" .. tostring(mid) .. "' ended locally -> reporting NativeRally_StageEnded")
  sendServerEvent("NativeRally_StageEnded", { missionId = mid, level = getCurrentLevelName() })
  emitVueBridgeState()
end

local function onReturnToPreStage(rawJson)
  if isDuplicatePacket("ReturnToPreStage", rawJson, 1500) then return end
  -- Put the driver's own car back on the start line and re-place the course (same path as arriving on a map)
  STATE.freeroamSpawnMode = "current_car"
  STATE.activeMissionId = nil
  STATE.sawForegroundMission = false
  STATE.stageEndReported = false
  onPreloadStagedNotes(rawJson)
end

local function onPlayManualCallout(rawJson)
  if not CFG.codriverClickToCallVoice then return end
  if isDuplicatePacket("PlayManualCallout", rawJson, 220) then return end
  local pkt = jsonDecode(rawJson)
  if type(pkt) ~= "table" or not pkt.callText then return end

  local nativeKey = (type(pkt.nativeText) == "string" and pkt.nativeText ~= "") and pkt.nativeText or tostring(pkt.callText)
  local forceTts = pkt.speakText == true
  local nativeOk = not forceTts and nativeSpeakPacenote(nativeKey, pkt.noteId) or false
  if not nativeOk and not forceTts and Engine and Engine.Audio and Engine.Audio.playOnce then
    pcall(Engine.Audio.playOnce, "AudioGui", "event:>UI>Generic>Select")
  end
  pkt.nativeVoice = nativeOk
  pkt.forceTts = forceTts
  pkt.speaker = pkt.speaker or "CO-DRIVER"
  local outJson = (jsonEncode and jsonEncode(pkt)) or rawJson
  execMainUiJs("try{if(window.__NativeRallyMP&&window.__NativeRallyMP.playManualCallout)window.__NativeRallyMP.playManualCallout(" .. outJson .. ");}catch(e){}")
end

local function onStopMission(rawJson)
  if isDuplicatePacket("StopMission", rawJson, 600) then return end
  STATE.activeMissionId = nil
  STATE.stagedMissionId = nil
  STATE.stagedMissionDir = nil
  STATE.pendingMissionStartJob = nil
  STATE.appliedBayOffset = false
  STATE.appliedStageGridOffset = false
  STATE.stageStartOriginPos = nil
  STATE.liveOdometerM = 0
  releaseCoDriverPassengerLock(true)
  silenceAiVoicepackAndEnforceHud()
  local veh = getOwnVehicle()
  if veh then setVehFreeze(veh, false) end
  if be and be.setDynamicCollisionEnabled then be:setDynamicCollisionEnabled(true) end
  stopAnyRunningForegroundMission()
  if getOwnVehicle() == nil then
    ensureSavedPlayerVehicleRestored()
  end
  reconcileSingleActivePlayerVehicle()
  flushMpSpawnQueueNow(true)
  emitVueBridgeState()
end

local function registerBeamMpEvents()
  if not AddEventHandler then return end
  -- CRITICAL: BeamMP's MPGameNetwork.lua has an off-by-one bug when patching a single handler
  -- ('if max > 1 then calls[max] = nil end'), which duplicates callbacks to 2x if AddEventHandler
  -- is called more than once on the same AddEventHandler function instance!
  if STATE.boundAddEventHandlerFn == AddEventHandler then return end
  STATE.boundAddEventHandlerFn = AddEventHandler

  AddEventHandler("NativeRally_ClockAck", onClockAck, "nativeRallyBridge")
  AddEventHandler("NativeRally_PeerState", onPeerState, "nativeRallyBridge")
  AddEventHandler("NativeRally_OpenMenu", onOpenMenu, "nativeRallyBridge")
  AddEventHandler("NativeRally_SwitchMap", onSwitchMap, "nativeRallyBridge")
  AddEventHandler("NativeRally_SyncFeature", onSyncFeature, "nativeRallyBridge")
  AddEventHandler("NativeRally_ExecuteLaunch", onExecuteLaunch, "nativeRallyBridge")
  AddEventHandler("NativeRally_StartLoopClock", onStartLoopClock, "nativeRallyBridge")
  AddEventHandler("NativeRally_CommitClockSkip", onCommitClockSkip, "nativeRallyBridge")
  AddEventHandler("NativeRally_ReleaseSimultaneousCountdown", onReleaseSimultaneousCountdown, "nativeRallyBridge")
  AddEventHandler("NativeRally_PeerSplitBroadcast", onPeerSplitBroadcast, "nativeRallyBridge")
  AddEventHandler("NativeRally_PeerStandings", onPeerStandings, "nativeRallyBridge")
  AddEventHandler("NativeRally_FlushSpawnQueue", onFlushSpawnQueue, "nativeRallyBridge")
  AddEventHandler("NativeRally_DespawnCoDriverCars", onDespawnCoDriverCarsClient, "nativeRallyBridge")
  AddEventHandler("NativeRally_TrackNotesData", onTrackNotesData, "nativeRallyBridge")
  AddEventHandler("NativeRally_PreloadStagedNotes", onPreloadStagedNotes, "nativeRallyBridge")
  AddEventHandler("NativeRally_ClearStagedNotes", onClearStagedNotes, "nativeRallyBridge")
  AddEventHandler("NativeRally_PlayManualCallout", onPlayManualCallout, "nativeRallyBridge")
  AddEventHandler("NativeRally_StopMission", onStopMission, "nativeRallyBridge")
  AddEventHandler("NativeRally_ReturnToPreStage", onReturnToPreStage, "nativeRallyBridge")
  AddEventHandler("NativeRally_ScanMissions", function(rawJson)
    if isDuplicatePacket("ScanMissions", rawJson, 1500) then return end
    if isLoadedInLevel() then
      scanAllMapsAndRallyMissions()
    else
      seedFallbackCatalog()
      emitVueBridgeState()
    end
  end, "nativeRallyBridge")
end

function M.rebindMpEvents()
  registerBeamMpEvents()
  installMpCrossMapSessionGuard()
  installMpVehicleGeHooks()
  injectLiveCefPauseMenuUi()
  if extensions and type(extensions.hookUpdate) == "function" then
    pcall(extensions.hookUpdate, "onUpdate")
    pcall(extensions.hookUpdate, "onPreRender")
    pcall(extensions.hookUpdate, "onVehicleSpawned")
    pcall(extensions.hookUpdate, "onVehicleSwitched")
    pcall(extensions.hookUpdate, "onWorldReadyState")
    pcall(extensions.hookUpdate, "onClientPostStartMission")
    pcall(extensions.hookUpdate, "onUiChangedState")
  end
end

function M.onVehicleSpawned(vehId)
  installMpVehicleGeHooks()
  if STATE.pendingStartLinePlacement then STATE.pendingStartLinePlacement.timer = 0.05 end
  if CFG.strictSingleVehicleSync and not isRemoteMpVehicle(vehId) and isAuxiliaryOrPropVehicle(vehId) then
    return
  end
  checkAndApplySpawnSeparation()
  enforceCollisionPolicy(false)
  reconcileSingleActivePlayerVehicle()
  flushMpSpawnQueueNow(false)
end

local function checkAutoCrewCockpitEntry()
  local veh = be and be:getPlayerVehicle(0) or nil
  if not veh then
    if STATE.inPartnerCar then
      STATE.inPartnerCar = false
      pcall(releaseCoDriverPassengerLock, false)
      STATE.partnerCarDriverPlayerId = nil
      STATE.participationMode = "two_car"
      STATE.role = "DRIVER"
      sendServerEvent("NativeRally_AutoCrewVehicle", { event = "exit_car" })
      emitVueBridgeState()
    end
    return
  end

  local vid = veh:getID()
  local jbeam = ""
  if veh.getJBeamFilename then
    local okJ, jb = pcall(function() return veh:getJBeamFilename() end)
    if okJ and jb then jbeam = tostring(jb):lower() end
  end

  -- If walking on foot, player is outside any car
  if jbeam == "unicycle" then
    if STATE.inPartnerCar then
      STATE.inPartnerCar = false
      pcall(releaseCoDriverPassengerLock, false)
      STATE.partnerCarDriverPlayerId = nil
      STATE.participationMode = "two_car"
      STATE.role = "DRIVER"
      sendServerEvent("NativeRally_AutoCrewVehicle", { event = "exit_car" })
      if ui_message then ui_message("Exited vehicle on foot — 2-Car mode active", 3, "nativeRally") end
      emitVueBridgeState()
    end
    return
  end

  -- Check if currently occupying a remote player's vehicle
  local isRemote = isRemoteMpVehicle(vid)
  if isRemote then
    local targetOwnerId = nil
    local targetOwnerName = "Partner"
    if MPVehicleGE and type(MPVehicleGE.getVehicles) == "function" then
      local ok, vehs = pcall(MPVehicleGE.getVehicles)
      if ok and type(vehs) == "table" then
        for _, mpv in pairs(vehs) do
          if type(mpv) == "table" and tonumber(mpv.gameVehicleID) == tonumber(vid) then
            targetOwnerId = tonumber(mpv.playerID or mpv.ownerID)
            targetOwnerName = mpv.ownerName or ("Player " .. tostring(targetOwnerId or ""))
            break
          end
        end
      end
    end

    if not STATE.inPartnerCar then
      STATE.inPartnerCar = true
      STATE.partnerCarDriverPlayerId = targetOwnerId
      STATE.role = "CODRIVER"
      STATE.slot = 2
      STATE.participationMode = "codriver"
      sendServerEvent("NativeRally_AutoCrewVehicle", {
        event = "enter_car",
        driverPlayerId = targetOwnerId,
        coDriverPlayerId = (STATE.peerState and STATE.peerState.yourPlayerId) or -1
      })
      if ui_message then ui_message("Entered " .. targetOwnerName .. "'s cockpit — Shared Co-Driver mode activated!", 4, "nativeRally") end
      emitVueBridgeState()
    end
  else
    if STATE.inPartnerCar then
      STATE.inPartnerCar = false
      pcall(releaseCoDriverPassengerLock, false)
      STATE.partnerCarDriverPlayerId = nil
      STATE.participationMode = "two_car"
      STATE.role = "DRIVER"
      sendServerEvent("NativeRally_AutoCrewVehicle", { event = "exit_car" })
      if ui_message then ui_message("Returned to own car — 2-Car mode active", 3, "nativeRally") end
      emitVueBridgeState()
    end
  end
end

function M.onVehicleSwitched(_oldId, _newId, _player)
  installMpVehicleGeHooks()
  checkAutoCrewCockpitEntry()
  checkAndApplySpawnSeparation()
  enforceCollisionPolicy(false)
  reconcileSingleActivePlayerVehicle()
  flushMpSpawnQueueNow(false)
end

function M.onUiChangedState(toState, _fromState)
  local st = tostring(toState or ""):lower()
  if st:find("pause") or (isLoadedInLevel() and st:find("^menu") and not st:find("beammp")) then
    STATE.luaMenuOpen = true
  elseif st == "play" or st == "freeroam" or st == "blank" or st == "" then
    STATE.luaMenuOpen = false
  end
  injectLiveCefPauseMenuUi()
  pushMenuVisibilityToCef(true)
end


local function tickBridge(dtReal)
  dtReal = tonumber(dtReal) or 0.016
  processStartLinePlacement(dtReal)

  -- Caption hook for BeamNG's own pacenote voice (re-checked often: the rally manager is recreated per stage)
  STATE.subHookTimer = (tonumber(STATE.subHookTimer) or 0) - dtReal
  if STATE.subHookTimer <= 0 then
    STATE.subHookTimer = 0.75
    pcall(installNativeSubtitleHook)
  end
  -- The rally manager only exists once the stage is running: pull the real pacenotes in as soon as it appears
  STATE.liveNotesTimer = (tonumber(STATE.liveNotesTimer) or 0) - dtReal
  if STATE.liveNotesTimer <= 0 then
    STATE.liveNotesTimer = 1.5
    if STATE.activeMissionId or STATE.stagedMissionId then
      local okDb, changedDb = pcall(M.disableRallyDebug)
      if okDb and type(changedDb) == "table" and #changedDb > 0 then
        local sigDb = table.concat(changedDb, ", ")
        if sigDb ~= STATE.lastDebugSig then
          STATE.lastDebugSig = sigDb
          log("I", "nativeRallyBridge", "[RallyDebug] turned off: " .. sigDb)
        end
      end
      if STATE.activeMissionId and STATE.probeWrittenFor ~= STATE.activeMissionId then
        local okPr, wrote = pcall(M.writeRallyProbe)
        if okPr and wrote then STATE.probeWrittenFor = STATE.activeMissionId end
      end
    end
    if STATE.activeMissionId and not STATE.roadbookCustomSaved and not STATE.roadbookFromLive then
      local okLn, liveNotes = pcall(M.tryReadLiveNotebook, STATE.currentTrackKey or STATE.activeMissionId)
      if okLn and liveNotes then
        STATE.roadbookNotes = liveNotes
        STATE.roadbookFromLive = true
        emitVueBridgeState()
      end
    end
  end
  if (tonumber(STATE.manualVoiceRestoreTimer) or 0) > 0 then
    STATE.manualVoiceRestoreTimer = STATE.manualVoiceRestoreTimer - dtReal
    if STATE.manualVoiceRestoreTimer <= 0 then
      -- Don't re-mute (which clears the audio queue) while the co-driver is still talking: that cut notes short
      local busy = false
      if (tonumber(STATE.manualVoiceExtendLeft) or 0) > 0 then
        local okB, b = pcall(M.nativeVoiceBusy)
        busy = okB and b == true
      end
      if busy then
        STATE.manualVoiceRestoreTimer = 0.4
        STATE.manualVoiceExtendLeft = STATE.manualVoiceExtendLeft - 0.4
      else
        STATE.manualVoiceRestoreTimer = 0
        STATE.manualVoiceExtendLeft = 0
        STATE.allowManualNativeVoice = false
        pcall(silenceAiVoicepackAndEnforceHud)
      end
    end
  end
  local now = clientNowMs()
  if now - STATE.lastTickClock < 4.0 then return end
  STATE.lastTickClock = now

  if STATE.switchingMapReleaseTimer > 0 then
    STATE.switchingMapReleaseTimer = math.max(0, STATE.switchingMapReleaseTimer - dtReal)
  end

  if STATE.launchingFromServerTimer > 0 then
    STATE.launchingFromServerTimer = math.max(0, STATE.launchingFromServerTimer - dtReal)
  end

  if STATE.spawnGhostGraceTimer > 0 then
    STATE.spawnGhostGraceTimer = math.max(0, STATE.spawnGhostGraceTimer - dtReal)
    if STATE.spawnGhostGraceTimer <= 0 then
      enforceCollisionPolicy(false)
    end
  end

  -- Execute deferred single-shot map switch outside MPGameNetwork socket callback stack
  if STATE.pendingMapSwitchJob then
    STATE.pendingMapSwitchJob.delay = STATE.pendingMapSwitchJob.delay - dtReal
    if STATE.pendingMapSwitchJob.delay <= 0 then
      local mapJob = STATE.pendingMapSwitchJob
      STATE.pendingMapSwitchJob = nil
      executeMapTravelJob(mapJob)
      return
    end
  end

  -- Execute deferred single-shot mission launch outside MPGameNetwork socket callback stack
  if STATE.pendingMissionStartJob and not STATE.switchingMapFromServer and not isUiLoadingScreenActive() then
    STATE.pendingMissionStartJob.delay = STATE.pendingMissionStartJob.delay - dtReal
    if STATE.pendingMissionStartJob.delay <= 0 then
      local launchJob = STATE.pendingMissionStartJob
      STATE.pendingMissionStartJob = nil
      executeMissionLaunchJob(launchJob)
    end
  end

  -- Detect MPGameNetwork launcher TCP handshake completion and flush any queued events
  local mpConn = isMpSocketReady()
  if mpConn and not STATE.wasMpSocketConnected then
    STATE.wasMpSocketConnected = true
    registerBeamMpEvents()
    installMpVehicleGeHooks()
    flushOutboundServerQueue()
    if isLoadedInLevel() and not STATE.switchingMapFromServer and STATE.worldReadyState == 2 then
      local lvl = getCurrentLevelName()
      if lvl ~= "" then
        sendServerEvent("NativeRally_ClientLevelReady", { level = lvl })
      end
      if not STATE.catalogScanned then
        scanAllMapsAndRallyMissions()
      end
    end
  elseif not mpConn then
    STATE.wasMpSocketConnected = false
  elseif #STATE.outboundQueue > 0 then
    flushOutboundServerQueue()
  end

  -- Keep MPVehicleGE prop filter installed and reconcile single active vehicle + instant 3D partner spawn queue flush
  if mpConn and isLoadedInLevel() and not STATE.switchingMapFromServer then
    if not STATE.hookedMpVehicleGe and MPVehicleGE then
      installMpVehicleGeHooks()
    end

    STATE.vehicleSyncTimer = STATE.vehicleSyncTimer + dtReal
    if STATE.vehicleSyncTimer >= 0.35 then
      STATE.vehicleSyncTimer = 0
      reconcileSingleActivePlayerVehicle()
    end

    STATE.queueFlushCooldown = STATE.queueFlushCooldown + dtReal
    if STATE.queueFlushCooldown >= 0.40 then
      STATE.queueFlushCooldown = 0
      if STATE.pendingExplicitQueueFlushes > 0 then
        STATE.pendingExplicitQueueFlushes = STATE.pendingExplicitQueueFlushes - 1
        flushMpSpawnQueueNow(true)
      else
        flushMpSpawnQueueNow(false)
      end
    end

    STATE.collisionEnforceTimer = STATE.collisionEnforceTimer + dtReal
    if STATE.collisionEnforceTimer >= 1.25 then
      STATE.collisionEnforceTimer = 0
      enforceCollisionPolicy(false)
    end
  end

  -- Poll v0.40 ui_router pause state cleanly on state deltas only
  STATE.routerPollTimer = STATE.routerPollTimer + dtReal
  if STATE.routerPollTimer >= 0.2 then
    STATE.routerPollTimer = 0
    pushMenuVisibilityToCef(false)
  end

  -- Lightweight 1-line CEF health check in case UI was reloaded with F5
  STATE.uiKeepAliveTimer = STATE.uiKeepAliveTimer + dtReal
  if STATE.uiKeepAliveTimer >= 2.0 then
    STATE.uiKeepAliveTimer = 0
    execMainUiJs("if(!window.__NativeRallyMP||!document.getElementById('nrmp-cef-root')){if(window.bngApi&&window.bngApi.engineLua)window.bngApi.engineLua('if extensions.nativeRallyBridge then extensions.nativeRallyBridge.onCefNeedsMount() end');}")
  end

  -- Report level readiness ONLY after worldReadyState == 2 AND loading screen has finished unloading
  if STATE.pendingReadyMinDelay and STATE.worldReadyState == 2 then
    STATE.pendingReadyMinDelay = STATE.pendingReadyMinDelay - dtReal
    STATE.pendingReadyMaxWait = math.max(0, STATE.pendingReadyMaxWait - dtReal)
    if STATE.pendingReadyMinDelay <= 0 then
      local loadingActive = isUiLoadingScreenActive()
      local carPending = STATE.waitingForSavedCarSpawn and (getOwnVehicle() == nil)
      if (not loadingActive and not carPending) or STATE.pendingReadyMaxWait <= 0 then
        STATE.pendingReadyMinDelay = nil
        STATE.waitingForSavedCarSpawn = false
        reconcileSingleActivePlayerVehicle()
        flushMpSpawnQueueNow(true)
        local lvl = getCurrentLevelName()
        if lvl ~= "" then
          log("I", "nativeRallyBridge", "Reporting level ready to BeamMP Server -> '" .. tostring(lvl) .. "'")
          sendServerEvent("NativeRally_ClientLevelReady", { level = lvl })
        end
        if STATE.pendingCoursePlacement and STATE.pendingCoursePlacement.missionId then
          local pc = STATE.pendingCoursePlacement
          STATE.pendingCoursePlacement = nil
          placeRallyCourseInFreeroam(pc.missionId, pc.missionDir)
        end
        if STATE.queuedLaunchAfterSwitch then
          local queuedRaw = STATE.queuedLaunchAfterSwitch
          STATE.queuedLaunchAfterSwitch = nil
          onExecuteLaunch(queuedRaw)
        end
      end
    end
  end

  if CFG.enableRttClockSync and mpConn then
    STATE.probeTimer = STATE.probeTimer + dtReal
    if STATE.probeTimer >= 4.0 then
      STATE.probeTimer = 0
      sendServerEvent("NativeRally_ClockProbe", { clientSentMs = now, lastRttMs = STATE.rttMs })
    end
  end

  if STATE.activeMissionId then
    updateCoDriverStageOdometer(dtReal)
    STATE.shieldTimer = STATE.shieldTimer + dtReal
    if STATE.shieldTimer >= 0.20 then
      STATE.shieldTimer = 0
      -- Re-hook gameplay_rally & gameplay_rallyLoop automatically if Flowgraph loopInit reloaded them
      hookNativeGameplayRally()
      hookNativeGameplayRallyLoop()
      silenceAiVoicepackAndEnforceHud()
      restoreAllRemoteMpVehicles()
      checkAndApplySpawnSeparation()
      checkAndApplyWrcSlotScheduleOffset()
      injectPeerIntoNativeEndScreen()

      do -- detect the native mission stopping (end screen closed / abandoned)
        local mm = gameplay_missions_missionManager
        local fgId = mm and mm.getForegroundMissionId and mm.getForegroundMissionId() or nil
        if fgId then
          STATE.sawForegroundMission = true
        elseif STATE.sawForegroundMission and not STATE.stageEndReported then
          STATE.stageEndReported = true
          reportStageEnded()
          return
        end
      end

      local lm = gameplay_rallyLoop and gameplay_rallyLoop.getManager and gameplay_rallyLoop.getManager()
      if lm and lm.getEventLog then
        local evLog = lm:getEventLog()
        local sTimes = {}
        for _, item in ipairs(evLog and evLog:getStageTimes() or {}) do
          sTimes[#sTimes + 1] = item.data.stageTimeSecs
        end
        if #sTimes > 0 then
          sendServerEvent("NativeRally_StageOrLoopResult", {
            stageTimes = sTimes,
            penaltySec = lm:getTotalPenalty() or 0,
            totalSec = lm:getTotalTime() or 0,
            completed = false
          })
        end
      end
    end
  elseif STATE.stagedMissionId then
    updateCoDriverStageOdometer(dtReal)
  end

  if STATE.simultaneousReleaseClientMs and now >= STATE.simultaneousReleaseClientMs then
    STATE.simultaneousReleaseClientMs = nil
    STATE.sentStagedAtSS = false
    local veh = getOwnVehicle()
    if veh then setVehFreeze(veh, false) end
  end
end

function M.onUpdate(dtReal)
  tickBridge(dtReal)
end

function M.onPreRender(dtReal)
  tickBridge(dtReal)
end

function M.onBeamMPPostJoin()
  registerBeamMpEvents()
  installMpCrossMapSessionGuard()
  installMpVehicleGeHooks()
  injectLiveCefPauseMenuUi()
  flushMpSpawnQueueNow(true)
end

function M.onWorldReadyState(worldState)
  local ws = tonumber(worldState) or 0
  STATE.worldReadyState = ws
  if ws == 2 then
    STATE.switchingMapFromServer = false
    STATE.switchingTargetLevel = ""
    STATE.switchingMapReleaseTimer = 3.0
    STATE.lastReportedGameVehId = nil
    STATE.lastReportedServerVehId = ""
    if STATE.stagedMissionId and STATE.stagedMissionId ~= "" then
      placeRallyCourseInFreeroam(STATE.stagedMissionId, STATE.stagedMissionDir)
    end
    STATE.forcedMpSendForVehId = nil
    if spawn then spawn.preventPlayerSpawning = false end
    if settings and settings.setValue then
      pcall(settings.setValue, "queueSkipUnicycle", false)
      pcall(settings.setValue, "unicycleAutoSave", true)
    end
    registerBeamMpEvents()
    installMpCrossMapSessionGuard()
    installMpVehicleGeHooks()
    injectLiveCefPauseMenuUi()
    enforceCollisionPolicy(false)
    if not STATE.catalogScanned then
      scanAllMapsAndRallyMissions()
    else
      emitVueBridgeState()
    end
    hookMissionManager()

    if STATE.vehicleMode == "own_mp_car" and STATE.savedPlayerVehicle and getOwnVehicle() == nil then
      ensureSavedPlayerVehicleRestored()
      STATE.waitingForSavedCarSpawn = true
      STATE.pendingReadyMinDelay = 2.8
      STATE.pendingReadyMaxWait = 8.5
    else
      STATE.waitingForSavedCarSpawn = false
      STATE.pendingReadyMinDelay = 2.4
      STATE.pendingReadyMaxWait = 8.0
    end
  end
end

function M.onClientPostStartMission()
  -- NOTE: onClientPostStartMission fires ~15-20s BEFORE onWorldReadyState(2)!
  -- Keep STATE.switchingMapFromServer active until onWorldReadyState(2) finishes.
  STATE.luaMenuOpen = false
  registerBeamMpEvents()
  installMpCrossMapSessionGuard()
  installMpVehicleGeHooks()
  injectLiveCefPauseMenuUi()
  if not STATE.catalogScanned then
    scanAllMapsAndRallyMissions()
  else
    emitVueBridgeState()
  end
  hookMissionManager()
end

function M.onInit()
  if setExtensionUnloadMode then
    pcall(setExtensionUnloadMode, M, "manual")
  end
end

function M.onExtensionLoaded()
  if setExtensionUnloadMode then
    pcall(setExtensionUnloadMode, M, "manual")
  end

  seedFallbackCatalog()
  registerBeamMpEvents()
  installMpCrossMapSessionGuard()
  installMpVehicleGeHooks()
  injectLiveCefPauseMenuUi()
  hookMissionManager()
  hookNativeGameplayRally()
  hookNativeGameplayRallyLoop()
  installTrafficDeleteShield()
  enforceCollisionPolicy(false)
  flushMpSpawnQueueNow(true)

  if settings and settings.getValue then
    local cd = settings.getValue("rallyStartCountdownDisplay")
    if cd == "2d" or cd == "3d" then STATE.countdownDisplay = cd end
  end

  if isLoadedInLevel() then
    STATE.worldReadyState = tonumber(worldReadyState) or 2
    scanAllMapsAndRallyMissions()
    reconcileSingleActivePlayerVehicle()
    local lvl = getCurrentLevelName()
    if lvl ~= "" then
      sendServerEvent("NativeRally_ClientLevelReady", { level = lvl })
    end
  else
    emitVueBridgeState()
  end

  log("I", "nativeRallyBridge", "BeamNG v0.40.4+ Live MainGEUI Pause Menu + 1-Car Prop Filter + Instant 3D Queue Flush + Solid Physics Bridge initialized.")
end




function M.vueRequestCrew(requestType, targetPlayerId)
  sendServerEvent("NativeRally_UIAction", {
    action = "requestCrew",
    type = tostring(requestType or "ask_copilot"),
    targetPlayerId = tonumber(targetPlayerId)
  })
end

function M.vueRespondCrewRequest(requestId, acceptBool)
  sendServerEvent("NativeRally_UIAction", {
    action = "respondCrewRequest",
    requestId = tostring(requestId or ""),
    accept = (acceptBool == true)
  })
end

function M.vueCancelCrewRequest()
  sendServerEvent("NativeRally_UIAction", {
    action = "cancelCrewRequest"
  })
end

function M.vueLeaveCrewSlot()
  sendServerEvent("NativeRally_UIAction", {
    action = "leaveSlot"
  })
end

return M
