-- Auto-loaded GE extension fallback: lua/ge/extensions/auto/nativeRallyAuto.lua
-- Guarantees nativeRallyBridge loads and rebinds even if BeamMP.zip reloads MPGameNetwork after startup.

local M = {}

function M.onExtensionLoaded()
  if setExtensionUnloadMode then
    pcall(setExtensionUnloadMode, M, "manual")
  end
  if not extensions.isExtensionLoaded("nativeRallyBridge") then
    extensions.load("nativeRallyBridge")
    if setExtensionUnloadMode then
      setExtensionUnloadMode("nativeRallyBridge", "manual")
    end
  elseif extensions.nativeRallyBridge and extensions.nativeRallyBridge.rebindMpEvents then
    extensions.nativeRallyBridge.rebindMpEvents()
  end
end

return M
